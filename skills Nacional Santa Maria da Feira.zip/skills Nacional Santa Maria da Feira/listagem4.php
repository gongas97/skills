<?php

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords"
        content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <link rel="shortcut icon" href="img/icons/icon-48x48.png" />

    <link rel="canonical" href="https://demo.adminkit.io/forms-layouts.html" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <title>BlSkilliana - Dashboard</title>



    <!-- BEGIN SETTINGS -->
    <!-- Remove this after purchasing -->
    <link rel="stylesheet" href="css/styleAdmin.css">
    <link rel="stylesheet" href="css/alertaErroSessao.css">
    <link class="js-stylesheet" href="css/light.css" rel="stylesheet">
    <link rel="stylesheet" href="css/datatables.css">
    <script src="js/jquery.js"></script>
    <script src="js/login.js"></script>
    <script src="js/sweatalert.js"></script>
    <script src="js/campo4.js"></script>
    <style>
        body {
            opacity: 0;
        }
    </style>

</head>

<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-layout="default">
    <div class="wrapper">

        <?php include_once 'menu.php' ?>

        <main class="content">
            <div class="container-fluid p-0">

                <div class="mb-3">
                    <h1 class="h3 d-inline align-middle">Listagem</h1>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Livros</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th scope="col">Titulo</th>
                                                <th scope="col">Quantidade</th>
                                                <th scope="col">Adicionar Stock</th>
                                                <th scope="col">Ficha Livro</th>
                                                <th scope="col">Remover</th>
                                            </tr>
                                        </thead>
                                        <tbody id="listagemLivros">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal para adicionar stock -->
            <div class="modal fade" id="modalStock" tabindex="-1" aria-labelledby="modalStockLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalStockLabel">Adicionar Stock</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="formAddStock">
                                <input type="hidden" id="hiddenISBN">
                                <div class="mb-3">
                                    <label for="quantidade" class="form-label">Quantidade</label>
                                    <input type="number" class="form-control" id="quantidade"
                                        placeholder="Insira a quantidade que quer adicionar de stock">
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                            <button type="button" class="btn btn-primary" onclick="adicionarStock()">Adicionar</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal para mostrar ficha do livro -->
            <div class="modal fade" id="modalInfo" tabindex="-1" aria-labelledby="modalInfoLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalInfoLabel">Ficha Livro</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="formAddInfo">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">Sinopse</th>
                                            <th scope="col">Ano</th>
                                            <th scope="col">Edição</th>
                                            <th scope="col">Autor</th>
                                            <th scope="col">Titulo</th>
                                        </tr>
                                    </thead>
                                    <tbody id="listagemInfo">
                                    </tbody>
                                </table>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal for Author Information -->
            <div class="modal fade" id="modalAuthorInfo" tabindex="-1" aria-labelledby="modalAuthorInfoLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg"> <!-- Use a larger modal size -->
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalAuthorInfoLabel">Author Information</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="table-responsive"> <!-- Add a responsive wrapper for the table -->
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">NIF</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Date of Birth</th>
                                            <th scope="col">Biography</th>
                                            <th scope="col">Additional Info</th>
                                            <th scope="col">Facebook</th>
                                            <th scope="col">Instagram</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="infoAutor">
                                        <!-- Author information will be loaded here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
    </div>

    </main>

    <?php include_once 'footer.php' ?>

    </div>
    </div>

    <script src="js/app.js"></script>
    <script src="js/datatables.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</html>

<?php

?>