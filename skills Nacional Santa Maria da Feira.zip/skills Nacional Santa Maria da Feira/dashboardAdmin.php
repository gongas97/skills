<?php
session_start(); // Start session at the very beginning
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords"
        content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="shortcut icon" href="img/icons/icon-48x48.png" />

    <link rel="canonical" href="https://demo.adminkit.io/forms-layouts.html" />

    <title>Dashboard Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">

    <!-- Remove this after purchasing -->
    <link rel="stylesheet" href="css/styleAdmin.css">
    <link rel="stylesheet" href="css/alertaErroSessao.css">
    <link class="js-stylesheet" href="css/light.css" rel="stylesheet">
    <link rel="stylesheet" href="css/datatables.css">
    <script src="js/jquery.js"></script>
    <script src="js/login.js"></script>
    <script src="js/sweatalert.js"></script>
    <script src="js/card.js"></script>

    <style>
        body {
            opacity: 0;
        }
    </style>
</head>

<body>
    <?php
    if (isset($_SESSION['admin'])) {
        $idAnunciante = $_SESSION['idAdmin']; // Obtém o ID do anunciante da sessão
        ?>

        <div class="wrapper">
            <?php include_once 'menuAdmin.php'; ?>


            <main class="content">
                <div class="container-fluid p-0">

                    <div class="mb-3">
                        <h1 class="h3 d-inline align-middle">Dashboard</h1>
                    </div>


                    <div class="row text-center">
                        <!-- Card for Borrowed Books -->
                        <div class="col-md-4">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">Numero de Users</h5>
                                </div>
                                <div class="card-body">
                                    <h2 class="display-4" id="quantidadeUsers"></h2>
                                </div>
                            </div>
                        </div>

                        <!-- Card for Active Members -->
                        <div class="col-md-4">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">Numero de Logins "Sucesso"</h5>
                                </div>
                                <div class="card-body">
                                    <h2 class="display-4" id="quantidadeLoginsSuccess"></h2>
                                </div>
                            </div>
                        </div>

                        <!-- Card for Total Registered Books -->
                        <div class="col-md-4">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">Numero de Logins "Falha"</h5>
                                </div>
                                <div class="card-body">
                                    <h2 class="display-4" id="quantidadeLoginsFalha"></h2>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row text-center">
                        <!-- Card for Books Registered Last Week -->
                        <div class="col-md-4">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">Contas Bloqueadas</h5>
                                </div>
                                <div class="card-body">
                                    <h2 class="display-4" id="quantidadeContasBlock"></h2>
                                </div>
                            </div>
                        </div>

                        <!-- Card for Books Registered Last Week -->
                        <div class="col-md-4">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">Contas Bloqueadas</h5>
                                </div>
                                <div class="card-body">
                                    <h2 class="display-4" id="quantidadeRealizadosEmprestados"></h2>
                                </div>
                            </div>
                        </div>

                        <!-- Card for Books Registered Last Week -->
                        <div class="col-md-4">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">Contas Bloqueadas</h5>
                                </div>
                                <div class="card-body">
                                    <h2 class="display-4" id="quantidadeRealizadosEmprestados"></h2>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="container-fluid p-0">

                        <div class="mb-3">
                            <h1 class="h3 d-inline align-middle">Listagem de Empréstimos em Atraso de Devolução</h1>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="card-title">Empréstimos</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Cod</th>
                                                        <th scope="col">Nome Sócio</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="listagemEmprestimosAtrasados">
                                                    <!-- Os dados dos funcionários serão inseridos aqui via JavaScript -->
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="container-fluid p-0">

                        <div class="mb-3">
                            <h1 class="h3 d-inline align-middle">Listagem Sócios Inativos</h1>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="card-title">
                                            <i class="fas fa-user"></i> <!-- Font Awesome user icon -->Sócios
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Nif</th>
                                                        <th scope="col">Nome</th>
                                                        <th scope="col">Atividade</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="listagemSociosInativos">
                                                    <!-- Os dados dos funcionários serão inseridos aqui via JavaScript -->
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </main>


            <?php include_once 'footerAdmin.php'; ?>
        </div>

        <?php
    } else {
        echo '<div class="body1">
                <div class="alert-message">
                    <h2>Acesso Negado ou a sua Sessão Expirou!</h2>
                    <p>Quer voltar ao Menu Principal?</p>
                    <a class="homePage" href="index.html">HOME PAGE</a>
                </div>
            </div>';
    }
    ?>
    <script src="js/app.js"></script>
    <script src="js/datatables.js"></script>
</body>

</html>