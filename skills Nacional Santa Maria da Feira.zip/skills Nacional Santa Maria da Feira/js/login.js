function logout() {
    let dados = new FormData();
    dados.append("op", 1);

    $.ajax({
        url: "controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {


            alerta("Logout", msg, "success");

            setTimeout(function () {
                window.location.href = "index.html";
            }, 2000);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

/* ANUNCIANTE */

function regista2() {
    let email = $('#emailUser').val();
    let password = $('#password').val();

    // Validação do e-mail
    if (!validarEmail(email)) {
        alerta("Registo", "Por favor, insira um e-mail válido.", "error");
        return;
    }

    // Validação da senha
    if (!validarSenha(password)) {
        alerta("Registo", "A senha deve ter no mínimo 12 caracteres, incluindo pelo menos uma letra maiúscula, uma letra minúscula, um número e um caractere especial.", "error");
        return;
    }

    let dados = new FormData();
    dados.append("op", 4);
    dados.append("nomeUser", $('#nomeUser').val());
    dados.append("emailUser", email);
    dados.append("nifUser", $('#nifUser').val());
    dados.append("pergunta1", $('#pergunta1').val());
    dados.append("resposta1Registo", $('#resposta1Registo').val());
    dados.append("pergunta2", $('#pergunta2').val());
    dados.append("reposta2Registo", $('#reposta2Registo').val());
    dados.append("username", $('#username').val());
    dados.append("password", password);
    dados.append("foto", $('#foto').prop('files')[0]);

    $.ajax({
        url: "controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {
            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Registo", obj.msg, "success");
                setTimeout(function () {
                    window.location.href = "login2.html";
                }, 2000);
            } else {
                alerta("Registo", obj.msg, "error");
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// Função para validar o e-mail
function validarEmail(email) {
    // Regex para verificar se o email termina em .com ou .pt
    const emailRegex = /^[^\s@]+@[^\s@]+\.(com|pt)$/i;
    return emailRegex.test(email);
}

// Função para validar a senha
function validarSenha(senha) {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{12,}$/;
    return regex.test(senha);
}

function login2() {

    let dados = new FormData();
    dados.append("op", 8);
    dados.append("username", $('#usernameLogin').val());
    dados.append("password", $('#passwordLogin').val());

    $.ajax({
        url: "controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("login", obj.msg, "success");

                setTimeout(function () {
                    window.location.href = "main2.php";
                }, 2000);

            } else {
                alerta("login", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function verificarPerguntas() {
    let dados = new FormData();
    dados.append('username', $('#usernameRecovery').val());
    dados.append('op', 2);

    $.ajax({
        url: "controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })
        .done(function (msg) {
            const obj = JSON.parse(msg);
            if (obj.flag) {
                // Hide username input and verification button
                $('#usernameRecovery, #buttonUser, #usernameRecoveryLabel').hide();

                // Show the security questions if the username exists
                $('#securityQuestions').show();

                // Set the text for the security questions
                $('#pergunta1Recovery').text(obj.msg.pergunta1);
                $('#pergunta2Recovery').text(obj.msg.pergunta2);

                // Store idUser in the hidden input
                $('#hiddenUserId').val(obj.msg.idUser);

            } else {
                alerta("Username", obj.msg, "error");
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function responderPerguntas() {

    let idUser = $('#hiddenUserId').val();  // Get idUser from hidden input
    let dados = new FormData();
    dados.append('resposta1', $('#resposta1Recovery').val());
    dados.append('resposta2', $('#resposta2Recovery').val());
    dados.append('idUser', idUser);
    dados.append('op', 3); // Operation code for verifying security answers

    $.ajax({
        url: "controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })
        .done(function (msg) {
            const obj = JSON.parse(msg);
            if (obj.flag) {
                // Hide security questions and answers if they are correct
                $('#pergunta1Recovery, #resposta1Recovery, #pergunta2Recovery, #resposta2Recovery, #buttonResposta, #pergunta1Label , #pergunta2Label').hide();

                // Show the new password input fields
                $('#newPassword').show();

            } else {
                alerta("Resposta", obj.msg, "error"); // Display error if answers are incorrect
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function recuperarPassword() {

    let newPassword = $('#newPassword1').val();

    // Validação da senha
    if (!validarSenha(newPassword)) {
        alerta("Registo", "A senha deve ter no mínimo 12 caracteres, incluindo pelo menos uma letra maiúscula, uma letra minúscula, um número e um caractere especial.", "error");
        return;
    }

    let idUser = $('#hiddenUserId').val();  // Get idUser from hidden input
    let dados = new FormData();
    dados.append('newPassword1', newPassword);
    dados.append('newPassword2', $('#newPassword2').val());
    dados.append('idUser', idUser);
    dados.append('op', 7); // Operation code for verifying security answers

    $.ajax({
        url: "controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })
        .done(function (msg) {
            const obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Password", obj.msg, "success");

                setTimeout(function () {
                    window.location.href = "login2.html";
                }, 2000);

            } else {
                alerta("Password", obj.msg, "error");
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

/*PRODUTORA*/


function regista3() {

    let dados = new FormData();



    dados.append('nomeProdutora', $('#nomeProdutora').val());
    dados.append('moradaFiscal', $('#moradaFiscal').val());
    dados.append('paisOrigem', $('#paisOrigem').val());
    dados.append('foto', $('#foto').prop('files')[0]);
    dados.append('historiaH', $('#historiaH').val()); //nome uma coisa id outra
    dados.append('foto2', $('#foto2').prop('files')[0]);
    dados.append('usernameP', $('#usernameP').val());
    dados.append('passwordP', $('#passwordP').val());

    dados.append('op', 5);

    $.ajax({
        url: "controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Registo", obj.msg, "success");

                setTimeout(function () {
                    window.location.href = "login3.html";
                }, 2000);

            } else {
                alerta("Registo", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function login3() {

    let dados = new FormData();
    dados.append("op", 6);
    dados.append("usernameP", $('#usernameLoginProdutora').val());
    dados.append("passwordP", $('#passwordLoginProdutora').val());

    $.ajax({
        url: "controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Login", obj.msg, "success");

                setTimeout(function () {
                    window.location.href = "main3.php";
                }, 2000);

            } else {
                alerta("Login", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function toggleMenu(element) {
    // Fecha todos os menus que não são o atual
    const sidebarLinks = document.querySelectorAll('.sidebar-item a[data-bs-toggle="collapse"]');
    sidebarLinks.forEach(link => {
        if (link !== element) {
            const targetId = link.getAttribute('data-bs-target');
            const target = document.querySelector(targetId);
            if (target && target.classList.contains('show')) {
                target.classList.remove('show');
            }
        }
    });
}

// ADMIN //

function loginAdmin() {

    let username = $('#usernameAdmin').val();
    let password = $('#pwAdmin').val();

    if (!username || !password) {
        alerta("Erro", "Preencha ambos os campos", "error");
        return;
    }

    let dados = new FormData();
    dados.append('username', username);
    dados.append('password', password);
    dados.append('op', 11);  // Operation code for login

    $.ajax({
        url: "controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "json",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (response) {
            if (response.flag) {
                alerta("Admin", response.msg, "success");

                setTimeout(function () {
                    window.location.href = "mainAdmin.php";  // Redirect after success
                }, 2000);

            } else {
                alerta("Admin", response.msg, "error");
            }
        })
        .fail(function (jqXHR, textStatus) {
            alerta("Erro", "Falha na requisição: " + textStatus, "error");
        });
}

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,
        confirmButtonText: 'Ok',
        confirmButtonColor: '#3085d6', // Cor do botão de confirmação
        backdrop: `
            rgba(0, 0, 123, 0.4)
            url("https://www.example.com/your-image.png") // URL de uma imagem de fundo, se desejar
            left top
            no-repeat
        `,
        customClass: {
            title: 'alert-title', // Classe customizada para o título
            html: 'alert-message', // Classe customizada para a mensagem
        },
        toast: false, // Defina como true se quiser um alerta do tipo toast
        timerProgressBar: true, // Mostra uma barra de progresso durante o tempo de espera
        showClass: {
            popup: 'animate__animated animate__fadeInDown', // Animação de entrada
        },
        hideClass: {
            popup: 'animate__animated animate__fadeOutUp', // Animação de saída
        },
    });
}

$(function () {
});