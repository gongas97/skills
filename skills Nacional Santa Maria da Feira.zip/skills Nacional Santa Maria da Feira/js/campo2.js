// ################################ REGISTO ################################ //

function registaMedico() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("nCedula", $('#campo2_2').val());
    dados.append("nome", $('#campo2_3').val());
    dados.append("nif", $('#campo2_4').val());
    dados.append("codPostal", $('#campo2_5').val());
    dados.append("morada", $('#campo2_6').val());
    dados.append("nacionalidade", $('#campo2_7').val());
    dados.append("dataNasc", $('#campo2_8').val());
    dados.append("email", $('#campo2_9').val());
    dados.append("tel", $('#campo2_10').val());



    $.ajax({
        url: "controller/controllerCampo2.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Médico Registado", obj.msg, "success");
                getListaMedicos();
            } else {
                alerta("Médico ", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ LISTAGEM ################################ //

function getListaMedicos() {
    let dados = new FormData();
    dados.append("op", 2);

    $.ajax({
        url: "controller/controllerCampo2.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        $('#listagemMedicos').html(msg);
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

// ################################ EDIÇÃO ################################ //

function editarMedico() {

    let dados = new FormData();
    dados.append("op", 7);
    dados.append('nCedula', $('#ListaMedicosEdit').val());

    $.ajax({
        url: "controller/controllerCampo2.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#campo2_1Edit').val(obj.nCedula);
            $('#campo2_2Edit').val(obj.nome);
            $('#campo2_3Edit').val(obj.nif);
            $('#campo2_4Edit').val(obj.codPostal);
            $('#campo2_5Edit').val(obj.morada);
            $('#campo2_6Edit').val(obj.nacionalidade);
            $('#campo2_7Edit').val(obj.email);
            $('#campo2_8Edit').val(obj.tel);

            $('#btnGuardaEdit').attr("onclick", "guardaEditMedico(" + obj.nCedula + ")")
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

  $('#ListaMedicosEdit').change(editarMedico);

function guardaEditMedico(nCedulaOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("nCedula", $('#campo2_1Edit').val());
    dados.append("nome", $('#campo2_2Edit').val());
    dados.append("nif", $('#campo2_3Edit').val());
    dados.append("codPostal", $('#campo2_4Edit').val());
    dados.append("morada", $('#campo2_5Edit').val());
    dados.append("nacionalidade", $('#campo2_6Edit').val());
    dados.append("email", $('#campo2_7Edit').val());
    dados.append("tel", $('#campo2_8Edit').val());
    dados.append("nCedulaOld", nCedulaOld);

    $.ajax({
        url: "controller/controllerCampo2.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Editado", obj.msg, "success");
                getListaMedicos();
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}


// ################################ REMOVER ################################ //

function removerMedico(nCedula) {

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("nCedula", nCedula);

    $.ajax({
        url: "controller/controllerCampo2.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Médico Removido", obj.msg, "success");
                getListaMedicos();
            } else {
                alerta("Médico", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}


// ################################ EDIÇÃO ################################ //

// function infoAgendamento(idAgendamento) {
//     let dados = new FormData();
//     dados.append("op", 4);
//     dados.append("id", idAgendamento);

//     $.ajax({
//         url: "controller/controllerCampo2.php",
//         method: "POST",
//         data: dados,
//         dataType: "html",
//         cache: false,
//         contentType: false,
//         processData: false
//     })
//     .done(function (msg) {
//         $('#infoPassageiros').html(msg);
//         $('#infoPModal').modal('show');
//     })
//     .fail(function (jqXHR, textStatus) {
//         alert("Request failed: " + textStatus);
//     });
// }


// ################################ GET ################################ //

function getMedicos() {
    
    let dados = new FormData();
    dados.append("op", 6);
    
    
    $.ajax({
        url: "controller/controllerCampo2.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#ListaMedicosEdit').html(msg);
            
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}


function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getListaMedicos();
    getMedicos();
});