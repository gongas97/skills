// ################################ REGISTO ################################ //

function registaVoo() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("descr", $('#campo4_2').val());
    dados.append("aviao", $('#campo4_3').val());
    dados.append("destino", $('#campo4_4').val());
    dados.append("estado", $('#campo4_5').val());


    $.ajax({
        url: "controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Voo Adicionado", obj.msg, "success");
                getListaVoos();
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ LISTAGEM ################################ //

function getListaVoos() {

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemVoos').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ REMOVER ################################ //

function removerVoo(id) {

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("id", id);

    $.ajax({
        url: "controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Voo Removido", obj.msg, "success");
                getListaVoos();
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}


// ################################ EDIÇÃO ################################ //

function editarVoo(id) {


    let dados = new FormData();
    dados.append("op", 4);
    dados.append("id", id);

    $.ajax({
        url: "controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#campo4_1Edit').val(obj.id);
            $('#campo4_2Edit').val(obj.descricao);
            $('#campo4_3Edit').val(obj.id_aviao);
            $('#campo4_4Edit').val(obj.id_destino);
            $('#campo4_5Edit').val(obj.estado);

            $('#btnGuardar').attr("onclick", "guardaEditVoo(" + obj.id + ")")

            $('#voosModal').modal('show')
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function guardaEditVoo(idOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("id", $('#campo4_1Edit').val());
    dados.append("descr", $('#campo4_2Edit').val());
    dados.append("aviao", $('#campo4_3Edit').val());
    dados.append("destino", $('#campo4_4Edit').val());
    dados.append("estado", $('#campo4_5Edit').val());
    dados.append("idOld", idOld);

    $.ajax({
        url: "controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Editado", obj.msg, "success");
                $('#voosModal').modal('hide')
                getListaVoos();
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}


// ################################ GET ################################ //

function getAviao() {
    
    let dados = new FormData();
    dados.append("op", 6);
    
    
    $.ajax({
        url: "controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo4_3').html(msg);
            $('#campo4_3Edit').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getDestino() {
    
    let dados = new FormData();
    dados.append("op", 8);
    
    
    $.ajax({
        url: "controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo4_4').html(msg);
            $('#campo4_4Edit').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}


// ################################ ALERTA ################################ //

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getListaVoos();
    getAviao();
    getDestino();
});