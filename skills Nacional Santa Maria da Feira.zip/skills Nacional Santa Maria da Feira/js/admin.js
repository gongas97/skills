// function listaParceriasAdmin() {

//     if ($.fn.DataTable.isDataTable('#recomendacoesLista')) {
//         $('#recomendacoesLista').DataTable().destroy();

//     }


//     let dados = new FormData();
//     dados.append("op", 8);


//     $.ajax({
//         url: "controller/controllerAdmin.php",
//         method: "POST",
//         data: dados,
//         dataType: "html",
//         cache: false,
//         contentType: false,
//         processData: false
//     })
//         .done(function (msg) {

//             $('#recomendacoesLista').DataTable();
//             $('#listaParceriasAdmin').html(msg); // Insere o resultado na div #listaParcerias
//         })
//         .fail(function (jqXHR, textStatus) {
//             console.log("Request failed:", textStatus); // Log do erro
//             alert("Request failed: " + textStatus);
//         });
// }

// Função para Confirmar Parceria
// function confirmarParceriaAdmin(idRecomendacao) {
//     let dados = new FormData();
//     dados.append("op", 7); // Operação para enviar mensagem
//     dados.append("idRecomendacao", idRecomendacao);

//     $.ajax({
//         url: "controller/controllerAdmin.php", // Atualiza o controlador para produtoras
//         method: "POST",
//         data: dados,
//         dataType: "html",
//         cache: false,
//         contentType: false,
//         processData: false
//     })
//         .done(function (msg) {
//             if (msg) {
//                 alerta("Parceria Confirmada", msg, "success");
//                 listaParceriasAdmin();
//             } else {
//                 alerta("Parceria", msg, "error");
//             }
//         })
//         .fail(function (jqXHR, textStatus) {
//             alert("Request failed: " + textStatus);
//         });
// }


// GESTÂO DE UTILIZADORES //

function listagemUsers() {

    if ($.fn.DataTable.isDataTable('#usersLista')) {
        $('#usersLista').DataTable().destroy();

    }


    let dados = new FormData();
    dados.append("op", 9);


    $.ajax({
        url: "controller/controllerAdmin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {

            $('#usersLista').DataTable();
            $('#listaUsers').html(msg); // Insere o resultado na div #listaParcerias
        })
        .fail(function (jqXHR, textStatus) {
            console.log("Request failed:", textStatus); // Log do erro
            alert("Request failed: " + textStatus);
        });
}

function bloquearUser(idUser) {
    let dados = new FormData();
    dados.append("op", 12); // Operação para enviar mensagem
    dados.append("idUser", idUser);

    $.ajax({
        url: "controller/controllerAdmin.php", // Atualiza o controlador para produtoras
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {
            if (msg) {
                alerta("Consumidor", msg, "success");
                listagemUsers();
            } else {
                alerta("Consumidor", msg, "error");
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function desbloquearUser(idUser) {
    let dados = new FormData();
    dados.append("op", 13); // Operação para enviar mensagem
    dados.append("idUser", idUser);

    $.ajax({
        url: "controller/controllerAdmin.php", // Atualiza o controlador para produtoras
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {
            if (msg) {
                alerta("Consumidor", msg, "success");
                listagemUsers();
            } else {
                alerta("Consumidor", msg, "error");
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function abrirStatusConsumidorModal(idConsumidor) {
    console.log("Consumidor ID ao abrir o modal:", idConsumidor); // Log do idProdutora

    // Atualiza o campo hidden com o idProdutora
    $('#idConsumidorHidden').val(idConsumidor);

    // Chama a função listaParcerias para buscar as parcerias da produtora
    listagemConsumidores(idConsumidor);

    // Mostra o modal
    $('#editStatusConsumidor').modal('show');
}

function listaLogins() {

    if ($.fn.DataTable.isDataTable('#loginsLista')) {
        $('#loginsLista').DataTable().destroy();

    }


    let dados = new FormData();
    dados.append("op", 10);


    $.ajax({
        url: "controller/controllerAdmin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {

            $('#loginsLista').DataTable();
            $('#listaLogins').html(msg); // Insere o resultado na div #listaParcerias
        })
        .fail(function (jqXHR, textStatus) {
            console.log("Request failed:", textStatus); // Log do erro
            alert("Request failed: " + textStatus);
        });
}

function ativarAnunciante(idAnunciante) {
    let dados = new FormData();
    dados.append("op", 16); // Operação para enviar mensagem
    dados.append("idAnunciante", idAnunciante);

    $.ajax({
        url: "controller/controllerAdmin.php", // Atualiza o controlador para produtoras
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {
            if (msg) {
                alerta("Anunciante", msg, "success");
                listagemAnunciantes();
            } else {
                alerta("Anunciante", msg, "error");
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function inativarAnunciante(idAnunciante) {
    let dados = new FormData();
    dados.append("op", 17); // Operação para enviar mensagem
    dados.append("idAnunciante", idAnunciante);

    $.ajax({
        url: "controller/controllerAdmin.php", // Atualiza o controlador para produtoras
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {
            if (msg) {
                alerta("Anunciante", msg, "success");
                listagemAnunciantes();
            } else {
                alerta("Anunciante", msg, "error");
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function listagemProdutoras() {

    if ($.fn.DataTable.isDataTable('#produtorasLista')) {
        $('#produtorasLista').DataTable().destroy();

    }


    let dados = new FormData();
    dados.append("op", 11);


    $.ajax({
        url: "controller/controllerAdmin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {

            $('#listaProdutoras').html(msg); // Insere o resultado na div #listaParcerias
            $('#produtorasLista').DataTable();
        })
        .fail(function (jqXHR, textStatus) {
            console.log("Request failed:", textStatus); // Log do erro
            alert("Request failed: " + textStatus);
        });
}

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}

function ativarProdutora(idProdutora) {
    let dados = new FormData();
    dados.append("op", 14); // Operação para enviar mensagem
    dados.append("idProdutora", idProdutora);

    $.ajax({
        url: "controller/controllerAdmin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {
            if (msg) {
                alerta("Produtora", msg, "success");
                listagemProdutoras();
            } else {
                alerta("Produtora", msg, "error");
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function inativarProdutora(idProdutora) {
    let dados = new FormData();
    dados.append("op", 15); // Operação para enviar mensagem
    dados.append("idProdutora", idProdutora);

    $.ajax({
        url: "controller/controllerAdmin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {
            if (msg) {
                alerta("Produtora", msg, "success");
                listagemProdutoras();
            } else {
                alerta("Produtora", msg, "error");
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function listagemEventosAdmin() {

    if ($.fn.DataTable.isDataTable('#EventosLista1')) {
        $('#EventosLista1').DataTable().destroy();

    }

    let dados = new FormData();

    dados.append('op', 18);

    $.ajax({
        url: "controller/controllerAdmin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })

        .done(function (msg) {

            $('#EventosLista1').DataTable();
            $('#EventosListas1').html(msg);


        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function infoEvento(idEvento) {

    $('#modalInfoEvento').modal('show');

    let dados = new FormData();
    dados.append("op", 19);
    dados.append("idEvento", idEvento);


    $.ajax({
        url: "controller/controllerAdmin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            let obj = JSON.parse(msg);
            if (obj.error) {
                alert("Erro: " + obj.error);
            } else {
                $('#imagemEvento').attr('src', obj.fotoEvento);
                $('#nomeEventoModal').text(obj.nomeEvento);
                $('#precoEventoModal').text(obj.precoEvento);
                $('#dataEventoModal').text(obj.dataEvento);
                $('#horaInicioModal').text(obj.horaInicioEvento);
                $('#horaFinalModal').text(obj.horaFinalEvento);
                $('#localEventoModal').text(obj.localizacao);
                $('#descricaoEventoModal').text(obj.descricao);
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

//ANUNCIOS //

function listagemAnunciosAdmin() {

    if ($.fn.DataTable.isDataTable('#AnunciosLista1')) {
        $('#AnunciosLista1').DataTable().destroy();

    }

    let dados = new FormData();

    dados.append('op', 20);

    $.ajax({
        url: "controller/controllerAdmin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })

        .done(function (msg) {

            $('#AnunciosLista1').DataTable();
            $('#AnunciosListas1').html(msg);


        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function validarAnuncio(idAnuncio) {
    let dados = new FormData();
    dados.append("op", 22); // Operação para enviar mensagem
    dados.append("idAnuncio", idAnuncio);

    $.ajax({
        url: "controller/controllerAdmin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {
            if (msg) {
                alerta("Anuncio", msg, "success");
                listagemAnunciosAdmin();
            } else {
                alerta("Anuncio", msg, "error");
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function rejeitarAnuncio(idAnuncio) {
    let dados = new FormData();
    dados.append("op", 23); // Operação para enviar mensagem
    dados.append("idAnuncio", idAnuncio);

    $.ajax({
        url: "controller/controllerAdmin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {
            if (msg) {
                alerta("Anuncio", msg, "success");
                listagemAnunciosAdmin();
            } else {
                alerta("Anuncio", msg, "error");
            }
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function infoAnuncio(idAnuncio) {

    $('#modalInfoAnuncios').modal('show');

    let dados = new FormData();
    dados.append("op", 21);
    dados.append("idAnuncio", idAnuncio);


    $.ajax({
        url: "controller/controllerAdmin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#infoEvento1').html(msg);

        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

$(function () {
    listagemUsers();
    listaLogins();
});

