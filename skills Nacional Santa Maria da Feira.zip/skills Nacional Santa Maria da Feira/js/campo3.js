// ################################ REGISTO ################################ //

function registaConsulta() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("medico", $('#campo3_2').val());
    dados.append("atleta", $('#campo3_3').val());
    dados.append("data", $('#campo3_4').val());
    dados.append("senha", $('#campo3_5').val());
    dados.append("valor", $('#campo3_6').val());
    dados.append("fCardica", $('#campo3_7').val());
    dados.append("PAmin", $('#campo3_8').val());
    dados.append("PAmax", $('#campo3_9').val());
    dados.append("comentarios", $('#campo3_10').val());



    $.ajax({
        url: "controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Consulta", obj.msg, "success");
                getListaConsultas();
            } else {
                alerta("Consulta ", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ LISTAGEM ################################ //

function getListaConsultas() {
    let dados = new FormData();
    dados.append("op", 2);

    $.ajax({
        url: "controller/controllercampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        $('#listagemConsultas').html(msg);
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

// ################################ EDIÇÃO ################################ //

function editarMedico() {

    let dados = new FormData();
    dados.append("op", 7);
    dados.append('nCedula', $('#ListaMedicosEdit').val());

    $.ajax({
        url: "controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#campo3_1Edit').val(obj.nCedula);
            $('#campo3_2Edit').val(obj.nome);
            $('#campo3_3Edit').val(obj.nif);
            $('#campo3_4Edit').val(obj.codPostal);
            $('#campo3_5Edit').val(obj.morada);
            $('#campo3_6Edit').val(obj.nacionalidade);
            $('#campo3_7Edit').val(obj.email);
            $('#campo3_8Edit').val(obj.tel);

            $('#btnGuardaEdit').attr("onclick", "guardaEditMedico(" + obj.nCedula + ")")
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

  $('#ListaMedicosEdit').change(editarMedico);

function guardaEditMedico(nCedulaOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("nCedula", $('#campo3_1Edit').val());
    dados.append("nome", $('#campo3_2Edit').val());
    dados.append("nif", $('#campo3_3Edit').val());
    dados.append("codPostal", $('#campo3_4Edit').val());
    dados.append("morada", $('#campo3_5Edit').val());
    dados.append("nacionalidade", $('#campo3_6Edit').val());
    dados.append("email", $('#campo3_7Edit').val());
    dados.append("tel", $('#campo3_8Edit').val());
    dados.append("nCedulaOld", nCedulaOld);

    $.ajax({
        url: "controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Editado", obj.msg, "success");
                getListaMedicos();
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}


// ################################ REMOVER ################################ //

function removerMedico(nCedula) {

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("nCedula", nCedula);

    $.ajax({
        url: "controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Médico Removido", obj.msg, "success");
                getListaMedicos();
            } else {
                alerta("Médico", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}


// ################################ INFO ################################ //

function infoConsulta(id) {
    let dados = new FormData();
    dados.append("op", 4);
    dados.append("id", id);

    $.ajax({
        url: "controller/controllercampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        $('#infoConsulta').html(msg);
        $('#infoPModal').modal('show');
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}


// ################################ GET ################################ //

function getMedicos() {
    
    let dados = new FormData();
    dados.append("op", 6);
    
    
    $.ajax({
        url: "controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo3_2').html(msg);
            
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getAtletas() {
    
    let dados = new FormData();
    dados.append("op", 8);
    
    
    $.ajax({
        url: "controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo3_3').html(msg);
            
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}


function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getListaConsultas();
    getMedicos();
    getAtletas();
});