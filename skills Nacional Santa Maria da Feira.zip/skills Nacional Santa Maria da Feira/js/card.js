function card1() {

    let dados = new FormData();
    dados.append("op", 1);


    $.ajax({
        url: "controller/controllerCard.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#quantidadeUsers').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function card2() {

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "controller/controllerCard.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#quantidadeLoginsSuccess').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function card3() {

    let dados = new FormData();
    dados.append("op", 3);


    $.ajax({
        url: "controller/controllerCard.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#quantidadeLoginsFalha').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function card4() {

    let dados = new FormData();
    dados.append("op", 4);


    $.ajax({
        url: "controller/controllerCard.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#quantidadeContasBlock').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function card5() {

    let dados = new FormData();
    dados.append("op", 5);


    $.ajax({
        url: "controller/controllerCard.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

    .done(function (msg) {

        let obj = JSON.parse(msg);
            $('#topSocioNome').html(obj.nome); 
            $('#topSocioCount').html(obj.total); 

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

$(document).ready(function() {
    card1(); // Call this when the page is ready
    card2();
    card3();
    card4();
    card5();
});