// ################################ REGISTO ################################ //

function registaAtleta() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("nif", $('#nifAtleta').val());
    dados.append("nome", $('#nomeAtleta').val());
    dados.append("codA", $('#codAtleta').val());
    dados.append("codPostal", $('#codPostalAtleta').val());
    dados.append("nacionalidade", $('#nacionalidadeAtleta').val());
    dados.append("dataNasc", $('#nascimentoAtleta').val());
    dados.append("email", $('#emailAtleta').val());
    dados.append("descricao", $('#descricaoAtleta').val());

    $.ajax({
        url: "controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Atleta Registado", obj.msg, "success");
                getListaClientes();

                // Clear the form fields
                $('#nifAtleta').val('');
                $('#nomeAtleta').val('');
                $('#codAtleta').val('');
                $('#codPostalAtleta').val('');
                $('#nacionalidadeAtleta').val('');
                $('#nascimentoAtleta').val('');
                $('#emailAtleta').val('');
                $('#descricaoAtleta').val('');
            } else {
                alerta("Atleta", obj.msg, "error");
            }
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ LISTAGEM ################################ //

function getListaAtletas() {


    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#listagemAtletas').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ INFO ################################ //

function infoAtleta(nif) {
    let dados = new FormData();
    dados.append("op", 7);
    dados.append("nif", nif);

    $.ajax({
        url: "controller/controllercampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        $('#infoAtleta').html(msg);
        $('#infoPModalAtleta').modal('show');
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}


// ################################ EDIÇÃO ################################ //

function editarAtleta() {




    let dados = new FormData();
    dados.append("op", 4);
    dados.append('nif', $('#ListaAtletasEdit').val());

    $.ajax({
        url: "controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#campo1_1Edit').val(obj.nif);
            $('#campo1_2Edit').val(obj.nome);
            $('#campo1_3Edit').val(obj.codAtleta);
            $('#campo1_4Edit').val(obj.codPostal);
            $('#campo1_5Edit').val(obj.nacionalidade);
            $('#campo1_6Edit').val(obj.dataNascimento);
            $('#campo1_7Edit').val(obj.email);
            $('#campo1_8Edit').val(obj.descricao);

            $('#btnGuardaEdit').attr("onclick", "guardaEditAtleta(" + obj.nif + ")")

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

  $('#ListaAtletasEdit').change(editarAtleta);

function guardaEditAtleta(nifOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("nif", $('#campo1_1Edit').val());
    dados.append("nome", $('#campo1_2Edit').val());
    dados.append("codAtleta", $('#campo1_3Edit').val());
    dados.append("codPostal", $('#campo1_4Edit').val());
    dados.append("nacionalidade", $('#campo1_5Edit').val());
    dados.append("dataNascimento", $('#campo1_6Edit').val());
    dados.append("email", $('#campo1_7Edit').val());
    dados.append("descricao", $('#campo1_8Edit').val());
    dados.append("nifOld", nifOld);

    $.ajax({
        url: "controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Editado", obj.msg, "success");
                getListaAtletas();
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}



// ################################ GET ################################ //

function getAtleta() {

    let dados = new FormData();
    dados.append("op", 6);


    $.ajax({
        url: "controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#ListaAtletasEdit').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}



function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getListaAtletas();
    getAtleta();
});