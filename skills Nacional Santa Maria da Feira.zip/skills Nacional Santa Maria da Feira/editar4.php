<?php

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords"
        content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <link rel="shortcut icon" href="img/icons/icon-48x48.png" />

    <link rel="canonical" href="https://demo.adminkit.io/forms-layouts.html" />

    <title>BlSkilliana - Dashboard</title>



    <!-- BEGIN SETTINGS -->
    <!-- Remove this after purchasing -->
    <link rel="stylesheet" href="css/styleAdmin.css">
    <link rel="stylesheet" href="css/alertaErroSessao.css">
    <link class="js-stylesheet" href="css/light.css" rel="stylesheet">
    <link rel="stylesheet" href="css/datatables.css">
    <script src="js/jquery.js"></script>
    <script src="js/login.js"></script>
    <script src="js/sweatalert.js"></script>
    <script src="js/campo4.js"></script>
    <style>
        body {
            opacity: 0;
        }
    </style>

</head>

<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-layout="default">
    <div class="wrapper">

        <?php include_once 'menu.php' ?>

        <main class="content">
            <div class="container-fluid p-0">

                <div class="mb-3">
                    <h1 class="h3 d-inline align-middle">Editar</h1>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Livro</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label for="listaLivros4" class="form-label">Livro:</label>
                                    <select class="form-select" id="listaLivros4" onchange="filtrarTabela(this.value)">
                                    </select>
                                </div>
                                <form>
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label">ISBN</label>
                                            <input type="number" class="form-control" id="isbnLivroEdit" disabled>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Titulo</label>
                                            <input type="text" class="form-control" id="titLivroEdit" >
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Data Lançamento</label>
                                            <input type="date" class="form-control" id="dataLivroEdit">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Sinopse</label>
                                            <input class="form-control" type="text" id="sinopLivroEdit">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Edição</label>
                                            <input type="text" class="form-control" id="edicaoLivroEdit"
                                                name="historiaH"></input>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Editora</label>
                                            <input class="form-control" type="text" id="editoraLivroEdit">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Idioma</label>
                                            <input type="text" class="form-control" id="idiomaLivroEdit">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Numero Páginas</label>
                                            <input type="number" class="form-control" id="nPaginasLivroEdit">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Estado</label>
                                            <select class="form-select" id="estadoLivroEdit">
                                            </select>
                                        </div>

                                    </div>
                                    <button type="button" class="btn btn-primary" id="btnGuardaEdit">Editar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php include_once 'footer.php' ?>

    </div>
    </div>

    <script src="js/app.js"></script>
    <script src="js/datatables.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</html>

<?php

?>