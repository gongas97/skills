<?php

require_once 'connection.php';

class Atleta
{

    // ################################ REGISTO ################################ //

    function registaAtleta($nif, $nome, $codA, $codPostal, $nacionalidade, $dataNasc, $email, $descricao)
    {
        global $conn;
        $flag = true;
        $msg = "";

        ### Registo do Cliente ###
        if ($flag) {
            $sql = "INSERT INTO atleta (nif, nome, codAtleta, codPostal, nacionalidade, dataNascimento, email, descricao) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            if ($stmt3 = $conn->prepare($sql)) {
                $stmt3->bind_param("ssssssss", $nif, $nome, $codA, $codPostal, $nacionalidade, $dataNasc, $email, $descricao);
                if ($stmt3->execute()) {
                    $msg = "Registrado com sucesso!";
                } else {
                    $flag = false;
                    $msg = "Erro: " . $stmt3->error;
                }
                $stmt3->close();
            } else {
                $flag = false;
                $msg = "Erro: " . $conn->error;
            }
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return $resp;
    }

    // ################################ LISTAGEM ################################ //
    function getListagemAtletas()
    {
        global $conn;
        $msg = "";

        $sql = "SELECT * FROM atleta";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['nif'] . "</th>";
                $msg .= "<th scope='row'>" . $row['nome'] . "</th>";
                $msg .= "<td><button class='btn btn-info' onclick='infoAtleta(" . $row['nif'] . ")'><i class='fas fa-info'></i></button></td>";
                $msg .= "<td><button class='btn btn-danger' onclick='removerAtleta(" . $row['nif'] . ")'><i class='fas fa-trash-alt'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function infoAtleta($nif)
    {
        global $conn;
        $msg = "";

        // SQL query to retrieve athlete details along with sport names
        $sql = "SELECT atleta.codAtleta, atleta.email, atleta.nacionalidade, modalidade.nomeModalidade, atleta.descricao, atleta.dataNascimento
            FROM atleta
            JOIN modalidadesatleta ON atleta.nif = modalidadesatleta.nifAtleta
            JOIN modalidade ON modalidadesatleta.codModalidade = modalidade.cod
            WHERE atleta.nif = ?";

        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $nif);  // Changed to "s" for string if nif is VARCHAR/CHAR
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Variables to store single values for athlete data and an array for sports
                $codAtleta = $email = $nacionalidade = $descricao = $dataNascimento = "";
                $modalidades = [];

                // Loop through each sport associated with the athlete and gather data
                while ($row = $result->fetch_assoc()) {
                    // Store the athlete's data once
                    if (!$codAtleta) {
                        $codAtleta = htmlspecialchars($row['codAtleta']);
                        $email = htmlspecialchars($row['email']);
                        $nacionalidade = htmlspecialchars($row['nacionalidade']);
                        $descricao = htmlspecialchars($row['descricao']);
                        $dataNascimento = htmlspecialchars($row['dataNascimento']);
                    }
                    // Add each sport name to the sports array
                    $modalidades[] = htmlspecialchars($row['nomeModalidade']);
                }

                // Build the table row
                $msg .= "<tr>";
                $msg .= "<td>" . $codAtleta . "</td>";
                $msg .= "<td>" . $email . "</td>";
                $msg .= "<td>" . $nacionalidade . "</td>";
                $msg .= "<td>" . $descricao . "</td>";
                $msg .= "<td>" . $dataNascimento . "</td>";
                // Join all sport names with commas or line breaks
                $msg .= "<td>" . implode(", ", $modalidades) . "</td>";
                $msg .= "</tr>";

            } else {
                // No records found
                $msg .= "<tr>";
                $msg .= "<td colspan='6'>Sem Registos</td>";
                $msg .= "</tr>";
            }

            $stmt->close();
        } else {
            // SQL error handling
            $msg .= "<tr>";
            $msg .= "<td colspan='6'>Erro na consulta: " . htmlspecialchars($conn->error) . "</td>";
            $msg .= "</tr>";
        }

        $conn->close();

        return $msg;
    }

    // ################################ EDITAR ################################ //
    function editarAtleta($nif)
    {
        global $conn;
        $row = "";

        $sql = "SELECT * FROM atleta WHERE nif =" . $nif;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function guardaEditAtleta($nif, $nome, $codAtleta, $codPostal, $nacionalidade, $dataNascimento, $email, $descricao, $nifOld)
    {
        global $conn;
        $msg = "";
        $flag = true;

        if ($flag) {
            $sql = "UPDATE atleta SET nif = ?, nome = ?, codAtleta = ?, codPostal = ?, nacionalidade = ?, dataNascimento = ?, email = ?, descricao = ? 
                WHERE nif = ?";

            if ($stmt2 = $conn->prepare($sql)) {
                $stmt2->bind_param("ssssssssi", $nif, $nome, $codAtleta, $codPostal, $nacionalidade, $dataNascimento, $email, $descricao, $nifOld);
                if ($stmt2->execute()) {
                    $msg = "Editado com sucesso!";
                } else {
                    $flag = false;
                    $msg = "Erro ao editar: " . $stmt2->error;
                }
                $stmt2->close();
            } else {
                $flag = false;
                $msg = "Erro: " . $conn->error;
            }
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return $resp;
    }

    // ################################ GETS ################################ //

    function getsAtletas()
    {
        global $conn;
        $msg = "<option selected>Escolha um Atleta</option>";

        $sql = "SELECT * FROM atleta";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['nif'] . "'>" . $row['nome'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Atletas registados</option>";

        }
        $conn->close();

        return ($msg);
    }

    // ################################ DIRETORIO FOTO ################################ //
    function updateFoto($diretorio, $id)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "UPDATE campo3 SET foto = '" . $diretorio . "' WHERE id = " . $id;

        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        return ($resp);
    }
    function uploads($img, $id)
    {

        $dir = "../imagens/Campo3" . $id . "/";
        $dir1 = "assets/imagens/Campo3" . $id . "/";
        $flag = false;
        $targetBD = "";

        if (!is_dir($dir)) {
            if (!mkdir($dir, 0777, TRUE)) {
                die("Erro não é possivel criar o diretório");
            }
        }
        if (array_key_exists('foto', $img)) {
            if (is_array($img)) {
                if (is_uploaded_file($img['foto']['tmp_name'])) {
                    $fonte = $img['foto']['tmp_name'];
                    $ficheiro = $img['foto']['name'];
                    $end = explode(".", $ficheiro);
                    $extensao = end($end);

                    $newName = "Campo3" . date("YmdHis") . "." . $extensao;

                    $target = $dir . $newName;
                    $targetBD = $dir1 . $newName;

                    $flag = move_uploaded_file($fonte, $target);

                }
            }
        }
        return (
            json_encode(
                array(
                    "flag" => $flag,
                    "target" => $targetBD
                )
            )
        );


    }


}
?>