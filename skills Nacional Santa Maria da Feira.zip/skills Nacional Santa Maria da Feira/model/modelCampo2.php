<?php

require_once 'connection.php';

class Medico
{

    // ################################ REGISTO ################################ //

    function registarMedico($nCedula, $nome, $nif, $codPostal, $morada, $nacionalidade, $dataNasc, $email, $tel)
    {
        global $conn;
        $msg = "";
        $flag = true;

        if ($flag) {
            $sql = "INSERT INTO medico (nCedula, nome, nif, codPostal, morada, nacionalidade, dataNascimento, email, tel) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            if ($stmt_insert = $conn->prepare($sql)) {
                $stmt_insert->bind_param("sssssssss", $nCedula, $nome, $nif, $codPostal, $morada, $nacionalidade, $dataNasc, $email, $tel);
                if ($stmt_insert->execute()) {
                    $msg = "Registrado com sucesso!";
                } else {
                    $flag = false;
                    $msg = "Erro: " . $stmt_insert->error;
                }
                $stmt_insert->close();
            } else {
                $flag = false;
                $msg = "Erro: " . $conn->error;
            }
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return $resp;
    }


    // ################################ LISTAGEM ################################ //
    function getListagemMedicos()
    {
        global $conn;
        $msg = "";

        $stmt = $conn->prepare("SELECT * FROM medico");
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['nCedula'] . "</th>";
                $msg .= "<th scope='row'>" . $row['nome'] . "</th>";
                $msg .= "<th scope='row'>" . $row['nif'] . "</th>";
                $msg .= "<th scope='row'>" . $row['tel'] . "</th>";
                $msg .= "<td><button class='btn btn-info' onclick='infoMedico(" . $row['nCedula'] . ")'><i class='fas fa-info'></i></button></td>";
                $msg .= "<td><button class='btn btn-danger' onclick='removerMedico(" . $row['nCedula'] . ")'><i class='fas fa-trash'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td colspan='4'>Sem Registos</td>";
            $msg .= "</tr>";
        }

        $stmt->close();
        $conn->close();

        return $msg;
    }

    // ################################ REMOVER ################################ //
    function removerMedico($nCedula)
    {
        global $conn;
        $flag = false;
        $msg = "";


        $sql = "DELETE FROM medico WHERE nCedula = ?";
        if ($stmt2 = $conn->prepare($sql)) {
            $stmt2->bind_param("i", $nCedula);
            if ($stmt2->execute()) {
                $msg = "Removido com sucesso!";
                $flag = true;
            } else {
                $msg = "Erro ao remover o registro: " . $stmt2->error;
            }
            $stmt2->close();
        } else {
            $msg = "Erro: " . $conn->error;
        }



        $conn->close();

        return json_encode(array("flag" => $flag, "msg" => $msg));
    }


    // ################################ EDITAR ################################ //
    function infoAgendamento($idAgendamento)
    {
        global $conn;
        $msg = "";
        $total = 0;

        $sql = "SELECT passageiros.nome, passageiros.idade, lugares.descricao AS lugares, destino.valor AS valorDestino
                FROM passageiros
                JOIN lugares ON passageiros.id_lugar = lugares.id
                JOIN agendamento ON passageiros.id_agendamento = agendamento.id
                JOIN voo ON agendamento.id_voo = voo.id
                JOIN destino ON voo.id_destino = destino.id
                WHERE passageiros.id_agendamento = ?";

        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("i", $idAgendamento);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $msg .= "<tr>";
                    $msg .= "<th scope='row'>" . htmlspecialchars($row['nome']) . "</th>";
                    $msg .= "<td>" . htmlspecialchars($row['idade']) . "</td>";
                    $msg .= "<td>" . htmlspecialchars($row['lugares']) . "</td>";
                    $msg .= "</tr>";
                    $total += $row['valorDestino']; // Adiciona o valor do destino ao total
                }
            } else {
                $msg .= "<tr>";
                $msg .= "<td>Sem Registos</td>";
                $msg .= "<th scope='row'></th>";
                $msg .= "<td></td>";
                $msg .= "<td></td>";
                $msg .= "<td></td>";
                $msg .= "<td></td>";
                $msg .= "<td></td>";
                $msg .= "<td></td>";
                $msg .= "</tr>";
            }

            $stmt->close();
        } else {
            $msg .= "<tr>";
            $msg .= "<td colspan='3'>Erro na consulta: " . $conn->error . "</td>";
            $msg .= "</tr>";
        }

        // Atualiza o estado do agendamento para 1 (bloqueado)
        $sqlUpdateEstado = "UPDATE voo SET estado = 1 WHERE id = ?";
        if ($stmtUpdateEstado = $conn->prepare($sqlUpdateEstado)) {
            $stmtUpdateEstado->bind_param("i", $idAgendamento);
            $stmtUpdateEstado->execute();
            $stmtUpdateEstado->close();
        } else {
            $msg .= "<tr>";
            $msg .= "<td colspan='3'>Erro ao atualizar estado: " . $conn->error . "</td>";
            $msg .= "</tr>";
        }

        // Atualiza o valor total do agendamento
        $sqlUpdateValorTotal = "UPDATE agendamento SET valor_total = ? WHERE id = ?";
        if ($stmtUpdateValorTotal = $conn->prepare($sqlUpdateValorTotal)) {
            $stmtUpdateValorTotal->bind_param("di", $total, $idAgendamento);
            $stmtUpdateValorTotal->execute();
            $stmtUpdateValorTotal->close();
        } else {
            $msg .= "<tr>";
            $msg .= "<td colspan='3'>Erro ao atualizar valor total: " . $conn->error . "</td>";
            $msg .= "</tr>";
        }

        $conn->close();

        // Gera a listagem dos passageiros
        $passageiros = []; // Supondo que $passageiros é um array que você irá preencher
        $dir = "../listagem/";
        // Cria o diretório se não existir
        if (!is_dir($dir)) {
            if (!mkdir($dir, 0777, true)) {
                die("Erro: não é possível criar o diretório de listagem.");
            }
        }
        // Gera o nome do arquivo
        $filename = 'listagem_' . date('YmdHis') . '.txt';
        $filepath = $dir . $filename;
        // Conteúdo do arquivo de texto
        $textContent = "Listagem: $idAgendamento\n\n";
        $textContent .= "Nome\t\tIdade\t\tLugar\n";
        $textContent .= str_repeat("=", 40) . "\n";

        foreach ($passageiros as $passageiro) {
            $textContent .= $passageiro['nome'] . "\t\t" . $passageiro['idade'] . "\t\t" . $passageiro['lugares'] . "\n";
        }

        // Escreve o conteúdo no arquivo
        if (file_put_contents($filepath, $textContent) !== false) {
            $msg .= "<tr><td colspan='3'>Listagem gerada em: $filepath</td></tr>";
        } else {
            $msg .= "<tr><td colspan='3'>Erro ao gerar a listagem</td></tr>";
        }

        return $msg;
    }

    function editarMedico($nCedula)
    {
        global $conn;
        $row = "";

        $sql = "SELECT * FROM medico WHERE nCedula =" . $nCedula;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function guardaEditMedico($nCedula, $nome, $nif, $codPostal, $morada, $nacionalidade, $email, $tel, $nCedulaOld)
    {
        global $conn;
        $msg = "";
        $flag = true;

        if ($flag) {
            $sql = "UPDATE medico SET nCedula = ?, nome = ?, nif = ?, codPostal = ?, morada = ?, nacionalidade = ?, email = ?, tel = ? 
                WHERE nCedula = ?";

            if ($stmt2 = $conn->prepare($sql)) {
                $stmt2->bind_param("ssssssssi", $nCedula, $nome, $nif, $codPostal, $morada, $nacionalidade, $email, $tel, $nCedulaOld);
                if ($stmt2->execute()) {
                    $msg = "Editado com sucesso!";
                } else {
                    $flag = false;
                    $msg = "Erro ao editar: " . $stmt2->error;
                }
                $stmt2->close();
            } else {
                $flag = false;
                $msg = "Erro: " . $conn->error;
            }
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return $resp;
    }


    // ################################ GETS ################################ //

    function getMedico()
    {
        global $conn;
        $msg = "<option selected>Escolha um Médico</option>";

        $sql = "SELECT * FROM medico";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['nCedula'] . "'>" . $row['nome'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Médicos registados</option>";

        }
        $conn->close();

        return ($msg);
    }


}
?>