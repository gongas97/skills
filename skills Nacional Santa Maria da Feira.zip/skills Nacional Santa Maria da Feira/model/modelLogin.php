<?php

require_once 'connection.php';

session_start();

if (isset($_SESSION['idAdmin'])) {
    $idAdmin = $_SESSION['idAdmin'];
} else {
    $idAdmin = null;
}

function getWindowsLocalIP()
{
    // Execute the `ipconfig` command and capture the output
    $ipConfigOutput = shell_exec('ipconfig');

    // Look for the line containing "IPv4 Address" or "Endereço IPv4" (in Portuguese systems)
    if (preg_match('/IPv4[^:]+:\s*([0-9.]+)/', $ipConfigOutput, $matches)) {
        // Return only the digits of the matched IP address
        return $matches[1];
    } else {
        return 'IP Address not found';
    }
}


$localIP = getWindowsLocalIP();

class Login
{
    function logout()
    {

        session_destroy();

        return ("Obrigado!");
    }


    /*PRODUTORAS*/

    function registar3($nomeProdutora, $moradaFiscal, $paisOrigem, $foto1, $historia, $foto2, $usernameP, $passwordP)
    {
        global $conn;
        $msg = "";
        $flag = true;

        // Encriptação da senha
        $passwordP = md5($passwordP);

        // Upload das fotos
        $comprovativoFiscal = null;
        $logo = null;

        // Verificação do primeiro upload (comprovativo fiscal)
        if ($foto1) {
            $resp1 = $this->uploads1($foto1, $nomeProdutora);
            $resp1 = json_decode($resp1, TRUE);
            if ($resp1['flag']) {
                $comprovativoFiscal = $resp1['target']; // Caminho do comprovativo fiscal
            }
        }

        // Verificação do segundo upload (logo)
        if ($foto2) {
            $resp2 = $this->uploads2($foto2, $nomeProdutora);
            $resp2 = json_decode($resp2, TRUE);
            if ($resp2['flag']) {
                $logo = $resp2['target']; // Caminho do logo
            }
        }

        // Definindo a query SQL com ou sem fotos
        if ($comprovativoFiscal && $logo) {
            $sql = "INSERT INTO produtora (nomeProdutora, moradaFiscal, paisOrigem, comprovativoFiscal, historia, logo, usernameP, passwordP) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssss", $nomeProdutora, $moradaFiscal, $paisOrigem, $comprovativoFiscal, $historia, $logo, $usernameP, $passwordP);
        } elseif ($comprovativoFiscal) {
            $sql = "INSERT INTO produtora (nomeProdutora, moradaFiscal, paisOrigem, comprovativoFiscal, historia, usernameP, passwordP) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssss", $nomeProdutora, $moradaFiscal, $paisOrigem, $comprovativoFiscal, $historia, $usernameP, $passwordP);
        } elseif ($logo) {
            $sql = "INSERT INTO produtora (nomeProdutora, moradaFiscal, paisOrigem, historia, logo, usernameP, passwordP) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssss", $nomeProdutora, $moradaFiscal, $paisOrigem, $historia, $logo, $usernameP, $passwordP);
        } else {
            $sql = "INSERT INTO produtora (nomeProdutora, moradaFiscal, paisOrigem, historia, usernameP, passwordP) 
                VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssss", $nomeProdutora, $moradaFiscal, $paisOrigem, $historia, $usernameP, $passwordP);
        }

        // Executa a query e verifica se houve sucesso
        if ($stmt->execute()) {
            $msg = "Registrado com sucesso! Aguarde Aprovação do Administrador.";
        } else {
            $flag = false;
            $msg = "Erro: " . $stmt->error;
        }

        // Atualizar fotos, se necessário
        if ($comprovativoFiscal || $logo) {
            $resUpdate = $this->updateFotos($comprovativoFiscal, $logo, $nomeProdutora);
            $resUpdate = json_decode($resUpdate, TRUE);
            if (!$resUpdate['flag']) {
                $flag = false;
                $msg = "Erro ao atualizar fotos: " . $resUpdate['msg'];
            }
        }

        // Fechar statement e conexão
        $stmt->close();
        $conn->close();

        // Retorna a resposta em formato JSON
        return json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
    }

    function login3($usernameP, $pwP)
    {

        global $conn;
        $msg = "";
        $flag = true;

        // Encriptação da senha
        $pwP = md5($pwP);

        // Consulta com prepared statement
        $stmt = $conn->prepare("SELECT * FROM produtora WHERE usernameP = ? AND passwordP = ?;");
        $stmt->bind_param("ss", $usernameP, $pwP);
        $stmt->execute();

        // Obtém o resultado da consulta
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Se o login for bem-sucedido
            $row = $result->fetch_assoc();

            if ($row['status'] === 'Ativo') {

                $msg = "Bem-vindo " . $row['usernameP'];
                $_SESSION['produtora'] = $row['usernameP'];
                $_SESSION['idProdutora'] = $row['idProdutora'];
                $_SESSION['logo'] = $row['logo'];
            } else {
                // Se o status não for 'ativo', bloqueia o login
                $flag = false;
                $msg = "O reu registo ainda não foi aceite. Para esclarecer dúvidas, contacte o administrador.";
            }
        } else {
            // Login falhou
            $flag = false;
            $msg = "Erro! Dados Inválidos";
        }
        // Fechar statement e conexão
        $stmt->close();
        $conn->close();

        // Retorna a resposta em formato JSON
        return json_encode(array(
            "msg" => $msg,
            "flag" => $flag
        ));
    }

    function updateFotos($diretorioComprovativo, $diretorioLogo, $id)
    {
        global $conn;
        $msg = "";
        $flag = true;

        // Usando prepared statement para atualizar dois campos (comprovativoFiscal e logo)
        $sql = "UPDATE produtora SET comprovativoFiscal = ?, logo = ? WHERE idProdutora = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $diretorioComprovativo, $diretorioLogo, $id);

        // Verifica se a execução foi bem-sucedida
        if ($stmt->execute()) {
            $msg = "Atualização bem-sucedida";
        } else {
            $flag = false;
            $msg = "Erro: " . $stmt->error;
        }

        $stmt->close();

        // Retorna a resposta em formato JSON
        $response = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));

        return $response;
    }

    function uploads1($img, $nomeProdutora)
    {

        $dir = "../imagens/UserProdutoras/ComprovativoFiscal_" . $nomeProdutora . "/";
        $dir1 = "imagens/UserProdutoras/ComprovativoFiscal_" . $nomeProdutora . "/";
        $flag = false;
        $targetBD = "";

        if (!is_dir($dir)) {
            if (!mkdir($dir, 0777, TRUE)) {
                die("Erro não é possivel criar o diretório");
            }
        }
        if (array_key_exists('foto', $img)) {
            if (is_array($img)) {
                if (is_uploaded_file($img['foto']['tmp_name'])) {
                    $fonte = $img['foto']['tmp_name'];
                    $ficheiro = $img['foto']['name'];
                    $end = explode(".", $ficheiro);
                    $extensao = end($end);

                    $newName = "ComprovativoFiscal" . date("YmdHis") . "." . $extensao;

                    $target = $dir . $newName;
                    $targetBD = $dir1 . $newName;

                    $flag = move_uploaded_file($fonte, $target);

                }
            }
        }
        return (json_encode(array(
            "flag" => $flag,
            "target" => $targetBD
        )));


    }

    function uploads2($img, $nomeProdutora)
    {

        $dir = "../imagens/UserProdutoras/Logotipo_" . $nomeProdutora . "/";
        $dir1 = "imagens/UserProdutoras/Logotipo_" . $nomeProdutora . "/";
        $flag = false;
        $targetBD = "";

        if (!is_dir($dir)) {
            if (!mkdir($dir, 0777, TRUE)) {
                die("Erro não é possivel criar o diretório");
            }
        }
        if (array_key_exists('foto', $img)) {
            if (is_array($img)) {
                if (is_uploaded_file($img['foto2']['tmp_name'])) {
                    $fonte = $img['foto2']['tmp_name'];
                    $ficheiro = $img['foto2']['name'];
                    $end = explode(".", $ficheiro);
                    $extensao = end($end);

                    $newName = "Logotipo" . date("YmdHis") . "." . $extensao;

                    $target = $dir . $newName;
                    $targetBD = $dir1 . $newName;

                    $flag = move_uploaded_file($fonte, $target);

                }
            }
        }
        return (json_encode(array(
            "flag" => $flag,
            "target" => $targetBD
        )));


    }

    /* USER */

    function registar2($nomeUser, $emailUser, $nifUser, $pergunta1, $resposta1, $pergunta2, $resposta2, $username, $password, $foto = null)
    {
        global $conn;
        $msg = "";
        $flag = true;

        // Encriptação da senha
        $password = md5($password);

        // Verificação do upload (foto)
        if ($foto) {
            $resp1 = $this->uploads3($foto, $nomeUser);
            $resp1 = json_decode($resp1, TRUE);
            if ($resp1['flag']) {
                $foto = $resp1['target']; // Caminho do comprovativo fiscal
            } else {
                $flag = false;
                $msg = "Erro ao fazer upload da foto.";
                return json_encode(array("flag" => $flag, "msg" => $msg));
            }
        }

        // Definindo a query SQL com ou sem fotos
        if ($foto) {
            $sql = "INSERT INTO user (nomeUser, emailUser, nifUser, pergunta1, resposta1, pergunta2, resposta2, username, password, foto) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssssss", $nomeUser, $emailUser, $nifUser, $pergunta1, $resposta1, $pergunta2, $resposta2, $username, $password, $foto);
        } else {
            $sql = "INSERT INTO user (nomeUser, emailUser, nifUser, pergunta1, resposta1, pergunta2, resposta2, username, password) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssssss", $nomeUser, $emailUser, $nifUser, $pergunta1, $resposta1, $pergunta2, $resposta2, $username, $password);
        }

        // Executa a query e verifica se houve sucesso
        if ($stmt->execute()) {
            $msg = "Registrado com sucesso!";
        } else {
            $flag = false;
            $msg = "Erro: " . $stmt->error;
        }

        // Atualizar fotos, se necessário
        if ($flag && $foto) {
            $resUpdate = $this->updateFotos1($foto, $nomeUser);
            $resUpdate = json_decode($resUpdate, TRUE);
            if (!$resUpdate['flag']) {
                $flag = false;
                $msg = "Erro ao atualizar fotos: " . $resUpdate['msg'];
            }
        }

        // Fechar statement e conexão
        $stmt->close();
        $conn->close();

        // Retorna a resposta em formato JSON
        return json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
    }

    function verificarPerguntas($username)
    {
        global $conn;

        $response = ["flag" => false, "msg" => ""]; // Inicializa a estrutura de resposta

        // Consulta para verificar se o username existe
        $sql = "SELECT idUser, pergunta1, pergunta2 FROM user WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Se o username existe, busca as perguntas
            $row = $result->fetch_assoc();
            $response["flag"] = true;
            $response["msg"] = [
                "idUser" => $row['idUser'],
                "pergunta1" => $row['pergunta1'],
                "pergunta2" => $row['pergunta2']
            ];
        } else {
            // Se o username não existe
            $response["msg"] = "Username não encontrado";
        }

        // Fecha a declaração
        $stmt->close();

        // Retorna a resposta em formato JSON
        return json_encode($response);
    }

    function responderPerguntas($resposta1, $resposta2, $idUser)
    {
        global $conn;

        $response = ["flag" => false, "msg" => ""]; // Initialize response structure

        // Query to check if idUser exists and fetch stored answers
        $sql = "SELECT idUser, resposta1, resposta2 FROM user WHERE idUser = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $idUser); // Assuming idUser is an integer
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // If idUser exists, fetch the stored answers
            $row = $result->fetch_assoc();

            // Log stored and provided answers for debugging
            error_log("Stored Resposta 1: " . $row['resposta1']);
            error_log("Stored Resposta 2: " . $row['resposta2']);
            error_log("User Resposta 1: " . $resposta1);
            error_log("User Resposta 2: " . $resposta2);

            // Compare provided answers with stored answers
            if (
                trim(strtolower($row['resposta1'])) === trim(strtolower($resposta1)) &&
                trim(strtolower($row['resposta2'])) === trim(strtolower($resposta2))
            ) {
                // If the answers are correct
                $response["flag"] = true;
                $response["msg"] = "Respostas Corretas, Escolhe agora a tua nova Password."; // Success message
            } else {
                // If the answers are incorrect
                $response["msg"] = "Respostas incorretas";
            }
        } else {
            // If idUser was not found
            $response["msg"] = "Username não encontrado"; // Detailed message
        }

        // Close the statement
        $stmt->close();

        // Return the response as JSON
        return json_encode($response);
    }


    function recuperarPassword($newPassword1, $newPassword2, $idUser)
    {
        global $conn;

        $response = ["flag" => false, "msg" => ""]; // Inicializa a estrutura de resposta

        // Verifica se as senhas coincidem
        if ($newPassword1 === $newPassword2) {
            // Criptografa a senha com MD5
            $encryptedPassword = md5($newPassword1);

            // Prepara a instrução SQL para atualizar a senha e o estado
            $sql = "UPDATE user SET password = ?, estado = 'Ativo' WHERE idUser = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $encryptedPassword, $idUser); // Liga a senha criptografada e o idUser

            // Executa a atualização e verifica se foi bem-sucedida
            if ($stmt->execute()) {
                $response["flag"] = true;
                $response["msg"] = "Senha atualizada com sucesso.";
            } else {
                $response["msg"] = "Erro ao atualizar a senha. Tente novamente.";
            }

            // Fecha a declaração
            $stmt->close();
        } else {
            // Se as senhas não coincidirem
            $response["msg"] = "As senhas não coincidem. Tente novamente.";
        }

        // Retorna a resposta em formato JSON
        return json_encode($response);
    }


    function login2($username, $pw)
    {
        global $conn, $localIP;
        $msg = "";
        $flag = true;

        // Encriptação da senha
        $pw = md5($pw);
        $hora = date("Y-m-d H:i:s");
        $tentativasFalhas = 3;

        // Consulta com prepared statement
        $stmt = $conn->prepare("SELECT * FROM user WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            // Verifica se a conta está ativa
            if ($row['estado'] === 'Ativo') {
                // Verifica a senha
                if ($row['password'] === $pw) {
                    $msg = "Bem-vindo " . $row['username'];
                    $_SESSION['user'] = $row['username'];
                    $_SESSION['idUser'] = $row['idUser'];
                    $_SESSION['foto'] = $row['foto'];

                    // Registra tentativa bem-sucedida
                    $stmtLog = $conn->prepare("INSERT INTO login (idUser, hora, ipOrigem, estado) VALUES (?, ?, ?, 'Sucesso')");
                    $stmtLog->bind_param("iss", $row['idUser'], $hora, $localIP);
                    $stmtLog->execute();
                } else {
                    // Login falhou: registra a tentativa e verifica o número de falhas
                    $stmtLog = $conn->prepare("INSERT INTO login (idUser, hora, ipOrigem, estado) VALUES (?, ?, ?, 'Falha')");
                    $stmtLog->bind_param("iss", $row['idUser'], $hora, $localIP);
                    $stmtLog->execute();

                    // Conta tentativas falhadas
                    $stmtFalhas = $conn->prepare("SELECT COUNT(*) as totalFalhas FROM login WHERE idUser = ? AND estado = 'Falha' AND hora > (NOW() - INTERVAL 1 HOUR)");
                    $stmtFalhas->bind_param("i", $row['idUser']);
                    $stmtFalhas->execute();
                    $resultFalhas = $stmtFalhas->get_result();
                    $totalFalhas = $resultFalhas->fetch_assoc()['totalFalhas'];

                    // Calcula tentativas restantes
                    $tentativasRestantes = $tentativasFalhas - $totalFalhas;

                    if ($totalFalhas >= $tentativasFalhas) {
                        // Bloqueia a conta após três tentativas falhadas
                        $stmtBloqueio = $conn->prepare("UPDATE user SET estado = 'Bloqueado' WHERE idUser = ?");
                        $stmtBloqueio->bind_param("i", $row['idUser']);
                        $stmtBloqueio->execute();

                        // Registra o bloqueio
                        $stmtLog = $conn->prepare("INSERT INTO login (idUser, hora, ipOrigem, estado) VALUES (?, ?, ?, 'Conta bloqueada')");
                        $stmtLog->bind_param("iss", $row['idUser'], $hora, $localIP);
                        $stmtLog->execute();

                        $msg = "A sua conta foi bloqueada devido a múltiplas tentativas falhadas. Para ativar a conta novamente, carregue em 'Esqueci-me da Password'.";
                        $flag = false;
                    } else {
                        // Mostra mensagem de erro com tentativas restantes
                        $msg = "Erro! Dados Inválidos. Tentativas restantes: $tentativasRestantes.";
                        $flag = false;
                    }
                }
            } else {
                $msg = "A sua conta está bloqueada. Carregue em 'Esqueci-me da Password' para recuperar a senha.";
                $flag = false;
            }
        } else {
            $msg = "Erro! Dados Inválidos.";
            $flag = false;
        }

        // Fechar statement e conexão
        $stmt->close();
        $conn->close();

        return json_encode(array(
            "msg" => $msg,
            "flag" => $flag
        ));
    }



    function updateFotos1($diretoriofoto, $id)
    {
        global $conn;
        $msg = "";
        $flag = true;

        // Usando prepared statement para atualizar dois campos
        $sql = "UPDATE user SET foto = ? WHERE idUser = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $diretoriofoto, $id);

        // Verifica se a execução foi bem-sucedida
        if ($stmt->execute()) {
            $msg = "Atualização bem-sucedida";
        } else {
            $flag = false;
            $msg = "Erro: " . $stmt->error;
        }

        $stmt->close();

        // Retorna a resposta em formato JSON
        $response = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));

        return $response;
    }

    function uploads3($foto, $nomeUser)
    {

        $dir = "../imagens/User/Foto_" . $nomeUser . "/";
        $dir1 = "imagens/User/Foto_" . $nomeUser . "/";
        $flag = false;
        $targetBD = "";

        if (!is_dir($dir)) {
            if (!mkdir($dir, 0777, TRUE)) {
                die("Erro não é possivel criar o diretório");
            }
        }
        if (array_key_exists('foto', $foto)) {
            if (is_array($foto)) {
                if (is_uploaded_file($foto['foto']['tmp_name'])) {
                    $fonte = $foto['foto']['tmp_name'];
                    $ficheiro = $foto['foto']['name'];
                    $end = explode(".", $ficheiro);
                    $extensao = end($end);

                    $newName = "Foto" . date("YmdHis") . "." . $extensao;

                    $target = $dir . $newName;
                    $targetBD = $dir1 . $newName;

                    $flag = move_uploaded_file($fonte, $target);

                }
            }
        }
        return (json_encode(array(
            "flag" => $flag,
            "target" => $targetBD
        )));


    }

    function uploads4($img, $nomeAnunciante)
    {

        $dir = "../imagens/UserAnunciantes/Logo_" . $nomeAnunciante . "/";
        $dir1 = "imagens/UserAnunciantes/Logo_" . $nomeAnunciante . "/";
        $flag = false;
        $targetBD = "";

        if (!is_dir($dir)) {
            if (!mkdir($dir, 0777, TRUE)) {
                die("Erro não é possivel criar o diretório");
            }
        }
        if (array_key_exists('foto1', $img)) {
            if (is_array($img)) {
                if (is_uploaded_file($img['foto1']['tmp_name'])) {
                    $fonte = $img['foto1']['tmp_name'];
                    $ficheiro = $img['foto1']['name'];
                    $end = explode(".", $ficheiro);
                    $extensao = end($end);

                    $newName = "Logo" . date("YmdHis") . "." . $extensao;

                    $target = $dir . $newName;
                    $targetBD = $dir1 . $newName;

                    $flag = move_uploaded_file($fonte, $target);

                }
            }
        }
        return (json_encode(array(
            "flag" => $flag,
            "target" => $targetBD
        )));


    }

    // ADMIN //

    function loginAdmin($username, $pw)
    {

        global $conn;
        $msg = "";
        $flag = true;

        $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ? AND password = ?");
        $stmt->bind_param("ss", $username, $pw);

        if ($stmt->execute()) {
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $msg = "Bem-vindo " . $row['username'];
                $_SESSION['admin'] = $row['username'];
                $_SESSION['idAdmin'] = $row['idAdmin'];

                // Send the confirmation message to the frontend
                $msg = "Login Confirmado com sucesso.";
                return json_encode(array(
                    "msg" => $msg,
                    "flag" => true
                ));
            } else {
                $flag = false;
                $msg = "Erro! Dados Inválidos";
            }
        } else {
            $msg = "Erro na execução da consulta: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();

        return json_encode(array(
            "msg" => $msg,
            "flag" => $flag
        ));
    }

}

?>