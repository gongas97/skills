<?php

$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "bdclinica_goncaloaraujo";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8
mysqli_set_charset($conn, 'utf8');

?>