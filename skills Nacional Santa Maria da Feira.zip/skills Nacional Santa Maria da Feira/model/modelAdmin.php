<?php

require_once 'connection.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['idAdmin'])) {
    $idAdmin = $_SESSION['idAdmin'];
} else {
    $idAdmin = null;
}

class Admin
{
    // function listaParcerias()
    // {
    //     global $conn; // Ensure the database connection is available globally
    //     $msg = "";

    //     // Query with a condition to show only ads for the logged-in advertiser
    //     $sql = "SELECT aprovarecomendacao.*, anunciante.nomeAnunciante, produtora.nomeAnunciante,  
    //         FROM anuncios 
    //         JOIN anunciante ON anuncios.idAnunciante = anunciante.idAnunciante
    //         JOIN tipoanuncio ON anuncios.idTipAnuncio = tipoanuncio.idTipoAnuncio
    //         WHERE anuncios.idAnunciante = ?";

    //     // Prepare and execute the query
    //     $stmt = $conn->prepare($sql);
    //     $stmt->bind_param("i", $idAnunciante); // Bind the advertiser ID from the session
    //     $stmt->execute();
    //     $result = $stmt->get_result(); // Get the result set

    //     // Check if the query returned any results
    //     if ($result->num_rows > 0) {
    //         // Iterate over the results and build the HTML
    //         while ($row = $result->fetch_assoc()) {
    //             $msg .= "<tr>";
    //             $msg .= "<td>" . $row['idAnuncio'] . "</td>";
    //             $msg .= "<td>" . $row['descricaoTipoAnuncio'] . "</td>";
    //             $msg .= "<td><img class='img-thumbnail' src='" . $row['foto'] . "'></td>";
    //             $msg .= "<td>" . $row['estado'] . "</td>";
    //             $msg .= "<td><button type='button' class='btn btn-primary' onclick='editFuncionario(" . $row['idAnuncio'] . ")'>Editar</button></td>";
    //             $msg .= "<td><button type='button' class='btn btn-primary' onclick='removeFuncionario(" . $row['idAnuncio'] . ")'>Apagar</button></td>";
    //             $msg .= "</tr>";
    //         }
    //     } else {
    //         // If no results, display a "No results" row
    //         $msg .= "<tr>";
    //         $msg .= "<th scope='row'> Sem resultados</th>";
    //         $msg .= "<td colspan='6'></td>"; // Fill the remaining columns
    //         $msg .= "</tr>";
    //     }

    //     $conn->close(); // Close the database connection
    //     return $msg;    // Return the generated HTML
    // }

    // function getAnunciantesMensagens($idAdmin)
    // {
    //     global $conn;
    //     $anunciantes = [];

    //     // A consulta busca anunciantes com mensagens e conta quantas delas estão com estado "não lido" (estado = 2)
    //     $sql = "SELECT a.idAnunciante, a.nomeAnunciante, a.logoAnunciante,
    //                    SUM(CASE WHEN m.estado = 2 THEN 1 ELSE 0 END) AS unreadCount
    //             FROM anunciante a
    //             JOIN mensagensAdmin m ON m.idAnunciante = a.idAnunciante
    //             WHERE m.idAdmin = ?
    //             GROUP BY a.idAnunciante, a.nomeAnunciante, a.logoAnunciante";

    //     $stmt = $conn->prepare($sql);
    //     $stmt->bind_param("i", $idAdmin); // Ajuste para usar $idAdmin
    //     $stmt->execute();
    //     $result = $stmt->get_result();

    //     // Armazena cada anunciante com a contagem de mensagens não lidas
    //     while ($row = $result->fetch_assoc()) {
    //         $anunciantes[] = $row;
    //     }

    //     $stmt->close();
    //     return $anunciantes;
    // }

    // function getProdutorasMensagens($idAnun)
    // {
    //     global $conn;
    //     $produtoras = [];

    //     // A consulta busca produtoras com mensagens e conta quantas delas estão com estado "não lido" (estado = 2)
    //     $sql = "SELECT p.idProdutora, p.nomeProdutora, p.logo,
    //                SUM(CASE WHEN m.estado = 2 THEN 1 ELSE 0 END) AS unreadCount
    //         FROM produtora p
    //         JOIN mensagensAdmin m ON m.idProdutora = p.idProdutora
    //         WHERE m.idAdmin = ?
    //         GROUP BY p.idProdutora, p.nomeProdutora, p.logo";

    //     $stmt = $conn->prepare($sql);
    //     $stmt->bind_param("i", $idAnun); // Ajuste para usar $idAdmin
    //     $stmt->execute();
    //     $result = $stmt->get_result();

    //     // Armazena cada produtora com a contagem de mensagens não lidas
    //     while ($row = $result->fetch_assoc()) {
    //         $produtoras[] = $row;
    //     }

    //     $stmt->close();
    //     return $produtoras;
    // }

    // function getConversaAnunciantes($idAnunciante)
    // {
    //     global $conn, $idAdmin; // Certifique-se de que $idAdmin esteja disponível
    //     $msg = "";

    //     // Atualiza o estado das mensagens para 2 (lidas) quando a conversa for aberta
    //     $sqlUpdate = "UPDATE mensagensadmin 
    //           SET estado = 2 
    //           WHERE idAnunciante = ? AND idAdmin = ? AND estado = 1";
    //     $stmtUpdate = $conn->prepare($sqlUpdate);
    //     $stmtUpdate->bind_param("ii", $idAnunciante, $idAdmin); // Parametros: idAnunciante e idAdmin
    //     $stmtUpdate->execute();
    //     $stmtUpdate->close();

    //     // SQL para buscar mensagens e respostas em ordem cronológica
    //     $sql = "
    //     (SELECT m.idMensagem, m.mensagem AS conteudo, m.dataEnvioMensagem AS dataHora, 'enviada' AS tipo, a.nomeAnunciante, a.logoAnunciante
    //     FROM mensagensadmin m
    //     JOIN anunciante a ON m.idAnunciante = a.idAnunciante
    //     WHERE m.idAnunciante = ? AND m.idAdmin = ?)
    
    //     UNION
    
    //     (SELECT r.idMensagemOriginal AS idMensagem, r.mensagemResposta AS conteudo, r.dataResposta AS dataHora, 'respondida' AS tipo, '' AS nomeAnunciante, '' AS logo
    //     FROM respostamensagensadmin r
    //     JOIN mensagensadmin m ON r.idMensagemOriginal = m.idMensagem
    //     WHERE m.idAnunciante = ? AND m.idAdmin = ?)
    
    //     ORDER BY dataHora ASC";  // Ordena pela data e hora

    //     $stmt = $conn->prepare($sql);
    //     $stmt->bind_param("iiii", $idAnunciante, $idAdmin, $idAnunciante, $idAdmin); // Parametros para as duas partes da consulta
    //     $stmt->execute();
    //     $result = $stmt->get_result();

    //     // Verifica se há mensagens
    //     if ($result->num_rows > 0) {
    //         // Obtém os dados do anunciante (a partir da primeira mensagem)
    //         $row = $result->fetch_assoc();
    //         $nome = htmlspecialchars($row['nomeAnunciante']);
    //         $logo = htmlspecialchars($row['logoAnunciante']);
    //         $idMensagemOriginal = htmlspecialchars($row['idMensagem']);

    //         // Criação do cabeçalho do chat
    //         $msg .= "
    //         <div class='chat-header clearfix'>
    //             <div class='row'>
    //                 <div class='col-lg-6'>
    //                     <img src='$logo' alt='avatar' id='avatarSelecionado'>
    //                     <div class='chat-about'>
    //                         <h6 class='m-b-0' id='nomeAnuncianteSelecionado'>$nome</h6>
    //                     </div>
    //                 </div>
    //             </div>
    //         </div>
    
    //         <div class='chat-history'>
    //             <ul class='m-b-0' id='chatHistory'>";

    //         // Loop para adicionar todas as mensagens e respostas
    //         do {
    //             $conteudo = htmlspecialchars($row['conteudo']);
    //             $dataHora = htmlspecialchars($row['dataHora']);
    //             $tipo = $row['tipo'];

    //             // Verifica se é uma mensagem enviada ou respondida
    //             if ($tipo == 'enviada') {
    //                 $msg .= "<li class='clearfix'>
    //                             <div class='message other-message'>
    //                                 $conteudo 
    //                                 <span class='message-time'>$dataHora</span>
    //                             </div>
    //                           </li>";
    //             } else {
    //                 $msg .= "<li class='clearfix'>
    //                             <div class='message my-message float-right'>
    //                                 $conteudo 
    //                                 <span class='message-time'>$dataHora</span>
    //                             </div>
    //                           </li>";
    //             }
    //         } while ($row = $result->fetch_assoc());

    //         $msg .= "
    //             </ul>
    //         </div>
    
    //         <div class='chat-message clearfix'>
    //             <div class='input-group mb-0'>
    //                 <input type='text' id='mensagemInput2' class='form-control' placeholder='Digite sua mensagem...'>
    //                 <div class='input-group-append'>
    //                     <button class='btn btn-primary' id='enviarMensagemBtn' onclick='enviarMensagemAnunciante($idMensagemOriginal)'>Enviar</button>
    //                 </div>
    //             </div>
    //         </div>";
    //     } else {
    //         // Mensagem padrão quando não há mensagens
    //         $msg .= "<div class='col'>Nenhuma mensagem encontrada.</div>";
    //     }

    //     $stmt->close();
    //     return $msg;
    // }

    // function getConversaProdutora($idProdutora)
    // {
    //     global $conn, $idAdmin; // Certifique-se de que $idAnunciante esteja disponível
    //     $msg = "";

    //     // Atualiza o estado das mensagens para 2 quando a conversa for aberta
    //     $sqlUpdate = "UPDATE mensagensadmin SET estado = 2 WHERE idProdutora = ? AND idAdmin = ? AND estado = 1";
    //     $stmtUpdate = $conn->prepare($sqlUpdate);
    //     $stmtUpdate->bind_param("ii", $idProdutora, $idAdmin);
    //     $stmtUpdate->execute();
    //     $stmtUpdate->close();

    //     // SQL para buscar mensagens e respostas em ordem cronológica
    //     $sql = "
    // (SELECT m.idMensagem, m.mensagem AS conteudo, m.dataEnvioMensagem AS dataHora, 'enviada' AS tipo, p.nomeProdutora, p.logo
    // FROM mensagensadmin m
    // JOIN produtora p ON m.idProdutora = p.idProdutora
    // WHERE m.idProdutora = ? AND m.idAdmin = ?)
    
    // UNION
    
    // (SELECT r.idMensagemOriginal AS idMensagem, r.mensagemResposta AS conteudo, r.dataResposta AS dataHora, 'respondida' AS tipo, '' AS nomeProdutora, '' AS logo
    // FROM respostamensagensadmin r
    // JOIN mensagensadmin m ON r.idMensagemOriginal = m.idMensagem
    // WHERE m.idProdutora = ? AND m.idAdmin = ?)
    
    // ORDER BY dataHora ASC";  // Ordena pela data e hora

    //     $stmt = $conn->prepare($sql);
    //     $stmt->bind_param("iiii", $idProdutora, $idAdmin, $idProdutora, $idAdmin); // Parametros para as duas partes da consulta
    //     $stmt->execute();
    //     $result = $stmt->get_result();

    //     // Verifica se há mensagens
    //     if ($result->num_rows > 0) {
    //         // Obtém os dados da produtora (a partir da primeira mensagem)
    //         $row = $result->fetch_assoc();
    //         $nome = htmlspecialchars($row['nomeProdutora']);
    //         $logo = htmlspecialchars($row['logo']);
    //         $idMensagemOriginal = htmlspecialchars($row['idMensagem']);

    //         // Criação do cabeçalho do chat
    //         $msg .= "
    //     <div class='chat-header clearfix'>
    //             <div class='row'>
    //                 <div class='col-lg-6'>
    //                     <img src='$logo' alt='avatar' id='avatarSelecionado'>
    //                     <div class='chat-about'>
    //                         <h6 class='m-b-0' id='nomeAnuncianteSelecionado'>$nome</h6>
    //                     </div>
    //                 </div>
    //             </div>
    //         </div>

    //     <div class='chat-history'>
    //         <ul class='m-b-0' id='chatHistory'>";

    //         // Loop para adicionar todas as mensagens e respostas
    //         do {
    //             $conteudo = htmlspecialchars($row['conteudo']);
    //             $dataHora = htmlspecialchars($row['dataHora']);
    //             $tipo = $row['tipo'];


    //             // Verifica o tipo de mensagem e cria a estrutura HTML
    //             if ($tipo == 'enviada') {
    //                 $msg .= "<li class='clearfix'>
    //                             <div class='message other-message'>
    //                                 $conteudo 
    //                                 <span class='message-time'>$dataHora</span>
    //                             </div>
    //                           </li>";
    //             } else {
    //                 $msg .= "<li class='clearfix'>
    //                             <div class='message my-message float-right'>
    //                                 $conteudo 
    //                                 <span class='message-time'>$dataHora</span>
    //                             </div>
    //                           </li>";
    //             }
    //         } while ($row = $result->fetch_assoc());

    //         $msg .= "
    //         </ul>
    //     </div>

    //     <div class='chat-message clearfix'>
    //         <div class='input-group mb-0'>
    //             <input type='text' id='mensagemInput1' class='form-control' placeholder='Digite sua mensagem...'>
    //             <div class='input-group-append'>
    //                 <button class='btn btn-primary' id='enviarMensagemBtn' onclick='enviarMensagemProdutora($idMensagemOriginal)'>Enviar</button>
    //             </div>
    //         </div>
    //     </div>";
    //     } else {
    //         // Mensagem padrão quando não há mensagens
    //         $msg .= "<div class='col'>Nenhuma mensagem encontrada.</div>";
    //     }

    //     $stmt->close();
    //     return $msg;
    // }

    // function RespostasNaoLidasAnunciante($idAnunciante)
    // {
    //     global $conn;

    //     // SQL para contar mensagens não lidas na tabela MensagensAdmin
    //     $sql = "SELECT COUNT(*) AS unreadCount 
    //     FROM mensagensadmin 
    //     WHERE idAnunciante = ? AND estado = 1";
    //     $stmt = $conn->prepare($sql);

    //     if ($stmt === false) {
    //         return 0; // Se a preparação da consulta falhar, retorne 0
    //     }

    //     $stmt->bind_param("i", $idAnunciante);
    //     $stmt->execute();
    //     $result = $stmt->get_result();

    //     // Verifica o resultado
    //     if ($row = $result->fetch_assoc()) {
    //         $unreadCount = $row['unreadCount'];
    //     } else {
    //         $unreadCount = 0; // Se não houver respostas não lidas, retorna 0
    //     }

    //     $stmt->close();
    //     return $unreadCount;
    // }

    // function RespostasNaoLidasProdutora($idProdutora)
    // {
    //     global $conn;

    //     // SQL para contar mensagens não lidas na tabela MensagensAdmin
    //     $sql = "SELECT COUNT(*) AS unreadCount 
    //     FROM mensagensadmin 
    //     WHERE idProdutora = ? AND estado = 1";

    //     $stmt = $conn->prepare($sql);

    //     if ($stmt === false) {
    //         return 0; // Se a preparação da consulta falhar, retorne 0
    //     }

    //     $stmt->bind_param("i", $idProdutora);
    //     $stmt->execute();
    //     $result = $stmt->get_result();

    //     // Verifica o resultado
    //     if ($row = $result->fetch_assoc()) {
    //         $unreadCountProdutora = $row['unreadCount'];
    //     } else {
    //         $unreadCountProdutora = 0; // Se não houver respostas não lidas, retorna 0
    //     }

    //     $stmt->close();
    //     return $unreadCountProdutora;
    // }

    // function respostaAnunciante($idMensagemOriginal, $resposta)
    // {
    //     global $conn;

    //     // Escapa a resposta para evitar injeção de SQL
    //     $resposta = htmlspecialchars($resposta, ENT_QUOTES, 'UTF-8');

    //     // SQL para inserir a mensagem
    //     $sql = "INSERT INTO respostamensagensadmin (idMensagemOriginal, mensagemResposta, dataResposta, estado)
    //              VALUES (?, ?, NOW(), 1)";
    //     $stmt = $conn->prepare($sql);
    //     $stmt->bind_param("is", $idMensagemOriginal, $resposta); // Corrigido para "is" pois o primeiro parâmetro é um inteiro e o segundo uma string

    //     if ($stmt->execute()) {
    //         // Obtém a data atual para exibir
    //         $data = date('Y-m-d H:i:s'); // Formato da data a ser exibido

    //         // Retorna o HTML da mensagem enviada
    //         return "<li class='clearfix'>
    //         <div class='message my-message float-right'>
    //             $resposta 
    //             <span class='message-time'>$data</span> <!-- Mostrar a data/hora aqui -->
    //         </div>
    //     </li>";
    //     } else {
    //         // Retorna o erro, caso haja
    //         return "Error: " . $stmt->error;
    //     }
    // }

    // function respostaProdutora($idMensagemOriginal, $resposta)
    // {
    //     global $conn;

    //     // Escapa a resposta para evitar injeção de SQL
    //     $resposta = htmlspecialchars($resposta, ENT_QUOTES, 'UTF-8');

    //     // SQL para inserir a mensagem
    //     $sql = "INSERT INTO respostamensagensadmin (idMensagemOriginal, mensagemResposta, dataResposta, estado)
    //              VALUES (?, ?, NOW(), 1)";
    //     $stmt = $conn->prepare($sql);
    //     $stmt->bind_param("is", $idMensagemOriginal, $resposta); // Corrigido para "is" pois o primeiro parâmetro é um inteiro e o segundo uma string

    //     if ($stmt->execute()) {
    //         // Obtém a data atual para exibir
    //         $data = date('Y-m-d H:i:s'); // Formato da data a ser exibido

    //         // Retorna o HTML da mensagem enviada
    //         return "<li class='clearfix'>
    //         <div class='message my-message float-right'>
    //             $resposta 
    //             <span class='message-time'>$data</span> <!-- Mostrar a data/hora aqui -->
    //         </div>
    //     </li>";
    //     } else {
    //         // Retorna o erro, caso haja
    //         return "Error: " . $stmt->error;
    //     }
    // }

    // function listaParceriasAdmin()
    // {
    //     global $conn;
    //     $msg = "";

    //     // SQL para buscar todas as recomendações da tabela aprovarecomendacao
    //     $sql = "
    // SELECT 
    //     g.descricaoGama, 
    //     ar.idRecomendacao,
    //     p.logo,
    //     an.nomeAnuncio,
    //     p.nomeProdutora,
    //     a.logoAnunciante,
    //     a.nomeAnunciante,
    //     ar.estadoAprovacao,
    //     ar.data
    // FROM aprovarecomendacao ar
    // JOIN produtora p ON ar.idProdutora = p.idProdutora
    // JOIN anunciante a ON ar.idAnunciante = a.idAnunciante
    // JOIN anuncios an ON ar.idAnuncio = an.idAnuncio
    // JOIN gamacharuto g ON ar.codGamaCharuto = g.codigoGama"; // Filtrar pelo estado de aprovação

    //     // Preparar e executar a query
    //     $stmt = $conn->prepare($sql);

    //     if ($stmt === false) {
    //         return "Erro ao preparar a consulta: " . $conn->error;
    //     }

    //     $stmt->execute();
    //     $result = $stmt->get_result(); // Obter os resultados

    //     // Verifica se a consulta retornou resultados
    //     if ($result->num_rows > 0) {
    //         // Iterar sobre os resultados e construir o HTML
    //         while ($row = $result->fetch_assoc()) {
    //             $idRecomendacao = htmlspecialchars($row['idRecomendacao']);
    //             $nomeProdutora = htmlspecialchars($row['nomeProdutora']);
    //             $nomeAnunciante = htmlspecialchars($row['nomeAnunciante']);
    //             $nomeAnuncio = htmlspecialchars($row['nomeAnuncio']);
    //             $data = htmlspecialchars($row['data']);
    //             $gama = htmlspecialchars($row['descricaoGama']);
    //             $estado = htmlspecialchars($row['estadoAprovacao']);

    //             $msg .= "<tr>";
    //             $msg .= "<td>$idRecomendacao</td>";
    //             $msg .= "<td>$nomeProdutora</td>";
    //             $msg .= "<td>$nomeAnunciante</td>";
    //             $msg .= "<td>$nomeAnuncio</td>";
    //             $msg .= "<td>$data</td>";
    //             $msg .= "<td>$gama</td>";
    //             $msg .= "<td>$estado</td>";

    //             // Verifica o estado de aprovação
    //             if ($estado === 'Aprovado') {
    //                 // Se aprovado, exibe a mensagem
    //                 $msg .= "<td><span class='badge badge-light text-dark'>Aprovado pelo Administrador</span></td>";
    //             } else {
    //                 // Caso contrário, exibe o botão de confirmar
    //                 $disabled = ($estado === 'Pendente') ? 'disabled' : '';
    //                 $msg .= "<td><button type='button' class='btn btn-primary' id='confirmarButton$idRecomendacao' onclick='confirmarParceriaAdmin($idRecomendacao)' $disabled>Confirmar</button></td>";
    //             }

    //             $msg .= "</tr>";
    //         }
    //     } else {
    //         // Se não houver resultados, exibir uma linha "Sem resultados"
    //         $msg .= "<tr>";
    //         $msg .= "<th scope='row'>Sem resultados</th>";
    //         $msg .= "<td colspan='6'></td>"; // Preencher as colunas restantes (6 colunas)
    //         $msg .= "</tr>";
    //     }

    //     $stmt->close(); // Fecha a consulta
    //     return $msg;    // Retorna o HTML gerado
    // }

    // function confirmarParceriaAdmin($idRecomendacao)
    // {
    //     global $conn;

    //     $estado = "Aprovado";

    //     // SQL para atualizar a recomendação
    //     $sql = "UPDATE aprovarecomendacao 
    //             SET estadoAprovacao = ? 
    //             WHERE idRecomendacao = ?";

    //     $stmt = $conn->prepare($sql);

    //     // Verificar se o prepare foi bem-sucedido
    //     if ($stmt === false) {
    //         return 'Erro no prepare: ' . $conn->error;
    //     }

    //     // Associar parâmetros
    //     $stmt->bind_param("si", $estado, $idRecomendacao);

    //     // Executar e verificar erros
    //     if ($stmt->execute()) {
    //         $stmt->close(); // Fechar a instrução após execução
    //         return "Aprovado com sucesso!";
    //     } else {
    //         $stmt->close(); // Fechar a instrução mesmo em caso de erro
    //         return "Erro ao atualizar a recomendação: " . $stmt->error;
    //     }
    // }

    // LISTAGEM DE UTILIZADORES //

    function listaUsers()
    {
        global $conn;
        $msg = "";

        // SQL para buscar todas as recomendações da tabela aprovarecomendacao
        $sql = "
    SELECT 
        u.idUser,
        u.nomeUser,
        u.username,
        u.emailUser,
        u.estado,
        u.foto,
        u.resposta1,
        u.resposta2
    FROM user u";

        // Preparar e executar a query
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            return "Erro ao preparar a consulta: " . $conn->error;
        }

        $stmt->execute();
        $result = $stmt->get_result(); // Obter os resultados

        // Verifica se a consulta retornou resultados
        if ($result->num_rows > 0) {
            // Iterar sobre os resultados e construir o HTML
            while ($row = $result->fetch_assoc()) {
                $nomeUser = htmlspecialchars($row['nomeUser']);
                $username = htmlspecialchars($row['username']);
                $emailUser = htmlspecialchars($row['emailUser']);
                $estado = htmlspecialchars($row['estado']);
                $foto = htmlspecialchars($row['foto']); // Coloca o link da foto
                $resposta1 = htmlspecialchars($row['resposta1']);
                $resposta2 = htmlspecialchars($row['resposta2']);
                $idUser = htmlspecialchars($row['idUser']);

                $msg .= "<tr>";
                $msg .= "<td>$nomeUser</td>";
                $msg .= "<td>$username</td>";
                $msg .= "<td>$emailUser</td>";
                $msg .= "<td>$estado</td>";
                $msg .= "<td><img class='img-size' src='$foto' alt='Foto do User'></td>"; // Usar a foto no src
                $msg .= "<td>$resposta1</td>";
                $msg .= "<td>$resposta2</td>";
                $msg .= "<td><button type='button' class='btn btn-danger' onclick='bloquearUser($idUser)'>Bloquear</button></td>";
                $msg .= "<td><button type='button' class='btn btn-success' onclick='desbloquearUser($idUser)'>Desbloquear</button></td>";
                $msg .= "</tr>";
            }
        } else {
            // Se não houver resultados, exibir uma linha "Sem resultados"
            $msg .= "<tr>";
            $msg .= "<th scope='row'>Sem resultados</th>";
            $msg .= "<td colspan='6'></td>"; // Preencher as colunas restantes (6 colunas)
            $msg .= "</tr>";
        }

        $stmt->close(); // Fecha a consulta
        return $msg;    // Retorna o HTML gerado
    }

    function bloquearUser($idUser)
    {
        global $conn;

        $estado = "Bloqueado";

        // SQL para atualizar a recomendação
        $sql = "UPDATE user 
                SET estado = ? 
                WHERE idUser = ?";

        $stmt = $conn->prepare($sql);

        // Verificar se o prepare foi bem-sucedido
        if ($stmt === false) {
            return 'Erro no prepare: ' . $conn->error;
        }

        // Associar parâmetros
        $stmt->bind_param("si", $estado, $idUser);

        // Executar e verificar erros
        if ($stmt->execute()) {
            $stmt->close(); // Fechar a instrução após execução
            return "Bloqueado com sucesso!";
        } else {
            $stmt->close(); // Fechar a instrução mesmo em caso de erro
            return "Erro ao atualizar a recomendação: " . $stmt->error;
        }
    }

    function desbloquearUser($idUser)
    {
        global $conn;

        $estado = "Ativo";

        // SQL para atualizar a recomendação
        $sql = "UPDATE user 
                SET estado = ? 
                WHERE idUser = ?";

        $stmt = $conn->prepare($sql);

        // Verificar se o prepare foi bem-sucedido
        if ($stmt === false) {
            return 'Erro no prepare: ' . $conn->error;
        }

        // Associar parâmetros
        $stmt->bind_param("si", $estado, $idUser);

        // Executar e verificar erros
        if ($stmt->execute()) {
            $stmt->close(); // Fechar a instrução após execução
            return "Desbloqueado com sucesso!";
        } else {
            $stmt->close(); // Fechar a instrução mesmo em caso de erro
            return "Erro ao atualizar a recomendação: " . $stmt->error;
        }
    }

    function listaLogins()
    {
        global $conn;
        $msg = "";

        // SQL para buscar todas as recomendações da tabela aprovarecomendacao para essa produtora e anunciante com estado de aprovação 'pendente'
        $sql = "
    SELECT 
        l.idLogin, 
        u.nomeUser,
        l.hora,
        l.IpOrigem,
        l.estado
    FROM login l
    JOIN user u ON l.idUser = u.idUser"; // Filtrar pelo estado de aprovação

        // Preparar e executar a query
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            return "Erro ao preparar a consulta: " . $conn->error;
        }

        $stmt->execute();
        $result = $stmt->get_result(); // Obter os resultados

        // Verifica se a consulta retornou resultados
        if ($result->num_rows > 0) {
            // Iterar sobre os resultados e construir o HTML
            while ($row = $result->fetch_assoc()) {
                $idLogin = htmlspecialchars($row['idLogin']);
                $nomeUser = htmlspecialchars($row['nomeUser']);
                $hora = htmlspecialchars($row['hora']);
                $IpOrigem = htmlspecialchars($row['IpOrigem']);
                $estado = htmlspecialchars($row['estado']); // Coloca o link da foto

                $msg .= "<tr>";
                $msg .= "<td>$idLogin</td>";
                $msg .= "<td>$nomeUser</td>";
                $msg .= "<td>$hora</td>";
                $msg .= "<td>$IpOrigem</td>";
                $msg .= "<td>$estado</td>";
                $msg .= "</tr>";
            }
        } else {
            // Se não houver resultados, exibir uma linha "Sem resultados"
            $msg .= "<tr>";
            $msg .= "<th scope='row'>Sem resultados</th>";
            $msg .= "<td colspan='6'></td>"; // Preencher as colunas restantes (6 colunas)
            $msg .= "</tr>";
        }

        $stmt->close(); // Fecha a consulta
        return $msg;    // Retorna o HTML gerado
    }

    function ativarAnunciante($idAnunciante)
    {
        global $conn;

        $status = "Ativo";

        // SQL para atualizar a recomendação
        $sql = "UPDATE anunciante 
                SET status = ? 
                WHERE idAnunciante = ?";

        $stmt = $conn->prepare($sql);

        // Verificar se o prepare foi bem-sucedido
        if ($stmt === false) {
            return 'Erro no prepare: ' . $conn->error;
        }

        // Associar parâmetros
        $stmt->bind_param("si", $status, $idAnunciante);

        // Executar e verificar erros
        if ($stmt->execute()) {
            $stmt->close(); // Fechar a instrução após execução
            return "Aprovado com sucesso!";
        } else {
            $stmt->close(); // Fechar a instrução mesmo em caso de erro
            return "Erro ao atualizar a recomendação: " . $stmt->error;
        }
    }

    function inativarAnunciante($idAnunciante)
    {
        global $conn;

        $status = "Inativo";

        // SQL para atualizar a recomendação
        $sql = "UPDATE anunciante 
                SET status = ? 
                WHERE idAnunciante = ?";

        $stmt = $conn->prepare($sql);

        // Verificar se o prepare foi bem-sucedido
        if ($stmt === false) {
            return 'Erro no prepare: ' . $conn->error;
        }

        // Associar parâmetros
        $stmt->bind_param("si", $status, $idAnunciante);

        // Executar e verificar erros
        if ($stmt->execute()) {
            $stmt->close(); // Fechar a instrução após execução
            return "Inativado com sucesso!";
        } else {
            $stmt->close(); // Fechar a instrução mesmo em caso de erro
            return "Erro ao atualizar a recomendação: " . $stmt->error;
        }
    }


    function listaProdutoras()
    {
        global $conn;
        $msg = "";

        // SQL para buscar todas as recomendações da tabela aprovarecomendacao para essa produtora e anunciante com estado de aprovação 'pendente'
        $sql = "
    SELECT 
        p.idProdutora,
        p.nomeProdutora, 
        p.usernameP,
        p.comprovativoFiscal,
        p.logo,
        p.moradaFiscal,
        p.status
    FROM produtora p"; // Filtrar pelo estado de aprovação

        // Preparar e executar a query
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            return "Erro ao preparar a consulta: " . $conn->error;
        }

        $stmt->execute();
        $result = $stmt->get_result(); // Obter os resultados

        // Verifica se a consulta retornou resultados
        if ($result->num_rows > 0) {
            // Iterar sobre os resultados e construir o HTML
            while ($row = $result->fetch_assoc()) {
                $nomeProdutora = htmlspecialchars($row['nomeProdutora']);
                $username = htmlspecialchars($row['usernameP']);
                $comprovativoFiscal = htmlspecialchars($row['comprovativoFiscal']);
                $logo = htmlspecialchars($row['logo']);
                $moradaFiscal = htmlspecialchars($row['moradaFiscal']); // Coloca o link da foto
                $status = htmlspecialchars($row['status']);
                $idProdutora = htmlspecialchars($row['idProdutora']);

                $msg .= "<tr>";
                $msg .= "<td>$nomeProdutora</td>";
                $msg .= "<td>$username</td>";
                $msg .= "<td>$moradaFiscal</td>";
                $msg .= "<td><img class='img-size' src='$comprovativoFiscal' alt='Logo do Produtora'></td>";
                $msg .= "<td><img class='img-size' src='$logo' alt='Comprovativo do Produtora'></td>"; // Usar a foto no src
                $msg .= "<td>$status</td>";
                $msg .= "<td><button type='button' class='btn btn-success' onclick='ativarProdutora($idProdutora)'>Aprovar</button></td>";
                $msg .= "<td><button type='button' class='btn btn-danger' onclick='inativarProdutora($idProdutora)'>Inativar</button></td>";
                $msg .= "</tr>";
            }
        } else {
            // Se não houver resultados, exibir uma linha "Sem resultados"
            $msg .= "<tr>";
            $msg .= "<th scope='row'>Sem resultados</th>";
            $msg .= "<td colspan='6'></td>"; // Preencher as colunas restantes (6 colunas)
            $msg .= "</tr>";
        }

        $stmt->close(); // Fecha a consulta
        return $msg;    // Retorna o HTML gerado
    }

    function ativarProdutora($idProdutora)
    {
        global $conn;

        $status = "Ativo";

        // SQL para atualizar a recomendação
        $sql = "UPDATE produtora 
                SET status = ? 
                WHERE idProdutora = ?";

        $stmt = $conn->prepare($sql);

        // Verificar se o prepare foi bem-sucedido
        if ($stmt === false) {
            return 'Erro no prepare: ' . $conn->error;
        }

        // Associar parâmetros
        $stmt->bind_param("si", $status, $idProdutora);

        // Executar e verificar erros
        if ($stmt->execute()) {
            $stmt->close(); // Fechar a instrução após execução
            return "Aprovado com sucesso!";
        } else {
            $stmt->close(); // Fechar a instrução mesmo em caso de erro
            return "Erro ao atualizar a recomendação: " . $stmt->error;
        }
    }

    function inativarProdutora($idProdutora)
    {
        global $conn;

        $status = "Inativo";

        // SQL para atualizar a recomendação
        $sql = "UPDATE produtora 
                SET status = ? 
                WHERE idProdutora = ?";

        $stmt = $conn->prepare($sql);

        // Verificar se o prepare foi bem-sucedido
        if ($stmt === false) {
            return 'Erro no prepare: ' . $conn->error;
        }

        // Associar parâmetros
        $stmt->bind_param("si", $status, $idProdutora);

        // Executar e verificar erros
        if ($stmt->execute()) {
            $stmt->close(); // Fechar a instrução após execução
            return "Inativado com sucesso!";
        } else {
            $stmt->close(); // Fechar a instrução mesmo em caso de erro
            return "Erro ao atualizar a recomendação: " . $stmt->error;
        }
    }

    function listaEventosAdmin()
    {
        global $conn;
        $msg = "";

        // Obter a data e hora atual
        $now = date("Y-m-d H:i:s");

        // Query para selecionar todos os eventos e os dados dos anunciantes associados
        $sql = "SELECT eventos.*, anunciante.nomeAnunciante 
            FROM eventos 
            JOIN anunciante ON eventos.idAnunciante = anunciante.idAnunciante";

        // Prepara e executa a consulta
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();

        // Verifica os resultados
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Verifica se a hora final do evento já passou
                if ($now > $row['dataEvento'] . ' ' . $row['horaFinalEvento'] && $row['estado'] != 'Realizado') {
                    // Atualiza o estado para "Realizado"
                    $sqlUpdate = "UPDATE eventos SET estado = 'Realizado' WHERE idEvento = ?";
                    $stmtUpdate = $conn->prepare($sqlUpdate);
                    $stmtUpdate->bind_param("i", $row['idEvento']);
                    $stmtUpdate->execute();
                    $stmtUpdate->close();
                    $row['estado'] = 'Realizado'; // Atualiza o valor localmente também
                }

                // Constrói o HTML da tabela
                $msg .= "<tr>";
                $msg .= "<td>" . $row['nomeEvento'] . "</td>";
                $msg .= "<td>" . $row['nomeAnunciante'] . "</td>";
                $msg .= "<td>" . $row['dataEvento'] . "</td>";
                $msg .= "<td><img class='img-thumbnail' src='" . $row['fotoEvento'] . "'></td>";
                $msg .= "<td>" . $row['estado'] . "</td>";
                $msg .= "<td><button type='button' class='btn btn-info' onclick='infoEvento(" . $row['idEvento'] . ")'>Info</button></td>";
                $msg .= "</tr>";
            }
        } else {
            // Exibe uma linha de "Sem resultados"
            $msg .= "<tr>";
            $msg .= "<th scope='row'> Sem resultados</th>";
            $msg .= "<td colspan='6'></td>";
            $msg .= "</tr>";
        }

        $conn->close(); // Fecha a conexão
        return $msg;    // Retorna o HTML gerado
    }

    function infoEvento($idEvento)
    {
        global $conn;
        $row = "";

        // Prepara a consulta SQL
        $sql = "SELECT * FROM eventos WHERE idEvento = ?";
        $stmt = $conn->prepare($sql);

        // Verifica se a preparação foi bem-sucedida
        if ($stmt === false) {
            die("Erro ao preparar a consulta: " . $conn->error);
        }

        // Vincula o parâmetro (idEvento) à consulta
        $stmt->bind_param("i", $idEvento); // "i" indica que o parâmetro é um inteiro

        // Executa a consulta
        $stmt->execute();

        // Obtém o resultado da consulta
        $result = $stmt->get_result();

        // Verifica se houve algum resultado
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc(); // Pega a primeira linha de resultado
        }

        // Fecha a declaração e a conexão
        $stmt->close();
        $conn->close();

        return json_encode($row);
    }

    // ANUNCIOS //

    function listaAnunciosAdmin()
    {
        global $conn;
        $msg = "";


        // Query para selecionar todos os eventos e os dados dos anunciantes associados
        $sql = "SELECT anuncios.*, anunciante.nomeAnunciante, tipoAnuncio.descricaoTipoAnuncio
            FROM anuncios 
            JOIN anunciante ON anuncios.idAnunciante = anunciante.idAnunciante
            JOIN tipoAnuncio ON anuncios.idTipAnuncio = tipoAnuncio.idTipoAnuncio";

        // Prepara e executa a consulta
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();

        // Verifica os resultados
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {

                // Constrói o HTML da tabela
                $msg .= "<tr>";
                $msg .= "<td>" . $row['idAnuncio'] . "</td>";
                $msg .= "<td>" . $row['nomeAnunciante'] . "</td>";
                $msg .= "<td>" . $row['descricaoTipoAnuncio'] . "</td>";
                $msg .= "<td><img class='img-thumbnail' src='" . $row['foto'] . "'></td>";
                $msg .= "<td>" . $row['estado'] . "</td>";
                $msg .= "<td><button type='button' class='btn btn-info' onclick='infoAnuncio(" . $row['idAnuncio'] . ")'>Info</button></td>";
                $msg .= "<td><button type='button' class='btn btn-success' onclick='validarAnuncio(" . $row['idAnuncio'] . ")'>Validar</button></td>";
                $msg .= "<td><button type='button' class='btn btn-danger' onclick='rejeitarAnuncio(" . $row['idAnuncio'] . ")'>Rejeitar</button></td>";
                $msg .= "</tr>";
            }
        } else {
            // Exibe uma linha de "Sem resultados"
            $msg .= "<tr>";
            $msg .= "<th scope='row'> Sem resultados</th>";
            $msg .= "<td colspan='6'></td>";
            $msg .= "</tr>";
        }

        $conn->close(); // Fecha a conexão
        return $msg;    // Retorna o HTML gerado
    }

    function infoAnuncio($idAnuncio)
    {
        global $conn;
        $msg = "";

        // Prepara a consulta SQL com um placeholder
        $sql = "SELECT * FROM anuncios WHERE idAnuncio = ?";
        $stmt = $conn->prepare($sql);

        // Verifica se a preparação foi bem-sucedida
        if ($stmt === false) {
            die("Erro ao preparar a consulta: " . $conn->error);
        }

        // Vincula o parâmetro idAnuncio à consulta
        $stmt->bind_param("i", $idAnuncio); // "i" indica que é um inteiro

        // Executa a consulta
        $stmt->execute();

        // Obtém o resultado
        $result = $stmt->get_result();

        // Verifica se há resultados
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Constrói o HTML da tabela
                $msg .= "<tr>";
                $msg .= "<td>https://" . $row['hyperligacao'] . "</td>";
                $msg .= "<td>$" . $row['custoPlacement'] . "</td>";
                $msg .= "<td>$" . $row['cpm'] . "</td>";
                $msg .= "<td>$" . $row['cpc'] . "</td>";
                $msg .= "<td>$" . $row['custoCriacao'] . "</td>";
                $msg .= "</tr>";
            }
        } else {
            // Exibe uma linha de "Sem resultados"
            $msg .= "<tr>";
            $msg .= "<th scope='row'>Sem resultados</th>";
            $msg .= "<td colspan='5'></td>";
            $msg .= "</tr>";
        }

        // Fecha a declaração e a conexão
        $stmt->close();
        $conn->close();

        return $msg; // Retorna o HTML gerado
    }


    function validarAnuncio($idAnuncio)
    {
        global $conn;

        $estado = "Aceite";

        // SQL para atualizar a recomendação
        $sql = "UPDATE anuncios 
                SET estado = ? 
                WHERE idAnuncio = ?";

        $stmt = $conn->prepare($sql);

        // Verificar se o prepare foi bem-sucedido
        if ($stmt === false) {
            return 'Erro no prepare: ' . $conn->error;
        }

        // Associar parâmetros
        $stmt->bind_param("si", $estado, $idAnuncio);

        // Executar e verificar erros
        if ($stmt->execute()) {
            $stmt->close(); // Fechar a instrução após execução
            return "Anuncio Validado!";
        } else {
            $stmt->close(); // Fechar a instrução mesmo em caso de erro
            return "Erro ao atualizar a recomendação: " . $stmt->error;
        }
    }

    function rejeitarAnuncio($idAnuncio)
    {
        global $conn;

        $estado = "Rejeitado";

        // SQL para atualizar a recomendação
        $sql = "UPDATE anuncios 
                SET estado = ? 
                WHERE idAnuncio = ?";

        $stmt = $conn->prepare($sql);

        // Verificar se o prepare foi bem-sucedido
        if ($stmt === false) {
            return 'Erro no prepare: ' . $conn->error;
        }

        // Associar parâmetros
        $stmt->bind_param("si", $estado, $idAnuncio);

        // Executar e verificar erros
        if ($stmt->execute()) {
            $stmt->close(); // Fechar a instrução após execução
            return "Anuncio Rejeitado!";
        } else {
            $stmt->close(); // Fechar a instrução mesmo em caso de erro
            return "Erro ao atualizar a recomendação: " . $stmt->error;
        }
    }

}


?>