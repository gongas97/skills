<?php

require_once 'connection.php';

class Campo4
{

    // ################################ REGISTO ################################ //

    function registarVoo($descr, $aviao, $destino, $estado)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "INSERT INTO voo (descricao, id_aviao, id_destino, estado) 
        VALUES ('" . $descr . "','" . $aviao . "','" . $destino . "','" . $estado . "')";


        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com sucesso!";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }


        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return ($resp);


    }

    // ################################ LISTAGEM ################################ //
    function getListagemVoos()
    {
        global $conn;
        $msg = "";

        $sql = "SELECT voo.*, aviao.matricula, destino.descricao AS descricaoD FROM voo, aviao, destino 
        WHERE voo.id_aviao = aviao.id AND
        voo.id_destino = destino.id";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['descricao'] . "</th>";
                $msg .= "<td>" . $row['matricula'] . "</td>";
                $msg .= "<td>" . $row['descricaoD'] . "</td>";
                $msg .= "<td>" . $row['estado'] . "</td>";
                $msg .= "<td><button class='btn btn-warning' onclick='editarVoo(" . $row['id'] . ")'><i class='fas fa-pencil-alt'></i></button></td>";
                $msg .= "<td><button class='btn btn-danger' onclick='removerVoo(" . $row['id'] . ")'><i class='fas fa-trash'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }


    // ################################ REMOVER ################################ //
    function removerVoo($id)
{
    global $conn;
    $flag = true; 
    $msg = "";

    $sql = "SELECT COUNT(*) AS total FROM agendamento WHERE id_voo = ?";
    if ($stmt1 = $conn->prepare($sql)) {
        $stmt1->bind_param("i", $id);
        $stmt1->execute();
        $stmt1->bind_result($total);
        $stmt1->fetch();
        $stmt1->close();

        if ($total > 0) {
            $flag = false;
            $msg = "Não pode ser removido voo com agendamento feito.";
        }
    } else {
        $flag = false;
        $msg = "Erro: " . $conn->error;
    }

    if ($flag) {
        $sql = "DELETE FROM voo WHERE id = ?";
        if ($stmt2 = $conn->prepare($sql)) {
            $stmt2->bind_param("i", $id);
            if ($stmt2->execute()) {
                $msg = "Removido com sucesso!";
            } else {
                $flag = false;
                $msg = "Erro ao remover o registro: " . $stmt2->error;
            }
            $stmt2->close();
        } else {
            $flag = false;
            $msg = "Erro: " . $conn->error;
        }
    }

    $conn->close();

    return json_encode(array("flag" => $flag, "msg" => $msg));
}

    // ################################ EDITAR ################################ //
    function editarVoo($id)
    {
       global $conn;
        $row = "";

        $sql = "SELECT * FROM voo WHERE id =".$id;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function guardarEditVoo($id, $descr, $aviao, $destino, $estado, $idOld)
    {
         global $conn;
        $msg = "";
        $flag = true;
        $sql = "";

        $sql = "UPDATE voo SET id = '".$id."', descricao = '".$descr."', id_aviao = '".$aviao."', id_destino = '".$destino."', estado = '".$estado."' WHERE id = ".$idOld;
        

        if ($conn->query($sql) === TRUE) {
            $msg = "Editada com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);
    }

    // ################################ GETS ################################ //

    function getsAviao()
    {
        global $conn;
        $msg = "<option selected>Escolha um Avião</option>";

        $sql = "SELECT * FROM aviao";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['matricula'] ." - ". $row['modelo'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Aviões registados</option>";

        }
        $conn->close();

        return ($msg);
    }

    function getsVoos()
    {
        global $conn;
        $msg = "<option selected>Escolha um Voo</option>";

        $sql = "SELECT * FROM voo";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Voos registados</option>";

        }
        $conn->close();

        return ($msg);
    }


}
?>