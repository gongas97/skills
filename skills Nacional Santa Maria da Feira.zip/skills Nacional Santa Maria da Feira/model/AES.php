<?php
class AES
{
    private $encryption_key;

    public function __construct($key)
    {
        $this->encryption_key = $key;
    }

    // Método para criptografar
    public function encrypt($data)
    {
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-128-cbc'));
        $encrypted = openssl_encrypt($data, 'aes-128-cbc', $this->encryption_key, 0, $iv);
        return base64_encode($iv . $encrypted); // Armazena o IV junto com o texto criptografado
    }

    // Método para descriptografar
    public function decrypt($encryptedData)
    {
        $data = base64_decode($encryptedData);
        $ivLength = openssl_cipher_iv_length('aes-128-cbc');
        $iv = substr($data, 0, $ivLength);
        $encrypted = substr($data, $ivLength);
        return openssl_decrypt($encrypted, 'aes-128-cbc', $this->encryption_key, 0, $iv);
    }
}
?>