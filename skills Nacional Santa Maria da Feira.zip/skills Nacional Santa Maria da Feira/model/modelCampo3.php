<?php

require_once 'connection.php';

class Campo3
{

    // ################################ REGISTO ################################ //

    function registarConsulta($medico, $atleta, $data, $senha, $valor, $fCardica, $PAmin, $PAmax, $comentarios)
    {
        global $conn;
        $msg = "";
        $flag = true;

        if ($flag) {
            $sql = "INSERT INTO consultas (nCedulaMedico, nifAtleta, data, nImpresso, valor, fCardica, pArtrialMin, pArtrialMax, comentario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            if ($stmt_insert = $conn->prepare($sql)) {
                $stmt_insert->bind_param("iisssssss", $medico, $atleta, $data, $senha, $valor, $fCardica, $PAmin, $PAmax, $comentarios);
                if ($stmt_insert->execute()) {
                    $msg = "Registrada com sucesso!";
                } else {
                    $flag = false;
                    $msg = "Erro: " . $stmt_insert->error;
                }
                $stmt_insert->close();
            } else {
                $flag = false;
                $msg = "Erro: " . $conn->error;
            }
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return $resp;
    }


    // ################################ LISTAGEM ################################ //
    function getListagemConsultas()
    {
        global $conn;
        $msg = "";

        $stmt = $conn->prepare("SELECT consultas.*, medico.nome AS nomeMedico, atleta.nome AS nomeAtleta FROM consultas 
         JOIN atleta ON consultas.nifAtleta = atleta.nif
         JOIN medico ON consultas.nCedulaMedico = medico.nCedula");
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {

                $valorConsulta = ($row['valor'] * 1.23);

                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['nImpresso'] . "</th>";
                $msg .= "<th scope='row'>" . $row['nomeMedico'] . "</th>";
                $msg .= "<th scope='row'>" . $row['nomeAtleta'] . "</th>";
                $msg .= "<th scope='row'>" . $row['data'] . "</th>";
                $msg .= "<th scope='row'>" . $valorConsulta . "€</th>";
                $msg .= "<td><button class='btn btn-info' onclick='infoConsulta(" . $row['id'] . ")'><i class='fas fa-info'></i></button></td>";
                $msg .= "<td><button class='btn btn-danger' onclick='removerConsulta(" . $row['id'] . ")'><i class='fas fa-trash'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td colspan='4'>Sem Registos</td>";
            $msg .= "</tr>";
        }

        $stmt->close();
        $conn->close();

        return $msg;
    }

    // ################################ REMOVER ################################ //
    function removerMedico($nCedula)
    {
        global $conn;
        $flag = false;
        $msg = "";


        $sql = "DELETE FROM medico WHERE nCedula = ?";
        if ($stmt2 = $conn->prepare($sql)) {
            $stmt2->bind_param("i", $nCedula);
            if ($stmt2->execute()) {
                $msg = "Removido com sucesso!";
                $flag = true;
            } else {
                $msg = "Erro ao remover o registro: " . $stmt2->error;
            }
            $stmt2->close();
        } else {
            $msg = "Erro: " . $conn->error;
        }



        $conn->close();

        return json_encode(array("flag" => $flag, "msg" => $msg));
    }


    // ################################ EDITAR ################################ //
    function infoConsulta($id)
    {
        global $conn;
        $msg = "";

        // SQL query to retrieve consultation details along with exam designations
        $sql = "SELECT consultas.fCardica, consultas.pArtrialMin, consultas.pArtrialMax, exames.designacao, consultas.comentario
            FROM consultas
            JOIN examesconsulta ON consultas.id = examesconsulta.idConsulta
            JOIN exames ON examesconsulta.idExame = exames.cod
            WHERE consultas.id = ?";

        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Variables to store single values for consultation data and an array for exams
                $fCardica = $pArtrialMin = $pArtrialMax = "";
                $exames = [];

                // Loop through each exam associated with the consultation and gather data
                while ($row = $result->fetch_assoc()) {
                    // Store the consultation data once
                    if (!$fCardica) {
                        $fCardica = htmlspecialchars($row['fCardica']);
                        $pArtrialMin = htmlspecialchars($row['pArtrialMin']);
                        $pArtrialMax = htmlspecialchars($row['pArtrialMax']);
                        $comentario = htmlspecialchars($row['comentario']);
                    }
                    // Add each exam designation to the exams array
                    $exames[] = htmlspecialchars($row['designacao']);
                }

                // Build the table row
                $msg .= "<tr>";
                $msg .= "<td scope='row'>" . $fCardica . "</td>";
                $msg .= "<td>" . $pArtrialMin . "</td>";
                $msg .= "<td>" . $pArtrialMax . "</td>";
                // Join all exam designations with commas or line breaks
                $msg .= "<td>" . implode(", ", $exames) . "</td>";
                $msg .= "<td>" . $comentario . "</td>";
                $msg .= "</tr>";

            } else {
                // No records found
                $msg .= "<tr>";
                $msg .= "<td>Sem Registos</td>";
                $msg .= "<td scope='row'></td>";
                $msg .= "<td></td>";
                $msg .= "<td></td>";
                $msg .= "<td></td>";
                $msg .= "</tr>";
            }

            $stmt->close();
        } else {
            // SQL error handling
            $msg .= "<tr>";
            $msg .= "<td colspan='5'>Erro na consulta: " . htmlspecialchars($conn->error) . "</td>";
            $msg .= "</tr>";
        }

        $conn->close();

        return $msg;
    }

    function editarMedico($nCedula)
    {
        global $conn;
        $row = "";

        $sql = "SELECT * FROM medico WHERE nCedula =" . $nCedula;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function guardaEditMedico($nCedula, $nome, $nif, $codPostal, $morada, $nacionalidade, $email, $tel, $nCedulaOld)
    {
        global $conn;
        $msg = "";
        $flag = true;

        if ($flag) {
            $sql = "UPDATE medico SET nCedula = ?, nome = ?, nif = ?, codPostal = ?, morada = ?, nacionalidade = ?, email = ?, tel = ? 
                 WHERE nCedula = ?";

            if ($stmt2 = $conn->prepare($sql)) {
                $stmt2->bind_param("ssssssssi", $nCedula, $nome, $nif, $codPostal, $morada, $nacionalidade, $email, $tel, $nCedulaOld);
                if ($stmt2->execute()) {
                    $msg = "Editado com sucesso!";
                } else {
                    $flag = false;
                    $msg = "Erro ao editar: " . $stmt2->error;
                }
                $stmt2->close();
            } else {
                $flag = false;
                $msg = "Erro: " . $conn->error;
            }
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return $resp;
    }


    // ################################ GETS ################################ //

    function getMedico()
    {
        global $conn;
        $msg = "<option selected>Escolha um Médico</option>";

        $sql = "SELECT * FROM medico";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['nCedula'] . "'>" . $row['nome'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Médicos registados</option>";

        }
        $conn->close();

        return ($msg);
    }

    function getAtleta()
    {
        global $conn;
        $msg = "<option selected>Escolha um Atleta</option>";

        $sql = "SELECT * FROM atleta";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['nif'] . "'>" . $row['nome'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Médicos registados</option>";

        }
        $conn->close();

        return ($msg);
    }


}
?>