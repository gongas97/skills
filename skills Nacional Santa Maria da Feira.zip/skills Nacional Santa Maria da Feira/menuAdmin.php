<nav id="sidebar" class="sidebar js-sidebar">
	<div class="sidebar-content js-simplebar">
		<a class='sidebar-brand'>
			<span class="sidebar-brand-text align-middle">
				<i class="align-middle" style="position: relative; top: -2px;"></i>
				Administrador
			</span>
			<svg class="sidebar-brand-icon align-middle" width="32px" height="32px" viewBox="0 0 24 24" fill="none"
				stroke="#FFFFFF" stroke-width="1.5" stroke-linecap="square" stroke-linejoin="miter" color="#FFFFFF"
				style="margin-left: -3px">
				<path d="M12 4L20 8.00004L12 12L4 8.00004L12 4Z"></path>
				<path d="M20 12L12 16L4 12"></path>
				<path d="M20 16L12 20L4 16"></path>
			</svg>
		</a>

		<ul class="sidebar-nav">
			<li class="sidebar-item text-center">
				<a class="btn-logout" href="#" onclick="logout()">Logout</a>
			</li>
			<li class="sidebar-header">Menus</li>
			<li class="sidebar-item">
				<a class='sidebar-link' href='mainAdmin.php'>
					<i class="align-middle" data-feather="home"></i>
					<span class="align-middle">Home Page</span>
				</a>
			</li>
			<li class="sidebar-item">
				<a class='sidebar-link' href='dashboardAdmin.php'>
					<i class="align-middle" data-feather="globe"></i>
					<span class="align-middle">Dashboard Admin</span>
				</a>
			</li>

			<li class="sidebar-header">Ações de Administração</li>
			<li class="sidebar-item">
				<a data-bs-target="#registos" data-bs-toggle="collapse" class="sidebar-link collapsed"
					aria-expanded="false" onclick="toggleMenu(this)">
					<i class="align-middle" data-feather="check-square"></i> <span class="align-middle">Ações</span>
				</a>
				<ul id="registos" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
					<a class="sidebar-item"><a class='sidebar-link' href='#'>outros</a>
			</li>
		</ul>
		<li class="sidebar-item">
			<a class='sidebar-link' href='parcerias.php'>
				<i class="align-middle" data-feather="tag"></i>
				<span class="align-middle">Parcerias</span>
			</a>
		</li>
		<li class="sidebar-item">
			<a class='sidebar-link' href='gestaoUtilizadores.php'>
				<i class="align-middle" data-feather="users"></i>
				<span class="align-middle">Gestão de Utilizadores</span>
			</a>
		</li>
		<!-- <li class="sidebar-item">
			<a class='sidebar-link' href='anunciosAdmin.php'>
				<i class="align-middle" data-feather="speaker"></i>
				<span class="align-middle">Anuncios</span>
			</a>
		</li>
		<li class="sidebar-item">
			<a class='sidebar-link' href='eventosAdmin.php'>
				<i class="align-middle" data-feather="calendar"></i>
				<span class="align-middle">Eventos</span>
			</a>
		</li> -->
		</ul>
	</div>
</nav>

<div class="main">
	<nav class="navbar navbar-expand navbar-light navbar-bg fixed-top">
		<a class="sidebar-toggle js-sidebar-toggle">
			<i class="hamburger align-self-center"></i>
		</a>

		<!-- Search Form -->
		<form class="d-none d-sm-inline-block">
			<div class="input-group input-group-navbar">
				<input type="text" class="form-control" placeholder="Search…" aria-label="Search">
				<button class="btn" type="button">
					<i class="align-middle" data-feather="search"></i>
				</button>
			</div>
		</form>

		<!-- Navbar Collapse -->
		<div class="navbar-collapse collapse">
			<ul class="navbar-nav navbar-align">

				<!-- Fullscreen Button -->
				<li class="nav-item">
					<a class="nav-icon js-fullscreen d-none d-lg-block" href="#">
						<div class="position-relative">
							<i class="align-middle" data-feather="maximize"></i>
						</div>
					</a>
				</li>
			</ul>
		</div>
	</nav>