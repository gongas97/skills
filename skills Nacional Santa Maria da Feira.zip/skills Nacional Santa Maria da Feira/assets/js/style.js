

// HEADER ZONE CAROUSEL

var swiper = new Swiper(".mySwiperCapa", {
    spaceBetween: 30,
    effect: "fade",
    loop: true,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    autoplay: {
        disableOnInteraction: false
    },
    crossFade: true,
});


// CAROUSEL DOS ANUNCIOS

var swiper = new Swiper(".mySwiperAnuncios", {
    slidesPerView: 1,
    spaceBetween: 10,
    loop: true,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    autoplay: {
        disableOnInteraction: false
    },
    breakpoints: {
        640: {
            slidesPerView: 2,
            spaceBetween: 20,
        },
        768: {
            slidesPerView: 4,
            spaceBetween: 40,
        },
        1024: {
            slidesPerView: 3,
            spaceBetween: 10,
        },
    },
});

// CAROUSEL PRODUTORAS

var swiper = new Swiper(".mySwiperProdutoras", {
    spaceBetween: 30,
    loop: true,
    freeMode: true,
    speed: 2000,
    autoplay: {
        delay: 0,
        disableOnInteraction: false,
        reverseDirection: true,
    },
    breakpoints: {
        640: {
            slidesPerView: 2,
            spaceBetween: 20,
        },
        768: {
            slidesPerView: 4,
            spaceBetween: 40,
        },
        1024: {
            slidesPerView: 5,
            spaceBetween: 10,
        },
    },
});

var swiper = new Swiper(".mySwiperProdutoras2", {
    spaceBetween: 30,
    loop: true,
    freeMode: true,
    speed: 2000,
    autoplay: {
        delay: 0,
        disableOnInteraction: false
    },
    breakpoints: {
        640: {
            slidesPerView: 2,
            spaceBetween: 20,
        },
        768: {
            slidesPerView: 4,
            spaceBetween: 40,
        },
        1024: {
            slidesPerView: 5,
            spaceBetween: 10,
        },
    },
});


// FIXED AND CHANGE NAVBAR COLOR ON SCROLL

var header = document.getElementById('header');
var lastScrollTop = 0;
var scrolledPastTop = false;

window.addEventListener('scroll', function () {
    var scrollTop = window.pageYOffset;
    if (scrollTop === 0) {
        header.classList.remove('scrolled');
        header.style.opacity = 1;
        scrolledPastTop = false;
    } else if (scrollTop < lastScrollTop) {
        header.classList.add('scrolled');
        header.style.opacity = 1;
    } else {
        header.classList.add('scrolled');
        header.style.opacity = 0;
        scrolledPastTop = true;
    }
    lastScrollTop = scrollTop;
});
