// FIXED AND CHANGE NAVBAR COLOR ON SCROLL

var header = document.getElementById('header');
var lastScrollTop = 0;
var scrolledPastTop = false;

window.addEventListener('scroll', function () {
    var scrollTop = window.pageYOffset;
    if (scrollTop === 0) {
        header.classList.remove('scrolled');
        header.style.opacity = 1;
        scrolledPastTop = false;
    } else if (scrollTop < lastScrollTop) {
        header.classList.add('scrolled');
        header.style.opacity = 1;
    } else {
        header.classList.add('scrolled');
        header.style.opacity = 0;
        scrolledPastTop = true;
    }
    lastScrollTop = scrollTop;
});