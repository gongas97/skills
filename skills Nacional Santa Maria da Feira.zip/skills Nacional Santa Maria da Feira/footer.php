<footer class="footer">
                <div class="container-fluid">
                    <div class="row text-muted">
                        <div class="col-6 text-start">
                            <p class="mb-0">
                                <a target="_blank" class="text-muted"><strong>Skills</strong></a> &copy;
                            </p>
                        </div>
                    </div>
                </div>
            </footer>