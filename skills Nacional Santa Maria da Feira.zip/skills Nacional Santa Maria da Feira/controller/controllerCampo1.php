<?php declare(strict_types=1); 

require_once '../model/modelCampo1.php';

$c1 = new Atleta();

if($_POST['op'] == 1){
    $resp = $c1 -> registaAtleta(
        $_POST['nif'],
        $_POST['nome'],
        $_POST['codA'],
        $_POST['codPostal'],
        $_POST['nacionalidade'],
        $_POST['dataNasc'],
        $_POST['email'],
        $_POST['descricao']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $c1 -> getListagemAtletas();
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $c1 -> editarAtleta($_POST['nif']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $c1 -> guardaEditAtleta(
        $_POST['nif'],
        $_POST['nome'],
        $_POST['codAtleta'],
        $_POST['codPostal'],
        $_POST['nacionalidade'],
        $_POST['dataNascimento'],
        $_POST['email'],
        $_POST['descricao'],
        $_POST['nifOld']
    );
    echo ($resp);

}else if($_POST['op'] == 6){
    $resp = $c1 -> getsAtletas();
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $c1 -> infoAtleta($_POST['nif']);
    echo($resp);

}





?>