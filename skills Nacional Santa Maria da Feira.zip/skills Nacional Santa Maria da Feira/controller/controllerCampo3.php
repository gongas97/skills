<?php

require_once '../model/modelCampo3.php';

$c3 = new Campo3();

if($_POST['op'] == 1){
    $resp = $c3 -> registarConsulta(
        $_POST['medico'],
        $_POST['atleta'],
        $_POST['data'],
        $_POST['senha'],
        $_POST['valor'],
        $_POST['fCardica'],
        $_POST['PAmin'],
        $_POST['PAmax'],
        $_POST['comentarios']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $c3 -> getListagemConsultas();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $c3 -> removerMedico($_POST['nCedula']);
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $c3 -> infoConsulta($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $c3 -> guardaEditMedico(
        $_POST['nCedula'],
        $_POST['nome'],
        $_POST['nif'],
        $_POST['codPostal'],
        $_POST['morada'],
        $_POST['nacionalidade'],
        $_POST['email'],
        $_POST['tel'],
        $_POST['nCedulaOld']
    );
    echo ($resp);

}else if($_POST['op'] == 6){
    $resp = $c3 -> getMedico();
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $c3 -> editarMedico($_POST['nCedula']);
    echo($resp);

}else if($_POST['op'] == 8){
    $resp = $c3 -> getAtleta();
    echo($resp);

}





?>