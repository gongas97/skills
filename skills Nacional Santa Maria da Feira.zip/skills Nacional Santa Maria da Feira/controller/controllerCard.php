<?php

require_once '../model/modelCard.php';

$card = new Card();

if($_POST['op'] == 1){
    $resp = $card -> card1();
    echo($resp);

}else if($_POST['op'] == 2){
    $resp = $card -> card2();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $card -> card3();
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $card -> card4();
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $card -> card5();
    echo($resp);

}


?>