<?php

require_once '../model/modelAdmin.php';

$adm = new Admin();

if (isset($_POST['op'])) {
    switch ($_POST['op']) {
        // case 1:
        //     $resp = $adm->getConversaAnunciantes($_POST['idAnunciante']);
        //     echo ($resp);
        //     break;

        // case 2:
        //     $idMensagemOriginal = $_POST['idMensagemOriginal'];
        //     $mensagem = $_POST['mensagem'];
        //     $resp = $adm->respostaAnunciante($idMensagemOriginal, $mensagem);
        //     echo ($resp);
        //     break;

        // case 3:
        //     $idMensagemOriginal = $_POST['idMensagemOriginal'];
        //     $mensagem = $_POST['mensagem'];
        //     $resp = $adm->respostaProdutora($idMensagemOriginal, $mensagem);
        //     echo ($resp);
        //     break;

        // case 4:
        //     $resp = $adm->RespostasNaoLidasAnunciante($_POST['idAnunciante']);
        //     echo ($resp);
        //     break;

        // case 5:
        //     $resp = $adm->RespostasNaoLidasProdutora($_POST['idProdutora']);
        //     echo ($resp);
        //     break;

        // case 6:
        //     $resp = $adm->getConversaProdutora($_POST['idProdutora']);
        //     echo ($resp);
        //     break;

        // case 7:
        //     $resp = $adm->confirmarParceriaAdmin(
        //         $_POST['idRecomendacao']
        //     );
        //     echo ($resp);
        //     break;

        // case 8:
        //     $resp = $adm->listaParceriasAdmin();
        //     echo ($resp);
        //     break;

        case 9:
            $resp = $adm->listaUsers();
            echo ($resp);
            break;

        case 10:
            $resp = $adm->listaLogins();
            echo ($resp);
            break;

        case 11:
            $resp = $adm->listaProdutoras();
            echo ($resp);
            break;

        case 12:
            $resp = $adm->bloquearUser(
                $_POST['idUser']
            );
            echo ($resp);
            break;

        case 13:
            $resp = $adm->desbloquearUser(
                $_POST['idUser']
            );
            echo ($resp);
            break;

        case 14:
            $resp = $adm->ativarProdutora(
                $_POST['idProdutora']
            );
            echo ($resp);
            break;

        case 15:
            $resp = $adm->inativarProdutora(
                $_POST['idProdutora']
            );
            echo ($resp);
            break;

        case 16:
            $resp = $adm->ativarAnunciante(
                $_POST['idAnunciante']
            );
            echo ($resp);
            break;

        case 17:
            $resp = $adm->inativarAnunciante(
                $_POST['idAnunciante']
            );
            echo ($resp);
            break;

        case 18:
            $resp = $adm->listaEventosAdmin();
            echo ($resp);
            break;

        case 19:
            $resp = $adm->infoEvento($_POST['idEvento']);
            echo ($resp);
            break;

        case 20:
            $resp = $adm->listaAnunciosAdmin();
            echo ($resp);
            break;

        case 21:
            $resp = $adm->infoAnuncio($_POST['idAnuncio']);
            echo ($resp);
            break;

        case 22:
            $resp = $adm->validarAnuncio(
                $_POST['idAnuncio']
            );
            echo ($resp);
            break;

        case 23:
            $resp = $adm->rejeitarAnuncio(
                $_POST['idAnuncio']
            );
            echo ($resp);
            break;

        default:
            echo json_encode(['error' => 'Operação não reconhecida.']);
            break;
    }
} else {
    echo json_encode(['error' => 'Nenhuma operação foi definida.']);
}

?>