<?php declare(strict_types=1); 

require_once '../model/modelCampo4.php';

$c4 = new Campo4();

if($_POST['op'] == 1){
    $resp = $c4 -> registarVoo(
        $_POST['descr'],
        $_POST['aviao'],
        $_POST['destino'],
        $_POST['estado']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $c4 -> getListagemVoos();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $c4 -> removerVoo($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $c4 -> editarVoo($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $c4 -> guardarEditVoo(
        $_POST['id'],
        $_POST['descr'],
        $_POST['aviao'],
        $_POST['destino'],
        $_POST['estado'],
        $_POST['idOld']
    );
    echo ($resp);

}else if($_POST['op'] == 6){
    $resp = $c4 -> getsAviao();
    echo($resp);

}else if($_POST['op'] == 8){
    $resp = $c4 -> getsVoos();
    echo($resp);

}





?>