<?php

include_once "../model/modelLogin.php";

$log = new Login();

if ($_POST['op'] == 1) {
    $resp = $log->logout();
    echo ($resp);
} else if ($_POST['op'] == 2) {
    $resp = $log->verificarPerguntas($_POST['username']);
    echo ($resp);
} else if ($_POST['op'] == 3) {
    $resp = $log->responderPerguntas($_POST['resposta1'], $_POST['resposta2'], $_POST['idUser']);
    echo ($resp);
} else if ($_POST['op'] == 4) {
    $resp = $log->registar2(
        $_POST['nomeUser'],
        $_POST['emailUser'],
        $_POST['nifUser'],
        $_POST['pergunta1'],
        $_POST['resposta1Registo'],
        $_POST['pergunta2'],
        $_POST['reposta2Registo'],
        $_POST['username'],
        $_POST['password'],
        $_FILES
    );
    echo ($resp);

} else if ($_POST['op'] == 5) {
    $resp = $log->registar3(
        $_POST['nomeProdutora'],
        $_POST['moradaFiscal'],
        $_POST['paisOrigem'],
        $_FILES,
        $_POST['historiaH'],
        $_FILES,
        $_POST['usernameP'],
        $_POST['passwordP']
    );
    echo ($resp);

} else if ($_POST['op'] == 6) {
    $resp = $log->login3($_POST['usernameP'], $_POST['passwordP']);
    echo ($resp);
} else if ($_POST['op'] == 7) {
    $resp = $log->recuperarPassword($_POST['newPassword1'], $_POST['newPassword2'], $_POST['idUser']);
    echo ($resp);
} else if ($_POST['op'] == 8) {
    $resp = $log->login2($_POST['username'], $_POST['password']);
    echo ($resp);
} else if ($_POST['op'] == 11) {
    $resp = $log->loginAdmin($_POST['username'], $_POST['password']);
    echo ($resp);
}


?>