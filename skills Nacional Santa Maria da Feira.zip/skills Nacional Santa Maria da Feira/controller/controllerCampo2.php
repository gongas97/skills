<?php declare(strict_types=1); 

require_once '../model/modelCampo2.php';

$c2 = new Medico();

if($_POST['op'] == 1){
    $resp = $c2 -> registarMedico(
        $_POST['nCedula'],
        $_POST['nome'],
        $_POST['nif'],
        $_POST['codPostal'],
        $_POST['morada'],
        $_POST['nacionalidade'],
        $_POST['dataNasc'],
        $_POST['email'],
        $_POST['tel']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $c2 -> getListagemMedicos();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $c2 -> removerMedico($_POST['nCedula']);
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $c2 -> infoAgendamento($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $c2 -> guardaEditMedico(
        $_POST['nCedula'],
        $_POST['nome'],
        $_POST['nif'],
        $_POST['codPostal'],
        $_POST['morada'],
        $_POST['nacionalidade'],
        $_POST['email'],
        $_POST['tel'],
        $_POST['nCedulaOld']
    );
    echo ($resp);

}else if($_POST['op'] == 6){
    $resp = $c2 -> getMedico();
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $c2 -> editarMedico($_POST['nCedula']);
    echo($resp);

}





?>