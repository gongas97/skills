<?php
session_start(); // Start session at the very beginning
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords"
        content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="shortcut icon" href="img/icons/icon-48x48.png" />

    <link rel="canonical" href="https://demo.adminkit.io/forms-layouts.html" />

    <title>Gestão Utilizadores Admin</title>

    <link rel="shortcut icon" href="imagens/Admin/adminLogo.jpg">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">

    <!-- Remove this after purchasing -->
    <link rel="stylesheet" href="css/styleAdmin.css">
    <link rel="stylesheet" href="css/alertaErroSessao.css">
    <link class="js-stylesheet" href="css/light.css" rel="stylesheet">
    <link rel="stylesheet" href="css/datatables.css">
    <script src="js/jquery.js"></script>
    <script src="js/login.js"></script>
    <script src="js/sweatalert.js"></script>
    <script src="js/admin.js"></script>

    <style>
        body {
            opacity: 0;
        }
    </style>
</head>

<?php
    if (isset($_SESSION['admin'])) {
        $idAnunciante = $_SESSION['idAdmin']; 
    ?>

    <body>
        <div class="wrapper">
            <?php include_once 'menuAdmin.php'; ?>


            <div class="container-fluid p-0">
                <main class="content">
                    <div class="container-fluid p-0">
                        <div class="mb-3">
                            <h1 class="h3 d-inline align-middle">Gestão de Utilizadores</h1>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="tab">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item"><a class="nav-link active" href="#tab-1" data-bs-toggle="tab"
                                                role="tab">Users</a>
                                        </li>
                                        <li class="nav-item"><a class="nav-link" href="#tab-2" data-bs-toggle="tab"
                                                role="tab">Logins</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#tab-3" data-bs-toggle="tab"
                                                role="tab">Others</a></li>
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="tab-1" role="tabpanel">
                                            <div class="container-fluid p-0">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="card">
                                                            <div class="card-header">
                                                                <h4 class="card-title">Listagem de Registos Users
                                                                </h4>
                                                            </div>
                                                            <div class="card-body">
                                                                <table id="usersLista" class="table table-striped"
                                                                    style="width:100%">
                                                                    <thead>
                                                                        <tr>
                                                                            <th>Nome</th>
                                                                            <th>Username</th>
                                                                            <th>Email</th>
                                                                            <th>estado</th>
                                                                            <th>Foto</th>
                                                                            <th>Resposta 1</th>
                                                                            <th>Resposta 2</th>
                                                                            <th>Bloquear</th>
                                                                            <th>Desbloquear</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody id="listaUsers">
                                                                        <!-- Os dados serão inseridos aqui dinamicamente -->
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!--  -->

                                        </div>

                                        <div class="tab-pane" id="tab-2" role="tabpanel">
                                            <!-- DATATABLE -->
                                            <br><br>
                                            <div class="container-fluid p-0">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="card">
                                                            <div class="card-header">
                                                                <h4 class="card-title">Lista de Registos Logins</h4>
                                                            </div>
                                                            <div class="card-body">
                                                                <table id="loginsLista" class="table table-striped"
                                                                    style="width:100%">
                                                                    <thead>
                                                                        <tr>
                                                                            <th>ID</th>
                                                                            <th>Nome User</th>
                                                                            <th>Hora</th>
                                                                            <th>IP Origem</th>
                                                                            <th>estado</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody id="listaLogins">
                                                                        <!-- Os dados serão inseridos aqui dinamicamente -->
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="tab-pane" id="tab-3" role="tabpanel">
                                            <!-- DATATABLE -->
                                            <br><br>
                                            <div class="container-fluid p-0">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="card">
                                                            <div class="card-header">
                                                                <h4 class="card-title">Lista de Registos Produtoras</h4>
                                                            </div>
                                                            <div class="card-body">
                                                                <table id="produtorasLista" class="table table-striped"
                                                                    style="width:100%">
                                                                    <thead>
                                                                        <tr>
                                                                            <th>Nome Produtora</th>
                                                                            <th>Username</th>
                                                                            <th>Morada Fiscal</th>
                                                                            <th>Comprovativo</th>
                                                                            <th>Logotipo</th>
                                                                            <th>Status</th>
                                                                            <th>Aprovar Registo</th>
                                                                            <th>Inativar Registo</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody id="listaProdutoras">
                                                                        <!-- Os dados serão inseridos aqui dinamicamente -->
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <?php include_once 'footerAdmin.php'; ?>
        </div>

        <?php
} else {
    echo '<div class="body2">
                <div class="alert-message">
                    <h2>Acesso Negado ou a sua Sessão Expirou!</h2>
                    <p>Quer voltar ao Menu Principal?</p>
                    <a class="homePage" href="index.html">HOME PAGE</a>
                </div>
            </div>';
}
?>


    <script src="js/app.js"></script>
    <script src="js/datatables.js"></script>
</body>

</html>