<nav id="sidebar" class="sidebar js-sidebar">
    <div class="sidebar-content js-simplebar">
        <a class='sidebar-brand'>
            <span class="sidebar-brand-text align-middle">
                <i class="align-middle" style="position: relative; top: -2px;"></i>
                Menu
            </span>
            <svg class="sidebar-brand-icon align-middle" width="32px" height="32px" viewBox="0 0 24 24" fill="none"
                stroke="#FFFFFF" stroke-width="1.5" stroke-linecap="square" stroke-linejoin="miter" color="#FFFFFF"
                style="margin-left: -3px">
                <path d="M12 4L20 8.00004L12 12L4 8.00004L12 4Z"></path>
                <path d="M20 12L12 16L4 12"></path>
                <path d="M20 16L12 20L4 16"></path>
            </svg>
        </a>



        <ul class="sidebar-nav">
            <!-- <li class="sidebar-item text-center">
                <a class="btn-logout" href="#" onclick="logout()">Logout</a>
            </li> -->
            <li class="sidebar-header">Menus</li>
            <!-- <li class="sidebar-item">
                <a class='sidebar-link' href='index.html'>
                    <i class="align-middle" data-feather="home"></i>
                    <span class="align-middle">Home Page</span>
                </a>
            </li> -->
            <li class="sidebar-item">
                <a class='sidebar-link' href='dashboard.php'>
                    <i class="align-middle" data-feather="globe"></i>
                    <span class="align-middle">Dashboard</span>
                </a>
            </li>

            <li class="sidebar-header">Registos</li>
            <li class="sidebar-item">
                <a data-bs-target="#registosAtletas" data-bs-toggle="collapse" class="sidebar-link collapsed"
                    aria-expanded="false" onclick="toggleMenu(this)">
                    <i class="align-middle" data-feather="check-square"></i> <span class="align-middle">Atletas</span>
                </a>
                <ul id="registosAtletas" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                    <li><a class='sidebar-link' href='registo1.php'>Registo</a></li>
                    <li><a class='sidebar-link' href='editar1.php'>Editar</a></li>
                    <li><a class='sidebar-link' href='listagem1.php'>Listagem</a></li>
                </ul>
            </li>

            <li class="sidebar-item">
                <a data-bs-target="#registosMedicos" data-bs-toggle="collapse" class="sidebar-link collapsed"
                    aria-expanded="false" onclick="toggleMenu(this)">
                    <i class="align-middle" data-feather="check-square"></i> <span class="align-middle">Médicos</span>
                </a>
                <ul id="registosMedicos" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                    <li><a class='sidebar-link' href='registo2.php'>Registo</a></li>
                    <li><a class='sidebar-link' href='editar2.php'>Editar</a></li>
                    <li><a class='sidebar-link' href='listagem2.php'>Listagem</a></li>
                </ul>
            </li>

            <li class="sidebar-item">
                <a data-bs-target="#registosConsultas" data-bs-toggle="collapse" class="sidebar-link collapsed"
                    aria-expanded="false" onclick="toggleMenu(this)">
                    <i class="align-middle" data-feather="check-square"></i> <span class="align-middle">Consultas</span>
                </a>
                <ul id="registosConsultas" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                    <li><a class='sidebar-link' href='registo3.php'>Registo</a></li>
                    <li><a class='sidebar-link' href='editar3.php'>Editar</a></li>
                    <li><a class='sidebar-link' href='listagem3.php'>Listagem</a></li>
                </ul>
            </li>

            <!-- <li class="sidebar-item">
                <a data-bs-target="#registoOutros" data-bs-toggle="collapse" class="sidebar-link collapsed"
                    aria-expanded="false" onclick="toggleMenu(this)">
                    <i class="align-middle" data-feather="check-square"></i> <span class="align-middle">Outro</span>
                </a>
                <ul id="registoOutros" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                    <a class="sidebar-item"><a class='sidebar-link' href='registo4.php'>Registo </a>
                        <a class="sidebar-item"><a class='sidebar-link' href='editar4.php'>Editar </a>
                            <a class="sidebar-item"><a class='sidebar-link' href='listagem4.php'>Listagem </a>
            </li> -->
        </ul>
        <li class="sidebar-item">
            <a class='sidebar-link' href='#'>
                <i class="align-middle" data-feather="message-square"></i>
                <span class="align-middle">Outro</span>
            </a>
        </li>
        </ul>
    </div>
</nav>

<div class="main">
    <nav class="navbar navbar-expand navbar-light navbar-bg fixed-top">
        <a class="sidebar-toggle js-sidebar-toggle">
            <i class="hamburger align-self-center"></i>
        </a>

        <!-- Search Form -->
        <form class="d-none d-sm-inline-block">
            <div class="input-group input-group-navbar">
                <input type="text" class="form-control" placeholder="Search…" aria-label="Search">
                <button class="btn" type="button">
                    <i class="align-middle" data-feather="search"></i>
                </button>
            </div>
        </form>

        <!-- Navbar Collapse -->
        <div class="navbar-collapse collapse">
            <ul class="navbar-nav d-none d-lg-flex">
                <li class="nav-item px-2">
                    <a class="nav-link" href="index.html" id="megaDropdown" role="button" aria-haspopup="true"
                        aria-expanded="false">
                        <span>Home Page</span>
                    </a>
                </li>
            </ul>
            <ul class="navbar-nav navbar-align">

                <!-- Fullscreen Button -->
                <li class="nav-item">
                    <a class="nav-icon js-fullscreen d-none d-lg-block" href="#">
                        <div class="position-relative">
                            <i class="align-middle" data-feather="maximize"></i>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </nav>



    <!-- <div class="main">
        <nav class="navbar navbar-expand navbar-light navbar-bg"> -->
    <!-- Home Link -->
    <!-- <ul class="navbar-nav d-none d-lg-flex">
                <li class="nav-item px-2">
                    <a class="nav-link" href="index.html" id="megaDropdown" role="button" aria-haspopup="true"
                        aria-expanded="false">
                        <span>Home Page</span>
                    </a>
                </li>
            </ul> -->

    <!-- Atletas Dropdown -->
    <!-- <div class="dropdown me-3">
                <a class="nav-link dropdown-toggle" href="#" id="atletasDropdown" role="button"
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-user"></i> Atletas
                </a>
                <ul class="dropdown-menu" aria-labelledby="atletasDropdown">
                    <li><a class="dropdown-item" href="registo1.php">Registo</a></li>
                    <li><a class="dropdown-item" href="editar1.php">Editar</a></li>
                    <li><a class="dropdown-item" href="listagem1.php">Listagem</a></li>
                </ul>
            </div> -->

    <!-- Médicos Dropdown -->
    <!-- <div class="dropdown me-3">
                <a class="nav-link dropdown-toggle" href="#" id="medicosDropdown" role="button"
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-user"></i> Médicos
                </a>
                <ul class="dropdown-menu" aria-labelledby="medicosDropdown">
                    <li><a class="dropdown-item" href="registo2.php">Registo</a></li>
                    <li><a class="dropdown-item" href="editar2.php">Editar</a></li>
                    <li><a class="dropdown-item" href="listagem2.php">Listagem</a></li>
                </ul>
            </div> -->

    <!-- Consultas Dropdown -->
    <!-- <div class="dropdown me-3">
                <a class="nav-link dropdown-toggle" href="#" id="consultasDropdown" role="button"
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <i></i> Consultas
                </a>
                <ul class="dropdown-menu" aria-labelledby="consultasDropdown">
                    <li><a class="dropdown-item" href="registo3.php">Registo</a></li>
                    <li><a class="dropdown-item" href="editar3.php">Editar</a></li>
                    <li><a class="dropdown-item" href="listagem3.php">Listagem</a></li>
                </ul>
            </div>

            <a class="nav-link me-3" href="#" id="tarefasLink">
                <i></i> Tarefas
            </a> -->

    <!-- Right-aligned Skills Icon -->
    <!-- <div class="ms-auto">
                <a class="nav-link" href="#" title="Books">
                    <i class="fas fa-book"></i> SKILLS
                </a>
            </div>
        </nav> -->