<?php
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords"
        content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <link rel="shortcut icon" href="img/icons/icon-48x48.png" />

    <link rel="canonical" href="https://demo.adminkit.io/forms-layouts.html" />

    <title>Dashboard</title>


    <!-- BEGIN SETTINGS -->
    <!-- Remove this after purchasing -->
    <link rel="stylesheet" href="css/styleAdmin.css">
    <link rel="stylesheet" href="css/alertaErroSessao.css">
    <link class="js-stylesheet" href="css/light.css" rel="stylesheet">
    <link rel="stylesheet" href="css/datatables.css">
    <script src="js/jquery.js"></script>
    <script src="js/login.js"></script>
    <script src="js/sweatalert.js"></script>
    <script src="js/card.js"></script>
    <style>
        body {
            opacity: 0;
        }
    </style>

</head>

<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-layout="default">
    <div class="wrapper">

        <?php include_once 'menu.php' ?>

        <main class="content">
            <div class="container-fluid p-0">

                <div class="mb-3">
                    <h1 class="h3 d-inline align-middle">Dashboard</h1>
                </div>
                

                <div class="row text-center">
                    <!-- Card for Borrowed Books -->
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Books Borrowed</h5>
                            </div>
                            <div class="card-body">
                                <h2 class="display-4" id="quantidadeLivrosEmprestados"></h2>
                            </div>
                        </div>
                    </div>

                    <!-- Card for Active Members -->
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Active Members</h5>
                            </div>
                            <div class="card-body">
                                <h2 class="display-4" id="quantidadeSociosAtivos"></h2>
                            </div>
                        </div>
                    </div>

                    <!-- Card for Total Registered Books -->
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Total Registered Books</h5>
                            </div>
                            <div class="card-body">
                                <h2 class="display-4" id="quantidadeLivrosRegistados"></h2>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row text-center">
                    <!-- Card for Books Registered Last Week -->
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Books Registered Last Week</h5>
                            </div>
                            <div class="card-body">
                                <h2 class="display-4" id="quantidadeRealizadosEmprestados"></h2>
                            </div>
                        </div>
                    </div>

                    <!-- Card for Member with Most Loans -->
                    <div class="col-md-8"> 
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Top Borrowing Member</h5>
                            </div>
                            <div class="card-body">
                                <h2 class="display-4" id="topSocioNome"></h2>
                                <p>Loans: <span id="topSocioCount"></span></p>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="container-fluid p-0">

                    <div class="mb-3">
                        <h1 class="h3 d-inline align-middle">Listagem de Empréstimos em Atraso de Devolução</h1>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title">Empréstimos</h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Cod</th>
                                                    <th scope="col">Nome Sócio</th>
                                                </tr>
                                            </thead>
                                            <tbody id="listagemEmprestimosAtrasados">
                                                <!-- Os dados dos funcionários serão inseridos aqui via JavaScript -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container-fluid p-0">

                    <div class="mb-3">
                        <h1 class="h3 d-inline align-middle">Listagem Sócios Inativos</h1>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title">
                                        <i class="fas fa-user"></i> <!-- Font Awesome user icon -->Sócios
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Nif</th>
                                                    <th scope="col">Nome</th>
                                                    <th scope="col">Atividade</th>
                                                </tr>
                                            </thead>
                                            <tbody id="listagemSociosInativos">
                                                <!-- Os dados dos funcionários serão inseridos aqui via JavaScript -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </main>

        <?php include_once 'footer.php' ?>

    </div>

    <script src="js/app.js"></script>
    <script src="js/datatables.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</body>

</html>