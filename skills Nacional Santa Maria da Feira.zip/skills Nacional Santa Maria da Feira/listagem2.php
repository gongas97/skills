<?php

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords"
        content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <link rel="shortcut icon" href="img/icons/icon-48x48.png" />

    <link rel="canonical" href="https://demo.adminkit.io/forms-layouts.html" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <title>Listagem Médicos</title>



    <!-- BEGIN SETTINGS -->
    <!-- Remove this after purchasing -->
    <link rel="stylesheet" href="css/styleAdmin.css">
    <link rel="stylesheet" href="css/alertaErroSessao.css">
    <link class="js-stylesheet" href="css/light.css" rel="stylesheet">
    <link rel="stylesheet" href="css/datatables.css">
    <script src="js/jquery.js"></script>
    <script src="js/login.js"></script>
    <script src="js/sweatalert.js"></script>
    <script src="js/campo2.js"></script>
    <style>
        body {
            opacity: 0;
        }
    </style>

</head>

<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-layout="default">
    <div class="wrapper">

        <?php include_once 'menu.php' ?>

        <main class="content">
            <div class="container-fluid p-0">

                <div class="mb-3">
                    <h1 class="h3 d-inline align-middle">Listagem</h1>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Médicos</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th scope="col">Numero Cédula</th>
                                                <th scope="col">Nome</th>
                                                <th scope="col">Nif</th>
                                                <th scope="col">Telemóvel</th>
                                                <th scope="col">Informações</th>
                                                <th scope="col">Remover</th>
                                            </tr>
                                        </thead>
                                        <tbody id="listagemMedicos">
                                            <!-- Os dados dos funcionários serão inseridos aqui via JavaScript -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php include_once 'footer.php' ?>

    </div>
    </div>

    <script src="js/app.js"></script>
    <script src="js/datatables.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</html>

<?php

?>