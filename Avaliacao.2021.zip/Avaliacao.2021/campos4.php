<?php
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Encomendas</title>
    <link rel="stylesheet" href="assets/css/datatables.css">
    <link rel="stylesheet" href="assets/css/select2.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">

    <script src="assets/js/lib/jquery.js"></script>
    <script src="assets/js/lib/datatables.js"></script>
    <script src="assets/js/lib/select2.js"></script>
    <script src="assets/js/lib/sweatalert.js"></script>
    <script src="assets/js/lib/bootstrap.js"></script>
    <script src="assets/js/campo4.js"></script>
</head>

<body>

    <?php include_once 'menu.php' ?>

    <div class="container mt-5">
        <div class="card">
            <h5 class="card-header">Encomendas</h5>
            <div class="card-body">
                <h5 class="card-title">Ordem de Encomendas:</h5>
                <form class="row g-3">
                    <div class="col-md-3">
                        <label for="campo4_1" class="form-label">Numero:</label>
                        <input type="number" class="form-control" id="campo4_1">
                    </div>

                    <div class="col-md-3">
                        <label for="campo4_2" class="form-label">Cliente:</label>
                        <select class="form-control" id="campo4_2"></select>
                    </div>

                    <div class="col-md-6">
                        <label for="campo4_3" class="form-label">Data/Hora:</label>
                        <input type="datetime-local" class="form-control" id="campo4_3">
                    </div>

                    <div class="col-12">
                        <button type="button" class="btn btn-primary" onclick="registaCampo4()">Adicionar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    
    <div class="container mt-5">
        <div class="card">
            <h5 class="card-header">Produtos/Encomendas</h5>
            <div class="card-body">
                <h5 class="card-title">Produtos da Encomenda</h5>
                <form class="row g-3">

                    <div class="col-md-6">
                        <label for="campo5_1" class="form-label">Ordem</label>
                        <select class="form-control" id="campo5_1">
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="campo5_2" class="form-label">Produtos</label>
                        <select class="form-control" id="campo5_2">
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="campo5_3" class="form-label">Valor Portes:</label>
                        <input type="number" class="form-control" id="campo5_3">
                    </div>

                    <div class="col-md-6">
                        <label for="campo5_4" class="form-label">Quantidade:</label>
                        <input type="number" class="form-control" id="campo5_4">
                    </div>
                    
                    <div class="col-12">
                        <button type="button" class="btn btn-primary" onclick="registaCampo5()">Adicionar Produtos á
                            Encomenda</button>
                        </div>
                    </form>
                </div>
            </div>
    </div>
    
    
    <div class="container mt-5">
        <div class="card">
            <h5 class="card-header">Encomendas por cliente</h5>
            <div class="card-body">
                <h5 class="card-title">Listagem</h5>

                <div class="mb-3">
                    <label for="campo4_2_1" class="form-label">Filtro Cliente:</label>
                    <select class="form-select" id="campo4_2_1" onchange="filtrarTabela(this.value)">
                    </select>
                </div>

                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Numero Encomenda</th>
                            <th scope="col">Data/Hora</th>
                            <th scope="col">Info Produtos</th>
                            <th scope="col">Remover</th>
                        </tr>
                    </thead>

                    <tbody id="listagemCampo4"></tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" id="campo4Modal" tabindex="-1" aria-labelledby="campo4ModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="campo4ModalLabel">Info</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="campo4_1Form">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">ID Produto</th>
                                <th scope="col">Descrição</th>
                                <th scope="col">Valor</th>
                                <th scope="col">Valor do VAT</th>
                                <th scope="col">Foto</th>
                            </tr>
                        </thead>
                        <tbody id="listagemCampo5"></tbody>
                    </table>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>
</body>

</html>

<?php
?>