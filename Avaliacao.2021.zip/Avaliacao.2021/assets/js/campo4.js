// ################################ REGISTO ################################ //

function registaCampo4() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("numero", $('#campo4_1').val());
    dados.append("cliente", $('#campo4_2').val());
    dados.append("dataHora", $('#campo4_3').val());

    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                getCampo5();
                alerta("Encomenda Adicionada", obj.msg, "success");
                getListaCampo4();
            } else {
                alerta("Encomenda ", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function registaCampo5() {

    let dados = new FormData();
    dados.append("op", 7);
    dados.append("ordem", $('#campo5_1').val());
    dados.append("produto", $('#campo5_2').val());
    dados.append("valor", $('#campo5_3').val());
    dados.append("qtd", $('#campo5_4').val());

    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        let obj = JSON.parse(msg);
        if (obj.flag) {
            alerta("Produtos/Encomenda", obj.msg, "success");

        } else {
            alerta("Produtos/Encomenda", obj.msg, "error");
        }
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

// ################################ REMOVER ################################ //

function removerCampo4(numero) {

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("numero", numero);

    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Removida", obj.msg, "success");
                filtrarTabela();
                getCampo5();
            } else {
                alerta("Campo 4", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}


// ################################ INFO ################################ //

function infoProdutos(numero) {

    $('#campo4Modal').modal('show')

    let dados = new FormData();
    dados.append("op", 4);
    dados.append("numero", numero);

    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

    .done(function (msg) {
            $('#listagemCampo5').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}


// ################################ GET ################################ //

function getCampo4() {
    
    let dados = new FormData();
    dados.append("op", 6);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo4_2').html(msg);
            $('#campo4_2_1').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getCampo5() {
    
    let dados = new FormData();
    dados.append("op", 8);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo5_1').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getCampo5_1() {
    
    let dados = new FormData();
    dados.append("op", 9);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo5_2').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ FILTRAR ################################ //


function filtrarTabela() {
  
    let dados = new FormData();
    dados.append('cliente', $('#campo4_2_1').val());
    dados.append('op', 2);
  
    $.ajax({
        url: "assets/controller/controllerCampo4.php",
      method: "POST",
      data: dados,
      dataType: "html",
      cache: false,
      contentType: false,
      processData: false,
    })
    .done(function(msg) {
        $('#listagemCampo4').html(msg);
    })
    .fail(function(jqXHR, textStatus) {
      alert("Request failed: " + textStatus);
    });
  }

  $('#campo4_2_1').change(filtrarTabela);


function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(document).ready(function () {
    filtrarTabela();
    getCampo4();
    getCampo5();
    getCampo5_1();
});