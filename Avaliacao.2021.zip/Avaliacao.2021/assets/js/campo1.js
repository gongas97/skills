// ################################ REGISTO ################################ //

function registaCampo1() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("descr", $('#campo1_2').val());
    dados.append("valor", $('#campo1_3').val());
    dados.append("tipo", $('#campo1_4').val());
    dados.append("foto", $('#campo1_5').prop('files')[0]);
    dados.append("estado", $('#campo1_6').val());
    dados.append("stock", $('#campo1_7').val());

    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Produto Registado", obj.msg, "success");
                getListaCampo1();
            } else {
                alerta("Produto", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ LISTAGEM ################################ //

function getListaCampo1() {

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemCampo1').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ REMOVER ################################ //

function removerCampo1(id) {

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Removido", obj.msg, "success");
                getListaCampo1();
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}


// ################################ EDIÇÃO ################################ //

function editarcampo1(id) {


    let dados = new FormData();
    dados.append("op", 4);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#campo1_1Edit').val(obj.id);
            $('#campo1_2Edit').val(obj.descricao);
            $('#campo1_3Edit').val(obj.valor);
            $('#campo1_4Edit').val(obj.id_type);
            $('#campo1_5Edit').attr('src', obj.img);
            $('#campo1_6Edit').val(obj.id_estado);
            $('#campo1_7Edit').val(obj.stock);

            $('#btnGuardar').attr("onclick", "guardaEditCampo1(" + obj.id + ")")

            $('#campo1Modal').modal('show')
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function guardaEditCampo1(idOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("id", $('#campo1_1Edit').val());
    dados.append("descr", $('#campo1_2Edit').val());
    dados.append("valor", $('#campo1_3Edit').val());
    dados.append("tipo", $('#campo1_4Edit').val());
    dados.append("foto", $('#campo1_5Edit').prop('files')[0]);
    dados.append("estado", $('#campo1_6Edit').val());
    dados.append("stock", $('#campo1_7Edit').val());
    dados.append("idOld", idOld);

    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Editado", obj.msg, "success");
                $('#campo1Modal').modal('hide')
                getListaCampo1();
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}


// ################################ GET ################################ //

function getCampo1() {
    
    let dados = new FormData();
    dados.append("op", 6);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo1_4').html(msg);
            $('#campo1_4Edit').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getCampo1_1() {
    
    let dados = new FormData();
    dados.append("op", 7);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo1_6').html(msg);
            $('#campo1_6Edit').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}


function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getListaCampo1();
    getCampo1();
    getCampo1_1();
});