

// ################################ REGISTO ################################ //

function registaCampo3() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("nif", $('#campo3_1').val());
    dados.append("nome", $('#campo3_2').val());
    dados.append("morada", $('#campo3_3').val());
    dados.append("email", $('#campo3_4').val());
    dados.append("tel", $('#campo3_5').val());
    dados.append("tipo", $('#campo3_6').val());

    $.ajax({
        url: "assets/controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Cliente Registado", obj.msg, "success");
                getListaCampo3();
                getCampo3();
            } else {
                alerta("Cliente", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ LISTAGEM ################################ //

function getListaCampo3() {

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemCampo3').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ REMOVER ################################ //

function removerCampo3(nif) {

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("nif", nif);

    $.ajax({
        url: "assets/controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Campo 3", obj.msg, "success");
                getListaCampo3();
            } else {
                alerta("Campo 3", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}


// ################################ EDIÇÃO ################################ //

function editarCampo3(nif) {


    let dados = new FormData();
    dados.append("op", 4);
    dados.append("nif", nif);

    $.ajax({
        url: "assets/controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#campo3_1Edit').val(obj.nif);
            $('#campo3_2Edit').val(obj.nome);
            $('#campo3_3Edit').val(obj.morada);
            $('#campo3_4Edit').val(obj.email);
            $('#campo3_5Edit').val(obj.telefone);
            $('#campo3_6Edit').val(obj.id_type);


            $('#btnGuardar').attr("onclick", "guardaEditCampo3(" + obj.nif + ")")

            $('#campo3Modal').modal('show')
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function guardaEditCampo3(nifOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("nif", $('#campo3_1Edit').val());
    dados.append("nome", $('#campo3_2Edit').val());
    dados.append("morada", $('#campo3_3Edit').val());
    dados.append("email", $('#campo3_4Edit').val());
    dados.append("tel", $('#campo3_5Edit').val());
    dados.append("tipo", $('#campo3_6Edit').val());
    dados.append("nifOld", nifOld);

    $.ajax({
        url: "assets/controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Editado", obj.msg, "success");
                $('#campo3Modal').modal('hide')
                getListaCampo3();
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}


// ################################ GET ################################ //

function getCampo3() {
    
    let dados = new FormData();
    dados.append("op", 6);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo3_6').html(msg);
            $('#campo3_6Edit').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}



function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getListaCampo3();
    getCampo3();
});