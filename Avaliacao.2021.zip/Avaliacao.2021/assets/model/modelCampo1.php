<?php

require_once 'connection.php';

class Campo1
{

    // ################################ REGISTO ################################ //

    function registarCampo1($descr, $valor, $tipo, $foto, $estado, $stock) {
        global $conn;
        $msg = "";
        $flag = true;
    
        $sqlGetVAT = "SELECT vat.value FROM vat, type_product
                      WHERE type_product.id_vat = vat.id AND type_product.id = '".$tipo."'";
        $result = $conn->query($sqlGetVAT);
    
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $vatValue = $row['value'];
            $valorComVAT = $valor + ($valor * $vatValue / 100);
        } else {
            $flag = false;
            $msg = "Erro: Não foi possível obter o valor do VAT.";
        }
    
        if ($flag) {
            $resp = $this->uploads($foto, $descr);
            $resp = json_decode($resp, TRUE);
    
            if ($resp['flag']) {
                $sql = "INSERT INTO product (descricao, valor, id_type, img, id_estado, stock) 
                        VALUES ('" . $descr . "','" . $valorComVAT . "','" . $tipo . "','" . $resp['target'] . "','" . $estado . "','" . $stock . "')";
            } else {
                $sql = "INSERT INTO product (descricao, valor, id_type, id_estado, stock) 
                        VALUES ('" . $descr . "','" . $valorComVAT . "','" . $tipo . "','" . $estado . "','" . $stock . "')";
            }
    
            if ($conn->query($sql) === TRUE) {
                $msg = "Registado com sucesso!";
            } else {
                $flag = false;
                $msg = "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    
        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );
    
        $conn->close();
    
        return ($resp);
    }

    // ################################ LISTAGEM ################################ //
    function getListagemCampo1()
    {
        global $conn;
        $msg = "";

        $sql = "SELECT product.*, type_product.descricao AS typeP, product_state.descricao AS estadoP FROM product, type_product, product_state
        WHERE product.id_type = type_product.id 
        AND product.id_estado = product_state.id";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'><img class='img-size' src='" . $row['img'] . "'></th>";
                $msg .= "<th scope='row'>" . $row['descricao'] . "</th>";
                $msg .= "<td>" . $row['valor'] . " €</td>";
                $msg .= "<td>" . $row['typeP'] . "</td>";
                $msg .= "<td>" . $row['estadoP'] . "</td>";
                $msg .= "<td>" . $row['stock'] . " UN</td>";
                $msg .= "<td><button class='btn btn-warning' onclick='editarcampo1(" . $row['id'] . ")'><i class='fas fa-pencil-alt'></i></button></td>";
                $msg .= "<td><button class='btn btn-danger' onclick='removerCampo1(" . $row['id'] . ")'><i class='fas fa-trash'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    // ################################ REMOVER ################################ //
    function removerCampo1($id)
{
    global $conn;
    $flag = false;
    $msg = "";

    $sqlCheckEstado = "SELECT id_estado FROM product WHERE id = '" . $id . "'";
    $result = $conn->query($sqlCheckEstado);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['id_estado'] == 2) {
            $sqlDelete = "DELETE FROM product WHERE id = '" . $id . "'";
            if ($conn->query($sqlDelete) === TRUE) {
                $msg = "Removido com sucesso!";
                $flag = true;
            } else {
                $msg = "Erro ao remover registro: " . $conn->error;
            }
        } else {
            $msg = "Só podem ser removidos Produtos no Estado Inativo.";
        }
    } else {
        $msg = "Produto não encontrado.";
    }

    $conn->close();

    return json_encode(array("flag" => $flag, "msg" => $msg));
}

    // ################################ EDITAR ################################ //
    function editarcampo1($id)
    {
       global $conn;
        $row = "";

        $sql = "SELECT * FROM product WHERE id =".$id;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function guardarEditCampo1($id, $descr, $valor, $tipo, $foto, $estado, $stock, $idOld)
    {
         global $conn;
        $msg = "";
        $flag = true;
        $sql = "";

        $resp = $this -> uploads($foto, $id);
        $resp = json_decode($resp, TRUE);

        if ($resp['flag']) {
            $sql = "UPDATE product SET id = '".$id."', descricao = '".$descr."', valor = '".$valor."', id_type = '".$tipo."', img = '".$resp['target']."', id_estado = '".$estado."', stock = '".$stock."' WHERE id = ".$idOld;
        } else {
            $sql = "UPDATE product SET id = '".$id."', descricao = '".$descr."', valor = '".$valor."', id_type = '".$tipo."', id_estado = '".$estado."', stock = '".$stock."' WHERE id = ".$idOld;
        }

        if ($conn->query($sql) === TRUE) {
            $msg = "Editada com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);
    }

    // ################################ GETS ################################ //

    function getsCampo1()
    {
        global $conn;
        $msg = "<option selected>Escolha um Type</option>";

        $sql = "SELECT * FROM type_product";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Types registados</option>";

        }
        $conn->close();

        return ($msg);
    }

    function getsCampo1_1()
    {
        global $conn;
        $msg = "<option selected>Escolha um Estado</option>";

        $sql = "SELECT * FROM product_state";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Estados registados</option>";

        }
        $conn->close();

        return ($msg);
    }

    // ################################ DIRETORIO FOTO ################################ //
    function updateFoto($diretorio, $id)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "UPDATE product SET img = '" . $diretorio . "' WHERE id = " . $id;

        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        return ($resp);
    }
    function uploads($img, $id)
    {

        $dir = "../imagens/Campo3" . $id . "/";
        $dir1 = "assets/imagens/Campo3" . $id . "/";
        $flag = false;
        $targetBD = "";

        if (!is_dir($dir)) {
            if (!mkdir($dir, 0777, TRUE)) {
                die("Erro não é possivel criar o diretório");
            }
        }
        if (array_key_exists('foto', $img)) {
            if (is_array($img)) {
                if (is_uploaded_file($img['foto']['tmp_name'])) {
                    $fonte = $img['foto']['tmp_name'];
                    $ficheiro = $img['foto']['name'];
                    $end = explode(".", $ficheiro);
                    $extensao = end($end);

                    $newName = "Campo3" . date("YmdHis") . "." . $extensao;

                    $target = $dir . $newName;
                    $targetBD = $dir1 . $newName;

                    $flag = move_uploaded_file($fonte, $target);

                }
            }
        }
        return (json_encode(
            array(
                "flag" => $flag,
                "target" => $targetBD
            )
        ));


    }


}
?>