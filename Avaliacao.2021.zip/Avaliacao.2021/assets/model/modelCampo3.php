<?php

require_once 'connection.php';

class Campo3
{

    // ################################ REGISTO ################################ //

    function registarCampo3($nif, $nome, $morada, $email, $tel, $tipo)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "INSERT INTO client ( nif, nome, morada, email, telefone, id_type) VALUES ('" . $nif . "','" . $nome . "','" . $morada . "','" . $email . "','" . $tel . "','" . $tipo . "')";


        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com sucesso!";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }


        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return ($resp);


    }

    // ################################ LISTAGEM ################################ //
    function getListagemCampo3()
    {
        global $conn;
        $msg = "";

        $sql = "SELECT client.*, type_client.descricao FROM client, type_client WHERE client.id_type = type_client.id";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['nif'] . "</th>";
                $msg .= "<td>" . $row['nome'] . "</td>";
                $msg .= "<td>" . $row['email'] . "</td>";
                $msg .= "<td>" . $row['descricao'] . "</td>";
                $msg .= "<td><button class='btn btn-warning' onclick='editarCampo3(" . $row['nif'] . ")'><i class='fas fa-pencil-alt'></i></button></td>";
                $msg .= "<td><button class='btn btn-danger' onclick='removerCampo3(" . $row['nif'] . ")'><i class='fas fa-trash'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    // ################################ REMOVER ################################ //
    function removerCampo3($nif)
    {

        global $conn;
        $flag = false;
        $msg = "";

        $sql = "DELETE FROM client WHERE nif = '" . $nif . "';";

        if ($conn->query($sql) === TRUE) {
            $msg = "Removido com sucesso!";
            $flag = true;
        } else {
            $msg = "Error deleting record: " . $conn->error;
        }

        $conn->close();

        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    // ################################ EDITAR ################################ //
    function editarCampo3($nif)
    {
       global $conn;
        $row = "";

        $sql = "SELECT * FROM client WHERE nif =".$nif;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function guardarEditCampo3($nif, $nome, $morada, $email, $tel, $tipo, $nifOld)
    {
         global $conn;
        $msg = "";
        $flag = true;
        $sql = "";

        $sql = "UPDATE client SET nif = '".$nif."', nome = '".$nome ."', morada = '".$morada."', email = '".$email."', telefone = '".$tel."', id_type = '".$tipo."' WHERE nif = ".$nifOld;


        if ($conn->query($sql) === TRUE) {
            $msg = "Editada com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);
    }

    // ################################ GETS ################################ //

    function getsCampo3()
    {
        global $conn;
        $msg = "<option selected>Escolha um Type</option>";

        $sql = "SELECT * FROM type_client";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Types registados</option>";

        }
        $conn->close();

        return ($msg);
    }

    // ################################ DIRETORIO FOTO ################################ //
    function updateFoto($diretorio, $id)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "UPDATE campo3 SET foto = '" . $diretorio . "' WHERE id = " . $id;

        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        return ($resp);
    }
    function uploads($img, $id)
    {

        $dir = "../imagens/Campo3" . $id . "/";
        $dir1 = "assets/imagens/Campo3" . $id . "/";
        $flag = false;
        $targetBD = "";

        if (!is_dir($dir)) {
            if (!mkdir($dir, 0777, TRUE)) {
                die("Erro não é possivel criar o diretório");
            }
        }
        if (array_key_exists('foto', $img)) {
            if (is_array($img)) {
                if (is_uploaded_file($img['foto']['tmp_name'])) {
                    $fonte = $img['foto']['tmp_name'];
                    $ficheiro = $img['foto']['name'];
                    $end = explode(".", $ficheiro);
                    $extensao = end($end);

                    $newName = "Campo3" . date("YmdHis") . "." . $extensao;

                    $target = $dir . $newName;
                    $targetBD = $dir1 . $newName;

                    $flag = move_uploaded_file($fonte, $target);

                }
            }
        }
        return (json_encode(
            array(
                "flag" => $flag,
                "target" => $targetBD
            )
        ));


    }


}
?>