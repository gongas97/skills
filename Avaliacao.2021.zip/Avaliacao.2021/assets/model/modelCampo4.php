<?php

require_once 'connection.php';

class Campo4
{

    // ################################ REGISTO ################################ //

    function registarCampo4($numero, $cliente, $dataHora)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "INSERT INTO order_client (numero, id_client, dth) VALUES ('" . $numero . "','" . $cliente . "','" . $dataHora . "')";


        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com sucesso!";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }


        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return ($resp);


    }

    function registarCampo5($ordem, $produto, $valor, $qtd)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $sqlCheckStock = "SELECT product.stock FROM product WHERE id = '" . $produto . "'";
        $result = $conn->query($sqlCheckStock);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $atualStock = $row['stock'];

            if ($atualStock >= $qtd) {
                $newStock = $atualStock - $qtd;
                $sqlUpdateStock = "UPDATE product SET stock = '" . $newStock . "' WHERE id = '" . $produto . "'";
                if ($conn->query($sqlUpdateStock) === TRUE) {
                    if ($newStock == 0) {
                        $sqlUpdateState = "UPDATE product SET id_estado = 2 WHERE id = '" . $produto . "'";
                        if ($conn->query($sqlUpdateState) !== TRUE) {
                            $flag = false;
                            $msg = "Error: " . $sqlUpdateState . "<br>" . $conn->error;
                        }
                    }

                    if ($flag) {
                        $sql = "INSERT INTO product_order (id_order, id_product, valor, quant) VALUES ('" . $ordem . "', '" . $produto . "', '" . $valor . "', '" . $qtd . "')";
                        if ($conn->query($sql) === TRUE) {
                            $msg = "Registado com sucesso!";
                        } else {
                            $flag = false;
                            $msg = "Error: " . $sql . "<br>" . $conn->error;
                        }
                    }
                } else {
                    $flag = false;
                    $msg = "Error: " . $sqlUpdateStock . "<br>" . $conn->error;
                }
            } else {
                $flag = false;
                $msg = "Quantidade insuficiente em estoque.";
            }
        } else {
            $flag = false;
            $msg = "Produto não encontrado.";
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return ($resp);
    }

    // ################################ LISTAGEM ################################ //
    function filtro($cliente)
    {
        global $conn;
        $msg = "";

        $stmt = $conn->prepare("SELECT order_client.numero, order_client.dth FROM order_client, client WHERE order_client.id_client = client.nif AND client.nif = ?");
        $stmt->bind_param("i", $cliente);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['numero'] . "</th>";
                $msg .= "<td>" . $row['dth'] . "</td>";
                $msg .= "<td><button class='btn btn-info' onclick='infoProdutos(" . $row['numero'] . ")'><i class='fas fa-info-circle'></i></button></td>";
                $msg .= "<td><button class='btn btn-danger' onclick='removerCampo4(" . $row['numero'] . ")'><i class='fas fa-trash'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td colspan='4'>Sem Registos</td>";
            $msg .= "</tr>";
        }

        $stmt->close();
        $conn->close();

        return $msg;
    }

    // ################################ REMOVER ################################ //
    function removerCampo4($numero)
    {

        global $conn;
        $flag = false;
        $msg = "";

        $sql = "DELETE FROM order_client WHERE numero = '" . $numero . "';";

        if ($conn->query($sql) === TRUE) {
            $msg = "Removida com sucesso!";
            $flag = true;
        } else {
            $msg = "Error deleting record: " . $conn->error;
        }

        $conn->close();

        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    // ################################ INFO ################################ //
    function infoProdutos($orderNumber)
{
    global $conn;
    $msg = "";
    $flag = true;
    $totalValor = 0;

    $sql = "SELECT
                product_order.id_product,
                product.descricao,
                (product.valor * product_order.quant) AS valorP,
                product.img,
                vat.value
            FROM product_order
            JOIN product ON product_order.id_product = product.id
            JOIN type_product ON product.id_type = type_product.id
            JOIN vat ON type_product.id_vat = vat.id
            WHERE product_order.id_order = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $orderNumber);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $msg .= "<tr>";
            $msg .= "<td>" . $row['id_product'] . "</td>";
            $msg .= "<td>" . $row['descricao'] . "</td>";
            $msg .= "<td>" . $row['valorP'] . " €</td>";
            $msg .= "<td>" . $row['value'] . " %</td>";
            $msg .= "<td><img class='img-size1' src='" . $row['img'] . "'></td>";
            $msg .= "</tr>";

            $totalValor += $row['valorP'];
        }
        
        $msg .= "<tr>";
        $msg .= "<td colspan='1'></td>";
        $msg .= "<td>Total:</td>";
        $msg .= "<td>" . $totalValor . " €</td>";
        $msg .= "<td></td>"; 
        $msg .= "<td></td>"; 
        $msg .= "</tr>";
    } else {
        $flag = false;
        $msg .= "<tr><td colspan='5'>Nenhum produto encontrado para este pedido.</td></tr>";
    }

    $stmt->close();
    $conn->close();

    return $msg;
}

    // ################################ GETS ################################ //

    function getsCampo4()
    {
        global $conn;
        $msg = "<option selected>Escolha um Cliente</option>";

        $sql = "SELECT * FROM client";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['nif'] . "'>" . $row['nome'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Clientes registados</option>";

        }
        $conn->close();

        return ($msg);
    }

    function getsCampo5()
    {
        global $conn;
        $msg = "<option selected>Escolha uma Ordem de Encomenda</option>";

        $sql = "SELECT * FROM order_client";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['numero'] . "'>" . $row['numero'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Ordens registados</option>";

        }
        $conn->close();

        return ($msg);
    }

    function getsCampo5_1()
    {
        global $conn;
        $msg = "<option selected>Escolha um Produto</option>";

        $sql = "SELECT * FROM product";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Produtos registados</option>";

        }
        $conn->close();

        return ($msg);
    }


}
?>