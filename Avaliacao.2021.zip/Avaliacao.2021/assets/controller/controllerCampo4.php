<?php declare(strict_types=1); 

require_once '../model/modelCampo4.php';

$c4 = new Campo4();

if($_POST['op'] == 1){
    $resp = $c4 -> registarCampo4(
        $_POST['numero'],
        $_POST['cliente'],
        $_POST['dataHora']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $c4 -> filtro($_POST['cliente']);
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $c4 -> removerCampo4($_POST['numero']);
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $c4 -> infoProdutos($_POST['numero']);
    echo($resp);

}else if($_POST['op'] == 6){
    $resp = $c4 -> getsCampo4();
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $c4 -> registarCampo5(
        $_POST['ordem'],
        $_POST['produto'],
        $_POST['valor'],
        $_POST['qtd']
    );
    echo ($resp);

}else if($_POST['op'] == 8){
    $resp = $c4 -> getsCampo5();
    echo($resp);

}else if($_POST['op'] == 9){
    $resp = $c4 -> getsCampo5_1();
    echo($resp);

}else if($_POST['op'] == 2){
    $resp = $c4 -> filtro($_POST['cliente']);
    echo($resp);

}





?>