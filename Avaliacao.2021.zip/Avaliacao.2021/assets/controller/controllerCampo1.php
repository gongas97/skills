<?php declare(strict_types=1); 

require_once '../model/modelCampo1.php';

$c1 = new Campo1();

if($_POST['op'] == 1){
    $resp = $c1 -> registarCampo1(
        $_POST['descr'],
        $_POST['valor'],
        $_POST['tipo'],
        $_FILES,
        $_POST['estado'],
        $_POST['stock']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $c1 -> getListagemCampo1();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $c1 -> removerCampo1($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $c1 -> editarcampo1($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $c1 -> guardarEditCampo1(
        $_POST['id'],
        $_POST['descr'],
        $_POST['valor'],
        $_POST['tipo'],
        $_FILES,
        $_POST['estado'],
        $_POST['stock'],
        $_POST['idOld']
    );
    echo ($resp);

}else if($_POST['op'] == 6){
    $resp = $c1 -> getsCampo1();
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $c1 -> getsCampo1_1();
    echo($resp);

}





?>