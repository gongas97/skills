<?php declare(strict_types=1);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes</title>
    <link rel="stylesheet" href="assets/css/datatables.css">
    <link rel="stylesheet" href="assets/css/select2.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">

    <script src="assets/js/lib/jquery.js"></script>
    <script src="assets/js/lib/datatables.js"></script>
    <script src="assets/js/lib/select2.js"></script>
    <script src="assets/js/lib/sweatalert.js"></script>
    <script src="assets/js/lib/bootstrap.js"></script>
    <script src="assets/js/campo3.js"></script>
</head>

<body>

    <?php include_once 'menu.php' ?>

    <div class="container mt-5">
        <div class="card">
            <h5 class="card-header">Clientes</h5>
            <div class="card-body">
                <h5 class="card-title">REGISTAR CLIENTE</h5>
                <form class="row g-3">
                    <div class="col-md-6">
                        <label for="campo3_1" class="form-label">Nif:</label>
                        <input type="number" class="form-control" id="campo3_1">
                    </div>
                    <div class="col-md-3">
                        <label for="campo3_2" class="form-label">Nome:</label>
                        <input type="text" class="form-control" id="campo3_2">
                    </div>

                    <div class="col-md-3">
                        <label for="campo3_3" class="form-label">Morada:</label>
                        <input type="tex" class="form-control" id="campo3_3">
                    </div>

                    <div class="col-md-6">
                        <label for="campo3_4" class="form-label">Email:</label>
                        <input type="email" class="form-control" id="campo3_4">
                    </div>

                    <div class="col-md-6">
                        <label for="campo3_5" class="form-label">Telemovel:</label>
                        <input type="tel" class="form-control" id="campo3_5">
                    </div>

                    <div class="col-md-6">
                        <label for="campo3_6" class="form-label">Tipo:</label>
                        <select class="form-control" id="campo3_6"></select>
                    </div>

                    <div class="col-12">
                        <button type="button" class="btn btn-primary" onclick="registaCampo3()">Registar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container mt-5">
        <div class="card">
            <h5 class="card-header">Listagem de clientes</h5>
            <div class="card-body">
                <h5 class="card-title">Listagem</h5>
                <div class="table-responsive">
                    <table class="table table-striped" id="tblCampo3">
                        <thead>
                            <tr>
                                <th scope="col">Nif</th>
                                <th scope="col">Nome</th>
                                <th scope="col">Email</th>
                                <th scope="col">Tipo</th>
                                <th scope="col">Editar</th>
                                <th scope="col">Remover</th>
                            </tr>
                        </thead>
                        <tbody id="listagemCampo3"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="campo3Modal" tabindex="-1" aria-labelledby="campo3ModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="campo3ModalLabel">Editar</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="campo3_1Form">

                        <div class="mb-3">
                            <label for="campo3_1Edit" class="form-label">Nif</label>
                            <input type="number" class="form-control" id="campo3_1Edit" disabled>
                        </div>

                        <div class="mb-3">
                            <label for="campo3_2Edit" class="form-label">Nome</label>
                            <input type="text" class="form-control" id="campo3_2Edit">
                        </div>

                        <div class="mb-3">
                            <label for="campo3_3Edit" class="form-label">Morada</label>
                            <input type="text" class="form-control" id="campo3_3Edit">
                        </div>

                        <div class="mb-3">
                            <label for="campo3_4Edit" class="form-label">Email</label>
                            <input type="email" class="form-control" id="campo3_4Edit">
                        </div>

                        <div class="mb-3">
                            <label for="campo3_5Edit" class="form-label">Telefone</label>
                            <input type="tel" class="form-control" id="campo3_5Edit">
                        </div>

                        <div class="mb-3">
                            <label for="campo3_6Edit" class="form-label">Tipo</label>
                            <select class="form-control" id="campo3_6Edit"></select>
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="btnGuardar">Guardar</button>
                </div>
            </div>
        </div>
    </div>
</body>

</html>