<?php
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atribuição</title>
    <link rel="stylesheet" href="assets/css/datatables.css">
    <link rel="stylesheet" href="assets/css/select2.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">

    <script src="assets/js/lib/jquery.js"></script>
    <script src="assets/js/lib/datatables.js"></script>
    <script src="assets/js/lib/select2.js"></script>
    <script src="assets/js/lib/sweatalert.js"></script>
    <script src="assets/js/lib/bootstrap.js"></script>
    <script src="assets/js/campo4.js"></script>
</head>

<body>

    <?php include_once 'menu.php' ?>

    <div class="container mt-5">
        <div class="card">
            <h5 class="card-header">Atribuição de Pontos</h5>
            <div class="card-body">
                <h5 class="card-title">Atribuir Pontos</h5>
                <form class="row g-3">
                    <div class="col-md-3">
                        <label for="campo4_2" class="form-label">Concorrente:</label>
                        <select class="form-control" id="campo4_2"></select>
                    </div>

                    <div class="col-md-3">
                        <label for="campo4_3" class="form-label">Critério:</label>
                        <select class="form-control" id="campo4_3"></select>
                    </div>

                    <div class="col-md-6">
                        <label for="campo4_4" class="form-label">Pontuação:</label>
                        <input type="number" class="form-control" id="campo4_4">
                    </div>

                    <div class="col-12">
                        <button type="button" class="btn btn-primary" onclick="registaCampo4()">Atribuir pontuação</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container mt-5">
    <div class="card">
        <h5 class="card-header">Clasificação Por prova</h5>
        <div class="card-body">
            <h5 class="card-title">Listagem</h5>

            <div class="mb-3">
                <label for="campo4_2_1" class="form-label">Filtro Prova:</label>
                <select class="form-select" id="campo4_2_1" onchange="filtrarTabela(this.value)">
                </select>
            </div>

            <table class="table table-striped" id="tblClassificacao">
                <thead>
                    <tr>
                        <th scope="col">Avaliação Final</th>
                        <th scope="col">INFO</th>
                    </tr>
                </thead>
                <tbody id="listagemCampo4_1"></tbody>
            </table>
        </div>
    </div>
</div>

    <div class="modal fade" id="campo4_1Modal" tabindex="-1" aria-labelledby="campo4_1ModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="campo4_1ModalLabel">Info</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="campo4_1Form">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Critérios</th>
                                <th scope="col">Pontuação</th>
                                <th scope="col">Prova</th>
                                <th scope="col">Concorrente</th>
                            </tr>
                        </thead>
                        <tbody id="listagemCampo4_2"></tbody>
                    </table>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</body>

</html>

<?php
?>