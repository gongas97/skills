<header>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link btn btn-info text-white" href="index.html">Logout</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-success text-white" href="main.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-success text-white" href="campos1.php">Concorrente</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-success text-white" href="campos2.php">Prova</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-success text-white" href="campos3.php">Critérios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-success text-white" href="campos4.php">Pontuação</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>