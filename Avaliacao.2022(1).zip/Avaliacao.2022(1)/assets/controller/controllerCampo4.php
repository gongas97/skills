<?php declare(strict_types=1); 

require_once '../model/modelCampo4.php';

$c4 = new Campo4();

if($_POST['op'] == 1){
    $resp = $c4 -> registarCampo4(
        $_POST['concorrente'],
        $_POST['criterio'],
        $_POST['pontuacao']
    );
    echo ($resp);

}else if($_POST['op'] == 6){
    $resp = $c4 -> getsCampo4();
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $c4 -> filtro($_POST['prova']);
    echo($resp);

}else if($_POST['op'] == 8){
    $resp = $c4 -> getsCampo4_1();
    echo($resp);

}else if($_POST['op'] == 2){
    $resp = $c4 -> getsCampo4_2();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $c4 -> infoProva($_POST['inscricao']);
    echo($resp);

}





?>