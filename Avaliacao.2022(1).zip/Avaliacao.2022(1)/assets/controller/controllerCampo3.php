<?php declare(strict_types=1); 

require_once '../model/modelCampo3.php';

$c3 = new Campo3();

if($_POST['op'] == 1){
    $resp = $c3 -> registarCampo3(
        $_POST['descr'],
        $_POST['pMin'],
        $_POST['pMax'],
        $_POST['prova'],

    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $c3 -> getListagemCampo3();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $c3 -> removerCampo3($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $c3 -> editarCampo3($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $c3 -> guardarEditCampo3(
        $_POST['descr'],
        $_POST['pMin'],
        $_POST['pMax'],
        $_POST['prova'],
        $_POST['idOld']
    );
    echo ($resp);

}else if($_POST['op'] == 6){
    $resp = $c3 -> getsCampo3();
    echo($resp);

}





?>