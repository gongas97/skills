<?php declare(strict_types=1); 

require_once '../model/modelCampo1.php';

$c1 = new Campo1();

if($_POST['op'] == 1){
    $resp = $c1 -> registarCampo1(
        $_POST['nome'],
        $_POST['cc'],
        $_POST['nif'],
        $_POST['email'],
        $_POST['tamanho'],
        $_POST['idade'],
        $_POST['regiao'],
        $_FILES
    );
    echo ($resp);

}else if($_POST['op'] == 6){
    $resp = $c1 -> getsCampo1();
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $c1 -> getsCampo1_1();
    echo($resp);

}else if($_POST['op'] == 8){
    $resp = $c1 -> getsCampo3();
    echo($resp);

}else if($_POST['op'] == 9){
    $resp = $c1 -> getsCampo1_2();
    echo($resp);

}else if($_POST['op'] == 10){
    $resp = $c1 -> registarCampo1_1(
        $_POST['concorrente'],
        $_POST['prova'],
        $_POST['dth']
    );
    echo ($resp);

}else if($_POST['op'] == 11){
    $resp = $c1 -> registarCampo1_2();
    echo($resp);

}





?>