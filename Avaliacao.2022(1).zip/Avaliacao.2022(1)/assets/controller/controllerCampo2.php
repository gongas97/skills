<?php declare(strict_types=1); 

require_once '../model/modelCampo2.php';

$c2 = new Campo2();

if($_POST['op'] == 1){
    $resp = $c2 -> registarCampo2(
        $_POST['descricao'],
        $_POST['cluster'],
        $_POST['idadeMax']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $c2 -> getListagemCampo2();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $c2 -> removerCampo2($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $c2 -> editarCampo2($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $c2 -> guardarEditCampo2(
        $_POST['descricao'],
        $_POST['cluster'],
        $_POST['idadeMax'],
        $_POST['idOld']
    );
    echo ($resp);

}else if($_POST['op'] == 6){
    $resp = $c2 -> getsCampo2();
    echo($resp);

}





?>