<?php

require_once 'connection.php';

class Campo3
{

    // ################################ REGISTO ################################ //

    function registarCampo3($descr, $pMin, $pMax, $prova)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $sql_check = "SELECT * FROM prova WHERE id = ?";
        if ($stmt_check = $conn->prepare($sql_check)) {
            $stmt_check->bind_param("i", $prova);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();
    
            if ($result_check->num_rows == 0) {
                $flag = false;
                $msg = "Erro: Precisa registar primeiro uma Prova.";
            } else {
                // Registra o novo cliente
                $sql_insert = "INSERT INTO criterios (descricao, pontuacao_minima, pontuacao_maxima, id_prova) VALUES (?, ?, ?, ?)";
                if ($stmt_insert = $conn->prepare($sql_insert)) {
                    $stmt_insert->bind_param("siii", $descr, $pMin, $pMax, $prova);
                    if ($stmt_insert->execute()) {
                        $msg = "Registrado com sucesso!";
                    } else {
                        $flag = false;
                        $msg = "Erro: " . $stmt_insert->error;
                    }
                    $stmt_insert->close();
                } else {
                    $flag = false;
                    $msg = "Erro: " . $conn->error;
                }
            }
            $stmt_check->close();
        } else {
            $flag = false;
            $msg = "Erro: " . $conn->error;
        }
    
        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
    
        $conn->close();
    
        return $resp;
    }

    // ################################ LISTAGEM ################################ //
    function getListagemCampo3()
    {
        global $conn;
        $msg = "";

        $sql = "SELECT criterios.*, prova.descricao AS nomeProva FROM criterios, prova WHERE criterios.id_prova = prova.id";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['descricao'] . "</th>";
                $msg .= "<td>" . $row['pontuacao_minima'] . "</td>";
                $msg .= "<td>" . $row['pontuacao_maxima'] . "</td>";
                $msg .= "<td>" . $row['nomeProva'] . "</td>";
                $msg .= "<td><button class='btn btn-warning' onclick='editarCampo3(" . $row['id'] . ")'><i class='fas fa-pencil-alt'></i></button></td>";
                $msg .= "<td><button class='btn btn-danger' onclick='removerCampo3(" . $row['id'] . ")'><i class='fas fa-trash'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    // ################################ REMOVER ################################ //
    function removerCampo3($id)
    {

        global $conn;
        $flag = false;
        $msg = "";

        $sql = "DELETE FROM criterios WHERE id = '" . $id . "';";

        if ($conn->query($sql) === TRUE) {
            $msg = "Removido com sucesso!";
            $flag = true;
        } else {
            $msg = "Error deleting record: " . $conn->error;
        }

        $conn->close();

        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    // ################################ EDITAR ################################ //
    function editarCampo3($id)
    {
       global $conn;
        $row = "";

        $sql = "SELECT * FROM criterios WHERE id =".$id;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function guardarEditCampo3($descr, $pMin, $pMax, $prova, $idOld)
    {
         global $conn;
        $msg = "";
        $flag = true;
        $sql = "";

        $sql = "UPDATE criterios SET descricao = '".$descr."', pontuacao_minima = '".$pMin."', pontuacao_maxima = '".$pMax."', id_prova = '".$prova."' WHERE id = ".$idOld;


        if ($conn->query($sql) === TRUE) {
            $msg = "Editada com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);
    }

    // ################################ GETS ################################ //

    function getsCampo3()
    {
        global $conn;
        $msg = "<option selected>Escolha uma Prova</option>";

        $sql = "SELECT * FROM prova";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Provas registadas</option>";

        }
        $conn->close();

        return ($msg);
    }


}
?>