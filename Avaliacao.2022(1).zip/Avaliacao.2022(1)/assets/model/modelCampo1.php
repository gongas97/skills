<?php

require_once 'connection.php';

class Campo1
{

    // ################################ REGISTO ################################ //

    function registarCampo1($nome, $cc, $nif, $email, $tamanho, $idade, $regiao, $foto)
    {
        global $conn;
        $msg = "";
        $flag = true;

        if ($idade > 25) {
            $flag = false;
            $msg = "Erro: Só podem ser registados concorrentes com idade inferior ou igual a 25 anos.";
        } else {
            $resp = $this->uploads($foto, $nome);
            $resp = json_decode($resp, TRUE);

            if ($resp['flag']) {
                $sql = "INSERT INTO concorrente (nome, cartao_cidadao, nif, email, id_tamanho, idade, id_regiao, foto) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssiiis", $nome, $cc, $nif, $email, $tamanho, $idade, $regiao, $resp['target']);
            } else {
                $sql = "INSERT INTO concorrente (nome, cartao_cidadao, nif, email, id_tamanho, idade, id_regiao) 
                        VALUES (?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("siisiii", $nome, $cc, $nif, $email, $tamanho, $idade, $regiao);
            }

            if ($stmt->execute()) {
                $msg = "Registado com sucesso!";
            } else {
                $flag = false;
                $msg = "Erro: " . $stmt->error;
                if ($resp['flag']) {
                    $resUpdate = $this->updateFoto($resp['target'], $nome);
                    $resUpdate = json_decode($resUpdate, TRUE);
                }
            }
            $stmt->close();
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return $resp;
    }

    function registarCampo1_1($concorrente, $prova, $dth)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $concorrente_sql = "SELECT concorrente.idade FROM concorrente WHERE id = " . $concorrente;
        $idade_result = $conn->query($concorrente_sql);

        if ($idade_result->num_rows > 0) {
            $row_idade = $idade_result->fetch_assoc();
            $idade_concorrente = $row_idade['idade'];

            $check_sql = "SELECT prova.idade_limite FROM prova WHERE id = " . $prova;
            $check_result = $conn->query($check_sql);

            if ($check_result->num_rows > 0) {
                $row = $check_result->fetch_assoc();
                $idade_limite_prova = $row['idade_limite'];


                if ($idade_concorrente <= $idade_limite_prova) {
                    $sql = $conn->prepare("INSERT INTO inscricao (id_concorrente, id_prova, dth) VALUES (?, ?, ?)");
                    $sql->bind_param("iis", $concorrente, $prova, $dth);

                    if ($sql->execute()) {
                        $msg = "Registado com sucesso!";
                    } else {
                        $flag = false;
                        $msg = "Erro: " . $conn->error;
                    }
                } else {
                    $flag = false;
                    $msg = "Não pode registrar o Concorrente na prova, porque a idade do Concorrente é superior á idade Limite da prova.";
                }
            } else {
                $flag = false;
                $msg = "Erro ao verificar o Ano do concorrente.";
            }
        } else {
            $flag = false;
            $msg = "Erro ao verificar o Limite de idades da Prova.";
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return ($resp);
    }

    function registarCampo1_2()
{
    global $conn;
    $msg = "";
    $flag = true;

    $criterios_sql = "SELECT id, id_prova FROM criterios";
    $criterios_result = $conn->query($criterios_sql);

    if ($criterios_result->num_rows > 0) {
        $inscricao_sql = "SELECT id, id_concorrente, id_prova, dth FROM inscricao";
        $inscricao_result = $conn->query($inscricao_sql);

        if ($inscricao_result->num_rows > 0) {
            $sql_insert = "INSERT INTO resultados (id_criterio, id_inscricao, avaliacao, dth) VALUES (?, ?, ?, ?)";
            if ($stmt_insert = $conn->prepare($sql_insert)) {
                while ($criterio = $criterios_result->fetch_assoc()) {
                    while ($inscricao = $inscricao_result->fetch_assoc()) {
                        if ($criterio['id_prova'] == $inscricao['id_prova']) {
                            // Verificar se já existe um registro para esta combinação de id_criterio e id_inscricao
                            $check_sql = "SELECT id FROM resultados WHERE id_criterio = ? AND id_inscricao = ?";
                            if ($stmt_check = $conn->prepare($check_sql)) {
                                $stmt_check->bind_param("ii", $criterio['id'], $inscricao['id']);
                                $stmt_check->execute();
                                $check_result = $stmt_check->get_result();

                                if ($check_result->num_rows == 0) {
                                    // Obter a idade do concorrente
                                    $concorrente_sql = "SELECT idade FROM concorrente WHERE id = ?";
                                    if ($stmt_concorrente = $conn->prepare($concorrente_sql)) {
                                        $stmt_concorrente->bind_param("i", $inscricao['id_concorrente']);
                                        $stmt_concorrente->execute();
                                        $idade_result = $stmt_concorrente->get_result();

                                        if ($idade_result->num_rows > 0) {
                                            $row_idade = $idade_result->fetch_assoc();
                                            $idade_concorrente = $row_idade['idade'];

                                            // Obter a idade limite da prova
                                            $prova_sql = "SELECT idade_limite FROM prova WHERE id = ?";
                                            if ($stmt_prova = $conn->prepare($prova_sql)) {
                                                $stmt_prova->bind_param("i", $inscricao['id_prova']);
                                                $stmt_prova->execute();
                                                $idade_limite_result = $stmt_prova->get_result();

                                                if ($idade_limite_result->num_rows > 0) {
                                                    $row_limite = $idade_limite_result->fetch_assoc();
                                                    $idade_limite_prova = $row_limite['idade_limite'];

                                                    if ($idade_concorrente <= $idade_limite_prova) {
                                                        $avaliacao = 0;
                                                        $dth_inscricao = $inscricao['dth'];
                                                        $stmt_insert->bind_param("iiis", $criterio['id'], $inscricao['id'], $avaliacao, $dth_inscricao);
                                                        if (!$stmt_insert->execute()) {
                                                            $flag = false;
                                                            $msg = "Erro ao registrar resultado: " . $stmt_insert->error;
                                                        }
                                                    } else {
                                                        $flag = false;
                                                        $msg = "Erro: Concorrente com idade superior ao limite permitido para a prova.";
                                                    }
                                                } else {
                                                    $flag = false;
                                                    $msg = "Erro ao obter idade limite da prova.";
                                                }
                                            }
                                        } else {
                                            $flag = false;
                                            $msg = "Erro ao obter idade do concorrente.";
                                        }
                                    }
                                }
                                $stmt_check->close();
                            } else {
                                $flag = false;
                                $msg = "Erro ao preparar query de verificação: " . $conn->error;
                            }
                        }
                    }
                    // Resetar o ponteiro dos resultados de inscrição para inserir para cada critério
                    $inscricao_result->data_seek(0);
                }
                $msg = "Registros inseridos com sucesso!";
            } else {
                $flag = false;
                $msg = "Erro ao preparar query de inserção: " . $conn->error;
            }
        } else {
            $flag = false;
            $msg = "Nenhuma inscrição encontrada.";
        }
    } else {
        $flag = false;
        $msg = "Nenhum critério encontrado.";
    }

    $resp = json_encode(
        array(
            "flag" => $flag,
            "msg" => $msg
        )
    );

    $conn->close();

    return $resp;
}

    // ################################ GETS ################################ //

    function getsCampo1()
    {
        global $conn;
        $msg = "<option selected>Escolha um Tamanho</option>";

        $sql = "SELECT * FROM tamanhos";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem tamanhos registados</option>";

        }
        $conn->close();

        return ($msg);
    }

    function getsCampo1_1()
    {
        global $conn;
        $msg = "<option selected>Escolha uma Região</option>";

        $sql = "SELECT * FROM regiao";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Regiões registadas</option>";

        }
        $conn->close();

        return ($msg);
    }

    function getsCampo3()
    {
        global $conn;
        $msg = "<option selected>Escolha uma Prova</option>";

        $sql = "SELECT * FROM prova";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Provas registadas</option>";

        }
        $conn->close();

        return ($msg);
    }

    function getsCampo1_2()
    {
        global $conn;
        $msg = "<option selected>Escolha um Concorrente</option>";

        $sql = "SELECT * FROM concorrente";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['nome'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Concorrentes registadas</option>";

        }
        $conn->close();

        return ($msg);
    }

    // ################################ DIRETORIO FOTO ################################ //
    function updateFoto($diretorio, $id)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "UPDATE campo3 SET foto = '" . $diretorio . "' WHERE id = " . $id;

        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        return ($resp);
    }
    function uploads($img, $id)
    {

        $dir = "../imagens/Campo3" . $id . "/";
        $dir1 = "assets/imagens/Campo3" . $id . "/";
        $flag = false;
        $targetBD = "";

        if (!is_dir($dir)) {
            if (!mkdir($dir, 0777, TRUE)) {
                die("Erro não é possivel criar o diretório");
            }
        }
        if (array_key_exists('foto', $img)) {
            if (is_array($img)) {
                if (is_uploaded_file($img['foto']['tmp_name'])) {
                    $fonte = $img['foto']['tmp_name'];
                    $ficheiro = $img['foto']['name'];
                    $end = explode(".", $ficheiro);
                    $extensao = end($end);

                    $newName = "Campo3" . date("YmdHis") . "." . $extensao;

                    $target = $dir . $newName;
                    $targetBD = $dir1 . $newName;

                    $flag = move_uploaded_file($fonte, $target);

                }
            }
        }
        return (
            json_encode(
                array(
                    "flag" => $flag,
                    "target" => $targetBD
                )
            )
        );


    }


}
?>