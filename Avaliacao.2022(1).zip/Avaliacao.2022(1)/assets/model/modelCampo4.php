<?php

require_once 'connection.php';

class Campo4
{

    // ################################ REGISTO ################################ //

    function registarCampo4($concorrente_id, $criterio_id, $pontuacao)
    {
        global $conn;
        $msg = "";
        $flag = true;

        // Verificar os limites de pontuação do critério
        $sql_criterio = "SELECT pontuacao_minima, pontuacao_maxima FROM criterios WHERE id = ?";
        if ($stmt_criterio = $conn->prepare($sql_criterio)) {
            $stmt_criterio->bind_param("i", $criterio_id);
            $stmt_criterio->execute();
            $result_criterio = $stmt_criterio->get_result();

            if ($result_criterio->num_rows > 0) {
                $criterios = $result_criterio->fetch_assoc();
                $pontuacao_minima = $criterios['pontuacao_minima'];
                $pontuacao_maxima = $criterios['pontuacao_maxima'];

                // Verificar se a pontuação está dentro dos limites
                if ($pontuacao < $pontuacao_minima || $pontuacao > $pontuacao_maxima) {
                    $flag = false;
                    $msg = "A pontuação deve ser de $pontuacao_minima a $pontuacao_maxima.";
                } else {
                    // Atualizar a pontuação e o campo de data e hora
                    $dth = date('Y-m-d H:i:s');
                    $sql_update = "UPDATE resultados SET avaliacao = ?, dth = ? WHERE id_criterio = ? AND id_inscricao = (SELECT id FROM inscricao WHERE id_concorrente = ? AND id_prova = (SELECT id_prova FROM criterios WHERE id = ?))";
                    if ($stmt_update = $conn->prepare($sql_update)) {
                        $stmt_update->bind_param("isiis", $pontuacao, $dth, $criterio_id, $concorrente_id, $criterio_id);
                        if ($stmt_update->execute()) {
                            $msg = "Pontuação atribuída com sucesso!";
                        } else {
                            $flag = false;
                            $msg = "Erro ao atualizar a pontuação: " . $stmt_update->error;
                        }
                    } else {
                        $flag = false;
                        $msg = "Erro ao preparar query de atualização: " . $conn->error;
                    }
                }
            } else {
                $flag = false;
                $msg = "Critério não encontrado.";
            }
            $stmt_criterio->close();
        } else {
            $flag = false;
            $msg = "Erro ao preparar query do critério: " . $conn->error;
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return $resp;
    }

    // ################################ LISTAGEM ################################ //
    function filtro($prova)
    {
        global $conn;
        $msg = "";

        // SQL para buscar a classificação da prova
        $stmt = $conn->prepare("SELECT SUM(resultados.avaliacao) AS total_avaliacao, inscricao.id FROM resultados, inscricao, concorrente, prova 
        WHERE resultados.id_inscricao = inscricao.id AND
        inscricao.id_prova = prova.id AND
        inscricao.id_concorrente = concorrente.id AND
        prova.id = ?
        GROUP BY concorrente.nome
        ORDER BY total_avaliacao DESC");

        $stmt->bind_param("i", $prova);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<td>" . $row['total_avaliacao'] . " Valores</td>";
                $msg .= "<td><button class='btn btn-info' onclick='infoProva(" . $row['id'] . ")'><i class='fas fa-info-circle'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td colspan='4'>Sem Registos</td>";
            $msg .= "</tr>";
        }

        $stmt->close();
        $conn->close();

        return $msg;
    }

    function infoProva($inscricao_id)
    {
        global $conn;
        $msg = "";
        $totalValor = 0;
        $provaDescricao = "";
        $concorrenteNome = "";

        // SQL para buscar os critérios e pontuações do concorrente na prova, baseado na inscrição
        $stmt = $conn->prepare("
        SELECT 
            criterios.descricao AS criterio,
            resultados.avaliacao,
            prova.descricao AS prova,
            concorrente.nome AS concorrente
        FROM 
            resultados
            JOIN inscricao ON resultados.id_inscricao = inscricao.id
            JOIN criterios ON resultados.id_criterio = criterios.id
            JOIN prova ON inscricao.id_prova = prova.id
            JOIN concorrente ON inscricao.id_concorrente = concorrente.id
        WHERE 
            inscricao.id = ?
    ");

        $stmt->bind_param("i", $inscricao_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<td>" . $row['criterio'] . "</td>";
                $msg .= "<td>" . $row['avaliacao'] . "</td>";
                $msg .= "<td></td>";
                $msg .= "<td></td>";
                $msg .= "</tr>";

                $totalValor += $row['avaliacao'];
                $provaDescricao = $row['prova'];
                $concorrenteNome = $row['concorrente'];
            }

            $msg .= "<tr>";
            $msg .= "<td>Nota Final:</td>";
            $msg .= "<td>" . $totalValor . " Valores</td>";
            $msg .= "<td>" . $provaDescricao . "</td>";
            $msg .= "<td>" . $concorrenteNome . "</td>";
            $msg .= "</tr>";
        } else {
            $msg .= "<tr>";
            $msg .= "<td colspan='4'>Sem Registos</td>";
            $msg .= "</tr>";
        }

        $stmt->close();
        $conn->close();

        return $msg;
    }

    // ################################ GETS ################################ //

    function getsCampo4()
    {
        global $conn;
        $msg = "<option selected>Escolha um Concorrente</option>";

        $sql = "SELECT * FROM concorrente";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['nome'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Concorrentes registados</option>";

        }
        $conn->close();

        return ($msg);
    }

    function getsCampo4_1()
    {
        global $conn;
        $msg = "<option selected>Escolha um Critério</option>";

        $sql = "SELECT * FROM criterios";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Critérios registados</option>";

        }
        $conn->close();

        return ($msg);
    }

    function getsCampo4_2()
    {
        global $conn;
        $msg = "<option selected>Escolha uma prova</option>";

        $sql = "SELECT * FROM prova";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Provas registadas</option>";

        }
        $conn->close();

        return ($msg);
    }

}
?>