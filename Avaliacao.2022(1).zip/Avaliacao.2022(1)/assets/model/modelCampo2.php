<?php

require_once 'connection.php';

class Campo2
{

    // ################################ REGISTO ################################ //

    function registarCampo2($descricao, $cluster, $idadeMax)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "INSERT INTO prova (descricao, id_cluster, idade_limite) VALUES ('" . $descricao . "','" . $cluster . "'
        ,'" . $idadeMax . "')";


        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com sucesso!";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }


        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return ($resp);


    }

    // ################################ LISTAGEM ################################ //
    function getListagemCampo2()
    {
        global $conn;
        $msg = "";

        $sql = "SELECT prova.*, cluster.descricao AS nome FROM prova, cluster WHERE prova.id_cluster = cluster.id";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['descricao'] . "</th>";
                $msg .= "<td>" . $row['idade_limite'] . "</td>";
                $msg .= "<td>" . $row['nome'] . "</td>";
                $msg .= "<td><button class='btn btn-warning' onclick='editarCampo2(" . $row['id'] . ")'><i class='fas fa-pencil-alt'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    // ################################ REMOVER ################################ //
    function removerCampo2($id)
    {

        global $conn;
        $flag = false;
        $msg = "";

        $sql = "DELETE FROM campo2 WHERE id = '" . $id . "';";

        if ($conn->query($sql) === TRUE) {
            $msg = "Removido com sucesso!";
            $flag = true;
        } else {
            $msg = "Error deleting record: " . $conn->error;
        }

        $conn->close();

        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    // ################################ EDITAR ################################ //
    function editarcampo2($id)
    {
       global $conn;
        $row = "";

        $sql = "SELECT * FROM prova WHERE id =".$id;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function guardarEditCampo2($descricao, $cluster, $idadeMax, $idOld)
    {
         global $conn;
        $msg = "";
        $flag = true;
        $sql = "";

        $sql = "UPDATE prova SET descricao = '".$descricao."', id_cluster = '".$cluster."', idade_limite = '".$idadeMax."' WHERE id = ".$idOld;
        

        if ($conn->query($sql) === TRUE) {
            $msg = "Editada com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);
    }

    // ################################ GETS ################################ //

    function getsCampo2()
    {
        global $conn;
        $msg = "<option selected>Escolha um Cluster</option>";

        $sql = "SELECT * FROM cluster";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Clusters registados</option>";

        }
        $conn->close();

        return ($msg);
    }


}
?>