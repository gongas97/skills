// ################################ REGISTO ################################ //

function registaCampo4() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("concorrente", $('#campo4_2').val());
    dados.append("criterio", $('#campo4_3').val());
    dados.append("pontuacao", $('#campo4_4').val());

    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Avaliação Enviada", obj.msg, "success");
            } else {
                alerta("Avaliação", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ GET ################################ //

function getCampo4() {
    
    let dados = new FormData();
    dados.append("op", 6);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo4_2').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getCampo4_1() {
    
    let dados = new FormData();
    dados.append("op", 8);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo4_3').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getCampo4_2() {
    
    let dados = new FormData();
    dados.append("op", 2);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo4_2_1').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ FILTRO ################################ //

function filtrarTabela() {

    if ( $.fn.DataTable.isDataTable('#tblClassificacao') ) {
        $('#tblClassificacao').DataTable().destroy();
    }

    let dados = new FormData();
    dados.append('prova', $('#campo4_2_1').val());
    dados.append('op', 7);

    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })
    .done(function(msg) {
        $('#listagemCampo4_1').html(msg);
        $('#tblClassificacao').DataTable( "order" [[1, "desc"]]);

    })
    .fail(function(jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

function infoProva(inscricao) {

    $('#campo4_1Modal').modal('show');
    
    let dados = new FormData();
    dados.append("op", 3);
    dados.append("inscricao", inscricao);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo4.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#listagemCampo4_2').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}


// ################################ ALERTA ################################ //

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getCampo4();
    getCampo4_1();
    getCampo4_2();
    $('#campo4_2_1').change(filtrarTabela);
    $('#tblClassificacao').DataTable();
});