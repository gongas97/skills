

// ################################ REGISTO ################################ //

function registaCampo3() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("descr", $('#campo3_2').val());
    dados.append("pMin", $('#campo3_3').val());
    dados.append("pMax", $('#campo3_4').val());
    dados.append("prova", $('#campo3_5').val());


    $.ajax({
        url: "assets/controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Critério Regisado", obj.msg, "success");
                getListaCampo3();
                getCampo3();
            } else {
                alerta("Critério", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ LISTAGEM ################################ //

function getListaCampo3() {

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemCampo3').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ REMOVER ################################ //

function removerCampo3(id) {

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Critério", obj.msg, "success");
                getListaCampo3();
            } else {
                alerta("Critério", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}


// ################################ EDIÇÃO ################################ //

function editarCampo3(id) {


    let dados = new FormData();
    dados.append("op", 4);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#campo3_2Edit').val(obj.descricao);
            $('#campo3_3Edit').val(obj.pontuacao_minima);
            $('#campo3_4Edit').val(obj.pontuacao_maxima);
            $('#campo3_5Edit').val(obj.id_prova);

            $('#btnGuardar').attr("onclick", "guardaEditCampo3(" + obj.id + ")")

            $('#campo3Modal').modal('show')
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function guardaEditCampo3(idOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("descr", $('#campo3_2Edit').val());
    dados.append("pMin", $('#campo3_3Edit').val());
    dados.append("pMax", $('#campo3_4Edit').val());
    dados.append("prova", $('#campo3_5Edit').val());
    dados.append("idOld", idOld);

    $.ajax({
        url: "assets/controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Editado", obj.msg, "success");
                $('#campo3Modal').modal('hide')
                getListaCampo3();
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}


// ################################ GET ################################ //

function getCampo3() {
    
    let dados = new FormData();
    dados.append("op", 6);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo3.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo3_5').html(msg);
            $('#campo3_5Edit').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}



function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getListaCampo3();
    getCampo3();
});