// ################################ REGISTO ################################ //

function registaCampo2() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("descricao", $('#campo2_2').val());
    dados.append("cluster", $('#campo2_3').val());
    dados.append("idadeMax", $('#campo2_4').val());

    $.ajax({
        url: "assets/controller/controllerCampo2.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Prova", obj.msg, "success");
                getListaCampo2();
            } else {
                alerta("Prova", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ LISTAGEM ################################ //

function getListaCampo2() {

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerCampo2.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemCampo2').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ REMOVER ################################ //

function removerCampo2(id) {

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerCampo2.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Campo 2", obj.msg, "success");
                getListaCampo2();
            } else {
                alerta("Campo 2", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}


// ################################ EDIÇÃO ################################ //

function editarCampo2(id) {


    let dados = new FormData();
    dados.append("op", 4);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerCampo2.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#campo2_2Edit').val(obj.descricao);
            $('#campo2_3Edit').val(obj.id_cluster);
            $('#campo2_4Edit').val(obj.idade_limite);

            $('#btnGuardar').attr("onclick", "guardaEditCampo2(" + obj.id + ")")

            $('#campo2Modal').modal('show')
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function guardaEditCampo2(idOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("descricao", $('#campo2_2Edit').val());
    dados.append("cluster", $('#campo2_3Edit').val());
    dados.append("idadeMax", $('#campo2_4Edit').val());
    dados.append("idOld", idOld);

    $.ajax({
        url: "assets/controller/controllerCampo2.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Prova Editada", obj.msg, "success");
                $('#campo2Modal').modal('hide')
                getListaCampo2();
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}


// ################################ GET ################################ //

function getCampo2() {
    
    let dados = new FormData();
    dados.append("op", 6);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo2.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo2_3').html(msg);
            $('#campo2_3Edit').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}



function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getListaCampo2();
    getCampo2();
});