// ################################ REGISTO ################################ //

function registaCampo1() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("nome", $('#campo1_2').val());
    dados.append("cc", $('#campo1_3').val());
    dados.append("nif", $('#campo1_4').val());
    dados.append("email", $('#campo1_5').val());
    dados.append("tamanho", $('#campo1_6').val());
    dados.append("idade", $('#campo1_7').val());
    dados.append("regiao", $('#campo1_8').val());
    dados.append("foto", $('#campo1_9').prop('files')[0]);
    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Concorrente Registado", obj.msg, "success");
                getCampo1_2();
            } else {
                alerta("Concorrente", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function registaCampo1_1() {

    let dados = new FormData();
    dados.append("op", 10);
    dados.append("concorrente", $('#campo1_1_1').val());
    dados.append("prova", $('#campo1_1_2').val());
    dados.append("dth", $('#campo1_1_3').val());

    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Concorrente Registado em Prova", obj.msg, "success");
            } else {
                alerta("ERRO", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function registaCampo1_2() {

    let dados = new FormData();
    dados.append("op", 11);

    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Resultados Registados", obj.msg, "success");
            } else {
                alerta("ERRO", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

// ################################ GET ################################ //

function getCampo1() {
    
    let dados = new FormData();
    dados.append("op", 6);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo1_6').html(msg);
            $('#campo1_6Edit').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getCampo1_1() {
    
    let dados = new FormData();
    dados.append("op", 7);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo1_8').html(msg);
            $('#campo1_8Edit').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getCampo3() {
    
    let dados = new FormData();
    dados.append("op", 8);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo1_1_2').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getCampo1_2() {
    
    let dados = new FormData();
    dados.append("op", 9);
    
    
    $.ajax({
        url: "assets/controller/controllerCampo1.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#campo1_1_1').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getCampo1();
    getCampo1_1();
    getCampo3();
    getCampo1_2();
});