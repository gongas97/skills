<?php
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Concorrente</title>
    <link rel="stylesheet" href="assets/css/datatables.css">
    <link rel="stylesheet" href="assets/css/select2.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">

    <script src="assets/js/lib/jquery.js"></script>
    <script src="assets/js/lib/datatables.js"></script>
    <script src="assets/js/lib/select2.js"></script>
    <script src="assets/js/lib/sweatalert.js"></script>
    <script src="assets/js/lib/bootstrap.js"></script>
    <script src="assets/js/campo1.js"></script>
</head>

<body>

    <?php include_once 'menu.php' ?>

    <div class="container mt-5">
        <div class="card">
            <h5 class="card-header">Concorrentes</h5>
            <div class="card-body">
                <h5 class="card-title">REGISTO CONCORRENTE</h5>
                <form class="row g-3">
                    <div class="col-md-3">
                        <label for="campo1_2" class="form-label">Nome:</label>
                        <input type="text" class="form-control" id="campo1_2">
                    </div>

                    <div class="col-md-3">
                        <label for="campo1_3" class="form-label">CC:</label>
                        <input type="number" class="form-control" id="campo1_3">
                    </div>

                    <div class="col-md-6">
                        <label for="campo1_4" class="form-label">Nif:</label>
                        <input type="number" class="form-control" id="campo1_4">
                    </div>

                    <div class="col-md-6">
                        <label for="campo1_5" class="form-label">Email:</label>
                        <input type="email" class="form-control" id="campo1_5">
                    </div>

                    <div class="col-md-6">
                        <label for="campo1_6" class="form-label">Tamanho:</label>
                        <select class="form-control" id="campo1_6"></select>
                    </div>

                    <div class="col-md-6">
                        <label for="campo1_7" class="form-label">Idade:</label>
                        <input type="number" class="form-control" id="campo1_7">
                    </div>

                    <div class="col-md-6">
                        <label for="campo1_8" class="form-label">Região:</label>
                        <select class="form-control" id="campo1_8"></select>
                    </div>

                    <div class="col-md-6">
                        <label for="campo1_9" class="form-label">Foto:</label>
                        <input type="file" class="form-control" id="campo1_9">
                    </div>

                    <div class="col-12">
                        <button type="button" class="btn btn-primary" onclick="registaCampo1()">Registar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container mt-5">
        <div class="card">
            <h5 class="card-header">INSCRIÇÕES</h5>
            <div class="card-body">
                <h5 class="card-title">INCRIÇÃO DE CONCORRENTE EM PROVA</h5>
                <form class="row g-3">

                    <div class="col-md-6">
                        <label for="campo1_1_1" class="form-label">Concorrente:</label>
                        <select class="form-control" id="campo1_1_1"></select>
                    </div>

                    <div class="col-md-6">
                        <label for="campo1_1_2" class="form-label">Prova:</label>
                        <select class="form-control" id="campo1_1_2"></select>
                    </div>

                    <div class="col-md-6">
                        <label for="campo1_1_3" class="form-label">Data/hora:</label>
                        <input type="datetime-local" class="form-control" id="campo1_1_3">
                    </div>

                    <div class="col-12">
                        <button type="button" class="btn btn-primary" onclick="registaCampo1_1()">Registar Inscrição</button>
                        <button type="button" class="btn btn-success" onclick="registaCampo1_2()">Registar Resultados</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>

<?php
?>