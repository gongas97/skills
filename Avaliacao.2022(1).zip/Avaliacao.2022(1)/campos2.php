<?php
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prova</title>
    <link rel="stylesheet" href="assets/css/datatables.css">
    <link rel="stylesheet" href="assets/css/select2.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">

    <script src="assets/js/lib/jquery.js"></script>
    <script src="assets/js/lib/datatables.js"></script>
    <script src="assets/js/lib/select2.js"></script>
    <script src="assets/js/lib/sweatalert.js"></script>
    <script src="assets/js/lib/bootstrap.js"></script>
    <script src="assets/js/campo2.js"></script>
</head>

<body>

    <?php include_once 'menu.php' ?>

    <div class="container mt-5">
        <div class="card">
            <h5 class="card-header">Provas</h5>
            <div class="card-body">
                <h5 class="card-title">REGISTO DE PROVA</h5>
                <form class="row g-3">
                    <div class="col-md-3">
                        <label for="campo2_2" class="form-label">Descrição:</label>
                        <input type="text" class="form-control" id="campo2_2">
                    </div>

                    <div class="col-md-3">
                        <label for="campo2_3" class="form-label">Cluster:</label>
                        <select class="form-control" id="campo2_3"></select>
                    </div>

                    <div class="col-md-6">
                        <label for="campo2_4" class="form-label">Idade Limite:</label>
                        <input type="number" class="form-control" id="campo2_4">
                    </div>

                    <div class="col-12">
                        <button type="button" class="btn btn-primary" onclick="registaCampo2()">Registar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="container mt-5">
        <div class="card">
            <h5 class="card-header">Listagem</h5>
            <div class="card-body">
                <h5 class="card-title">Listagem</h5>

                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Descrição</th>
                            <th scope="col">Idade Limite</th>
                            <th scope="col">Nome Cluster</th>
                            <th scope="col">Editar</th>
                        </tr>
                    </thead>

                    <tbody id="listagemCampo2"></tbody>
                </table>
            </div>
        </div>
    </div>


    <div class="modal fade" id="campo2Modal" tabindex="-1" aria-labelledby="campo2ModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="campo2ModalLabel">Editar</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="campo2_1Form">

                        <div class="mb-3">
                            <label for="campo2_2Edit" class="form-label">Campo2</label>
                            <input type="number" class="form-control" id="campo2_2Edit">
                        </div>

                        <div class="mb-3">
                            <label for="campo2_3Edit" class="form-label">Campo3</label>
                            <select class="form-control" id="campo2_3Edit">
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="campo2_4Edit" class="form-label">Campo4</label>
                            <input type="number" class="form-control" id="campo2_4Edit">
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="btnGuardar">Guardar</button>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

<?php
?>