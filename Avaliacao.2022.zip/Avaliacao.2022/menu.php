<header>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <?php echo ($_SESSION['utilizador']); ?>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link btn btn-info text-white" href="#" onclick="logout()">Logout</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-success text-white" href="main.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-success text-white" href="vinhas.php">Vinhas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-success text-white" href="funcionarios.php">Funcionários</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-success text-white" href="vindimas.php">Vindimas</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>