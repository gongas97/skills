<?php declare(strict_types=1); 
session_start(); // Inicie a sessão

require_once('tcpdf/tcpdf.php'); // Certifique-se de que o caminho está correto

// Configurar cabeçalhos para download do PDF
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="compra_vinho.pdf"');

// Cria um novo objeto TCPDF
$pdf = new TCPDF();

// Define informações do documento
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Seu Nome');
$pdf->SetTitle('Fatura de Compra de Vinho');
$pdf->SetSubject('Fatura');

// Adiciona uma página
$pdf->AddPage();

// Define fonte para o cabeçalho
$pdf->SetFont('helvetica', 'B', 12);

// Informações da empresa
$empresa = "Venda de Vinhos Unipessoal, Lda\nContribuinte: 515432136\nMorada: Rua da Praça do Giraldo\nCódigo Postal: 7005-000 Évora";
$pdf->MultiCell(100, 10, $empresa, 0, 'L', 0, 1, '', '', true);

// Nome do cliente no canto superior direito
$usuario = $_SESSION['utilizador'] ?? 'N/A';
$pdf->SetXY(150, 10);
$pdf->MultiCell(50, 10, 'Nome do Cliente: ' . htmlspecialchars($usuario), 0, 'R', 0, 1, '', '', true);

$pdf->Ln(20); // Adiciona um espaço

// Linha horizontal
$pdf->Line(10, 40, 200, 40);

// Define fonte para os detalhes
$pdf->SetFont('helvetica', '', 12);

// Cabeçalho da tabela
$pdf->Ln(10);
$pdf->SetFont('helvetica', 'B', 12);
$pdf->Cell(140, 10, 'Artigo', 1);
$pdf->Cell(50, 10, 'Quantidade', 1);
$pdf->Ln(10);

// Obtém os dados do formulário
$nome = $_POST['nome'] ?? 'N/A';
$quantidade = $_POST['quantidade'] ?? '0';

// Adiciona os detalhes ao PDF
$pdf->SetFont('helvetica', '', 12);
$pdf->Cell(140, 10, htmlspecialchars($nome), 1);
$pdf->Cell(50, 10, htmlspecialchars($quantidade), 1);
$pdf->Ln(10);

$pdf->Ln(10); // Adiciona um espaço

// Preço total dentro de um quadrado, calculado como quantidade * 6 euros
$preco_total = (float)$quantidade * 6;
$pdf->SetFont('helvetica', 'B', 12);
$pdf->Cell(0, 10, 'Preço Total: ' . number_format($preco_total, 2) . ' €', 1, 1, 'C');

// Fecha e envia o PDF para o navegador
$pdf->Output('compra_vinho.pdf', 'D');
exit;
?>