function registaUser() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("username", $('#username').val());
    dados.append("password", $('#password').val());
    dados.append("tpUser", $('#tpUser').val());

    $.ajax({
        url: "assets/controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Utilizador", obj.msg, "success");
            } else {
                alerta("Utilizador", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function login() {

    let dados = new FormData();
    dados.append("op", 2);
    dados.append("username", $('#usernameLogin').val());
    dados.append("password", $('#passwordLogin').val());

    $.ajax({
        url: "assets/controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Utilizador", obj.msg, "success");

                setTimeout(function () {
                    window.location.href = "main.php";
                }, 2000);

            } else {
                alerta("Utilizador", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function logout() {
    let dados = new FormData();
    dados.append("op", 3);

    $.ajax({
        url: "assets/controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {


            alerta("Utilizador", msg, "success");

            setTimeout(function () {
                window.location.href = "index.html";
            }, 2000);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function getTipos() {
    let dados = new FormData();
    dados.append('op', 4);


    $.ajax({
        url: "assets/controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })

        .done(function (msg) {

            $('#tpUser').html(msg)
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function mostraVinho() {
    let dados = new FormData();
    dados.append('op', 5);

    $.ajax({
        url: "assets/controller/controllerLogin.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })
        .done(function (msg) {
            $('#wineCardsContainer').html(msg);
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function openCompraVinhoModal(id) {
    $('#compraVinhoId1').val(id);
    $('#compraVinhoModal').modal('show');
}

function compraVinho() {
    let id_vinho = $('#compraVinhoId1').val();
    let quantidade = $('#quantidade1').val();

    let dados = new FormData();
    dados.append("op", 6);
    dados.append("id_vinho", id_vinho);
    dados.append("quantidade", quantidade);

    $.ajax({
        url: "assets/controller/controllerLogin.php",
        method: "POST",
        data: dados,
        processData: false,
        contentType: false
    })
    .done(function (msg) {
        let obj = JSON.parse(msg);
        if (obj.flag) {
            alerta("Compra de Vinho", obj.msg, "success");
            $('#compraVinhoModal').modal('hide');
            mostraVinho();

            // Gerar PDF
            let pdfDados = new FormData();
            pdfDados.append("nome", obj.nome);
            pdfDados.append("quantidade", quantidade);
            pdfDados.append("total", obj.total);

            $.ajax({
                url: "generate_pdf.php",
                method: "POST",
                data: pdfDados,
                processData: false,
                contentType: false,
                xhrFields: {
                    responseType: 'blob' // Receber o PDF como blob
                }
            })
            .done(function (pdfBlob) {
                // Criar um URL para o blob e abrir em nova aba
                let pdfUrl = URL.createObjectURL(pdfBlob);
                window.open(pdfUrl);
            })
            .fail(function (jqXHR, textStatus) {
                alert("Falha ao gerar PDF: " + textStatus);
            });

        } else {
            alerta("Compra de Vinho", obj.msg, "error");
        }
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}


function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}

$(document).ready(function () {
    getTipos();
    mostraVinho();
});