function registaVinha() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("desc", $('#descricaoVinha').val());
    dados.append("ha", $('#haVinha').val());
    dados.append("dataP", $('#dataPlantacaoVinha').val());
    dados.append("anoC", $('#anoColheitaVinha').val());
    dados.append("foto", $('#fotoVinha').prop('files')[0]);

    $.ajax({
        url: "assets/controller/controllerVinha.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Vinha Registada", obj.msg, "success");
                getListaVinha();
                getTipoVinha();
            } else {
                alerta("Vinha", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function registaCastaVinha() {

    let dados = new FormData();
    dados.append("op", 8);
    dados.append("vinha", $('#listaVinhas').val());
    dados.append("casta", $('#listaCastas').val());

    $.ajax({
        url: "assets/controller/controllerVinha.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Casta/Vinha Registada", obj.msg, "success");
                getListaVinha();
            } else {
                alerta("Casta/Vinha", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getListaVinha() {

    if ($.fn.DataTable.isDataTable('#tblVinhas')) {
        $('#tblVinhas').DataTable().destroy();
    }

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerVinha.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemVinhas').html(msg);
            $('#tblVinhas').DataTable();

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function removerVinha(id) {

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerVinha.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Vinha Removida", obj.msg, "success");
                getListaVinha();
            } else {
                alerta("Vinha", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function getDadosVinha(id) {


    let dados = new FormData();
    dados.append("op", 4);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerVinha.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#descricaoVinhaEdit').val(obj.descricao);
            $('#haVinhaEdit').val(obj.ha);
            $('#dataPlantacaoEdit').val(obj.data_plantacao);
            $('#anoColheitaEdit').val(obj.ano_p_colheita);
            $('#fotoEdit').attr('src', obj.foto);

            $('#btnGuardar').attr("onclick", "guardaEditVinha(" + obj.id + ")")

            $('#formEditVinha').modal('show')
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function guardaEditVinha(idOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("desc", $('#descricaoVinhaEdit').val());
    dados.append("ha", $('#haVinhaEdit').val());
    dados.append("dataP", $('#dataPlantacaoEdit').val());
    dados.append("anoC", $('#anoColheitaEdit').val());
    dados.append("foto", $('#fotoEdit').prop('files')[0]);
    dados.append("idOld", idOld);

    $.ajax({
        url: "assets/controller/controllerVinha.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Vinha Editada", obj.msg, "success");
                getListaVinha();
                $('#formEditVinha').modal('hide')
            } else {
                alerta("Vinha", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function getTipoVinha(){

    let dados = new FormData();
    dados.append("op", 6);


    $.ajax({
        url: "assets/controller/controllerVinha.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {
        $('#listaVinhas').html(msg);
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function getTipoCasta(){

    let dados = new FormData();
    dados.append("op", 7);


    $.ajax({
        url: "assets/controller/controllerVinha.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) { 
        $('#listaCastas').html(msg);  
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}


function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}

function erroPermissao(){
    Swal.fire({
        position: 'center',
        icon: 'error',
        title: "Sem permissão!",
        text: "Não pode aceder a este conteudo",
        showConfirmButton: true,

      })
}


$(function () {
    getListaVinha();
    getTipoVinha();
    getTipoCasta();
});

