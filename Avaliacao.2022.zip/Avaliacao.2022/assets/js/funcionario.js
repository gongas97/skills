function registaFuncionario() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("bi", $('#biFuncionario').val());
    dados.append("nome", $('#nomeFuncionario').val());
    dados.append("morada", $('#moradaFuncionario').val());
    dados.append("tel", $('#telFuncionario').val());
    dados.append("email", $('#emailFuncionario').val());
    dados.append("salario", $('#salarioFuncionario').val());
    dados.append("estado", $('#estadoFuncionario').val());

    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Funcionário/a", obj.msg, "success");
                getListaFuncionario();
            } else {
                alerta("Funcionário/a", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getListaFuncionario(){

    if ( $.fn.DataTable.isDataTable('#tblFuncionario') ) {
        $('#tblFuncionario').DataTable().destroy();
    }

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {

        $('#listagemFuncionarios').html(msg);
        $('#tblFuncionario').DataTable();
        
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function getEstadoFuncionario(){

    let dados = new FormData();
    dados.append("op", 3);


    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {
        $('#estadoFuncionario').html(msg); 
        $('#estadoFuncionarioEdit').html(msg); 
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function getDadosFuncionario(bi) {


    let dados = new FormData();
    dados.append("op", 4);
    dados.append("bi", bi);

    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#biFuncionarioEdit').val(obj.bi);
            $('#estadoFuncionarioEdit').val(obj.id_estado);

            $('#btnGuardar').attr("onclick", "guardaEditFuncionario(" + obj.bi + ")")

            $('#formEditFuncionario').modal('show')
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function guardaEditFuncionario(biOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("bi", $('#biFuncionarioEdit').val());
    dados.append("estado", $('#estadoFuncionarioEdit').val());
    dados.append("biOld", biOld);

    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Estado Alterado", obj.msg, "success");
                getListaFuncionario();
                $('#formEditFuncionario').modal('hide')
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function erroPermissao(){
    Swal.fire({
        position: 'center',
        icon: 'error',
        title: "Sem permissão!",
        text: "Não pode aceder a este conteudo",
        showConfirmButton: true,

      })
}

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getEstadoFuncionario();
    getListaFuncionario();
});