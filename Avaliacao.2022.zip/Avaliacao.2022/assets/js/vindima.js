function registaVindima() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("vinha", $('#listaVinhas1').val());
    dados.append("funcionario", $('#listaFuncionarios1').val());
    dados.append("kg", $('#kgVindima').val());
    dados.append("dth", $('#dthVindima').val());
    dados.append("ano", $('#listaAnoVindima').val());

    $.ajax({
        url: "assets/controller/controllerVindima.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Vindima Registada", obj.msg, "success");
                getListaVindima();
            } else {
                alerta("Vindima", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getListaVindima() {

    if ($.fn.DataTable.isDataTable('#tblVindimas')) {
        $('#tblVindimas').DataTable().destroy();
    }

    let dados = new FormData();
    dados.append("op", 3);


    $.ajax({
        url: "assets/controller/controllerVindima.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemVindimas').html(msg);
            $('#tblVindimas').DataTable();

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getFuncionario(){

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerVindima.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) { 
        $('#listaFuncionarios1').html(msg);  
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function getListaVinhos() {

    if ($.fn.DataTable.isDataTable('#tblVinhos')) {
        $('#tblVinhos').DataTable().destroy();
    }

    let dados = new FormData();
    dados.append("op", 7);


    $.ajax({
        url: "assets/controller/controllerVindima.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemVinhos').html(msg);
            $('#tblVinhos').DataTable();

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function openVendaVinhoModal(id) {
    $('#vendaVinhoId').val(id);
    $('#vendaVinhoModal').modal('show');
  }

  function vendaVinho() {

    let id_vinho = $('#vendaVinhoId').val();
    let quantidade = $('#quantidade').val();

    let dados = new FormData();
    dados.append("op", 8);
    dados.append("id_vinho", id_vinho);
    dados.append("quantidade", quantidade);

    $.ajax({
      url: "assets/controller/controllerVindima.php",
      method: "POST",
      data: dados,
      dataType: "html",
      cache: false,
      contentType: false,
      processData: false
    })
    .done(function(msg) {
      let obj = JSON.parse(msg);
      if (obj.flag) {
        alerta("Venda de Vinho", obj.msg, "success");
        getListaVinhos();
        mostraVinho();
        $('#vendaVinhoModal').modal('hide');
      } else {
        alerta("Venda de Vinho", obj.msg, "error");
      }
    })
    .fail(function(jqXHR, textStatus) {
      alert("Request failed: " + textStatus);
    });
  }

function getAno(){

    let dados = new FormData();
    dados.append("op", 4);


    $.ajax({
        url: "assets/controller/controllerVindima.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) { 
        $('#listaAnoVindima').html(msg);  
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}

function getTipoVinha(){

    let dados = new FormData();
    dados.append("op", 5);


    $.ajax({
        url: "assets/controller/controllerVindima.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {
        $('#listaVinhas1').html(msg);  
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function adicionarVinho(id_vindima, button) {

    let dados = new FormData();
    dados.append("op", 6);
    dados.append("id", id_vindima);

    $.ajax({
        url: "assets/controller/controllerVindima.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        let obj = JSON.parse(msg);
        if (obj.flag) {
            alerta("Stock Atualizado", obj.msg, "success");
            getListaVinhos();
            button.disabled = true;
        } else {
            alerta("Vinhos", obj.msg, "error");
            button.disabled = false;
        }
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
        button.disabled = false;
    });
}

function erroPermissao(){
    Swal.fire({
        position: 'center',
        icon: 'error',
        title: "Sem permissão!",
        text: "Não pode aceder a este conteudo",
        showConfirmButton: true,

      })
}

$(document).ready(function () {
    getFuncionario();
    getListaVindima();
    getAno();
    getTipoVinha();
    getListaVinhos();
});