<?php declare(strict_types=1);

require_once 'connection.php';

class Vindima
{

    function registarVindima($vinha, $funcionario, $kg, $dth, $id_ano)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $ano_sql = "SELECT ano.descricao FROM ano WHERE id = " . $id_ano;
        $ano_result = $conn->query($ano_sql);

        if ($ano_result->num_rows > 0) {
            $ano_row = $ano_result->fetch_assoc();
            $descricao_ano = $ano_row['descricao'];

            $check_sql = "SELECT vinha.ano_p_colheita FROM vinha WHERE id = " . $vinha;
            $check_result = $conn->query($check_sql);

            if ($check_result->num_rows > 0) {
                $row = $check_result->fetch_assoc();
                $ano_p_colheita = $row['ano_p_colheita'];

                if ($ano_p_colheita >= $descricao_ano) {
                    $sql = $conn->prepare("INSERT INTO vindima (id_vinha, id_funcionario, kg, dth, id_ano) VALUES (?, ?, ?, ?, ?)");
                    $sql->bind_param("iidsi", $vinha, $funcionario, $kg, $dth, $id_ano);

                    if ($sql->execute()) {
                        $msg = "Registado com sucesso!";
                    } else {
                        $flag = false;
                        $msg = "Erro: " . $conn->error;
                    }
                } else {
                    $flag = false;
                    $msg = "Não pode registrar a vindima porque o ano de colheita da vinha é inferior ao ano da vindima.";
                }
            } else {
                $flag = false;
                $msg = "Erro ao verificar o ano de colheita da vinha.";
            }
        } else {
            $flag = false;
            $msg = "Erro ao verificar a descrição do ano.";
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return ($resp);
    }

    function getListaVindimas()
    {
        global $conn;
        $msg = "";
        session_start();

        $sql = "SELECT vindima.*, vinha.foto, funcionarios.nome, ano.descricao,
                COUNT(vinhos.id) AS vinho_count 
                FROM vindima 
                JOIN vinha ON vindima.id_vinha = vinha.id 
                JOIN funcionarios ON vindima.id_funcionario = funcionarios.bi 
                JOIN ano ON vindima.id_ano = ano.id
                LEFT JOIN vinhos ON vindima.id = vinhos.id_vindima
                GROUP BY vindima.id";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'><img class='img-size' src='" . $row['foto'] . "'></th>";
                $msg .= "<th scope='row'>" . $row['nome'] . "</th>";
                $msg .= "<td>" . $row['kg'] . " KG</td>";
                $msg .= "<td>" . $row['descricao'] . "</td>";
                // Check if wine has already been added
                $disabled = $row['vinho_count'] > 0 ? "disabled" : "";

                if ($_SESSION['tipo'] == 1) {
                $msg .= "<td><button class='btn btn-success' onclick='adicionarVinho(" . $row['id'] . ", this)' " . $disabled . "><i class='fas fa-plus'></i></button></td>";
                $msg .= "<td><button class='btn btn-danger' onclick='removerVinha(" . $row['id'] . ")'><i class='fa fa-trash'></i></button></td>";
                } else {
                    $msg .= "<td><button class='btn btn-secondary' onclick ='erroPermissao()'><i class='fa fa-plus'></i></button></td>";
                    $msg .= "<td><button class='btn btn-secondary' onclick ='erroPermissao()'><i class='fa fa-trash'></i></button></td>";
                }
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function getVinhos() {
        global $conn;
        $msg = "";
        session_start();
    
        // SQL Query to fetch wine details with aggregated castas
        $sql = "SELECT vinhos.id AS id_vinhos, 
                       vinhos.nome, 
                       vinhos.total, 
                       GROUP_CONCAT(castas.descricao SEPARATOR ', ') AS castas
                FROM vinhos 
                JOIN vindima ON vinhos.id_vindima = vindima.id 
                JOIN vinha ON vindima.id_vinha = vinha.id 
                JOIN vinhas_castas ON vinhas_castas.id_vinha = vinha.id 
                JOIN castas ON castas.id = vinhas_castas.id_casta 
                GROUP BY vinhos.id;";
    
        $result = $conn->query($sql);
    
        // Check for results
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . htmlspecialchars($row['nome']) . "</th>";
                $msg .= "<th scope='row'>" . htmlspecialchars($row['total']) . " UN</th>";
                $msg .= "<th scope='row'>" . htmlspecialchars($row['castas']) . "</th>";
                if($_SESSION['tipo'] == 1){
                $msg .= "<td><button class='btn btn-warning' onclick='openVendaVinhoModal(" . $row['id_vinhos'] . ")'><i class='fa fa-v'></i></button></td>";
                }else{
                        $msg .= "<td><button class='btn btn-secondary' onclick ='erroPermissao()'><i class='fa fa-v'></i></button></td>";
                    }
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
    
        $conn->close();
        return $msg;
    }

    function vendaVinho($id_vinho, $quantidade) {
        global $conn;
        $msg = "";
        $flag = true;
    
        // Get current total of wine
        $sql = "SELECT total FROM vinhos WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id_vinho);
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $total = $row['total'];
    
            if ($total >= $quantidade) {
                // Update the total
                $new_total = $total - $quantidade;
                $update_sql = "UPDATE vinhos SET total = ? WHERE id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("ii", $new_total, $id_vinho);
    
                if ($update_stmt->execute()) {
                    $msg = "Venda realizada com sucesso!";
                } else {
                    $flag = false;
                    $msg = "Erro ao atualizar quantidade: " . $conn->error;
                }
            } else {
                $flag = false;
                $msg = "Quantidade insuficiente em Stock.";
            }
        } else {
            $flag = false;
            $msg = "Vinho não encontrado.";
        }
    
        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
    
        $conn->close();
        return $resp;
    }

    function adicionarVinho($id_vindima)
    {
        global $conn;
        $msg = "";
        $flag = true;

        // Obter detalhes da vindima
        $sql = "SELECT vindima.kg, vindima.id_ano, vinha.descricao as nome_vinha, ano.descricao as ano_vindima 
                FROM vindima 
                JOIN vinha ON vindima.id_vinha = vinha.id 
                JOIN ano ON vindima.id_ano = ano.id 
                WHERE vindima.id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id_vindima);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $kg = $row['kg'];
            $nome_vinha = $row['nome_vinha'];
            $ano_vindima = $row['ano_vindima'];

            // Calcular número de garrafas
            $garrafas = floor($kg / 2);

            // Nome do vinho
            $nome_vinho = $nome_vinha . " - " . $ano_vindima;

            // Inserir novo registro na tabela de vinhos
            $insert_sql = "INSERT INTO vinhos (total, id_vindima, nome) VALUES (?, ?, ?)";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bind_param("iis", $garrafas, $id_vindima, $nome_vinho);

            if ($insert_stmt->execute()) {
                $msg = "Vinho adicionado com sucesso!";
            } else {
                $flag = false;
                $msg = "Erro ao adicionar vinho: " . $conn->error;
            }
        } else {
            $flag = false;
            $msg = "Vindima não encontrada.";
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return $resp;
    }

    function getSelectFuncionario()
    {
        global $conn;
        $msg = "<option selected>Escolha um/a Funcionário/a</option>";

        $sql = "SELECT * FROM funcionarios";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {

            while ($row = $result->fetch_assoc()) {
                if ($row['id_estado'] == 1) {
                    $msg .= "<option value='" . $row['bi'] . "'>" . $row['nome'] . "</option>";

                } else {
                    $msg .= "";
                }

            }
        }

        $conn->close();

        return ($msg);
    }


    function getSelectVinha()
    {
        global $conn;
        $msg = "<option selected>Escolha uma Vinha</option>";

        $sql = "SELECT * FROM vinha";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Vinhas registadas</option>";

        }
        $conn->close();

        return ($msg);
    }

    function getSelectAno()
    {
        global $conn;
        $msg = "<option selected>Escolha um Ano</option>";

        $sql = "SELECT * FROM ano";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {

            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";

            }
        } else {
            $msg .= "<option selected>Não existe nenhum ano Criado</option>";


        }


        $conn->close();

        return ($msg);
    }


}

?>