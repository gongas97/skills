<?php

require_once 'connection.php';

class Funcionario{

    function registarFuncionario($bi , $nome , $morada, $tel ,$email ,$salario, $estado){

        global $conn;
        $msg = "";
        $flag = true;

        $sql = "INSERT INTO funcionarios (bi, nome, morada, telefone, email, salario, id_estado) VALUES ('" . $bi . "', '" . $nome . "','" . $morada . "', '" . $tel . "','" . $email . "', '" . $salario . "','" . $estado . "')";


        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com sucesso!";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;

        }


        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return ($resp);

    }

    function getListaFuncionarios(){

        global $conn;
        $msg = "";
        session_start();

        $sql = "SELECT funcionarios.*, estado_funcionario.descr FROM funcionarios, estado_funcionario WHERE funcionarios.id_estado = estado_funcionario.id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                if($row['descr'] == 'Inativo'){
                $msg .= "<tr>";
                $msg .= "<th scope='row'>".$row['bi']."</th>";
                $msg .= "<th scope='row'>".$row['nome']."</th>";
                    $msg .= "<td>".$row['descr']."</td>";
                    if($_SESSION['tipo'] == 1){
                        $msg .= "<td><button class='btn btn-dark' onclick ='getDadosFuncionario(".$row['bi'].")'>Alterar Estado</button></td>";
                    }else{
                        $msg .= "<td><button class='btn btn-secondary' onclick ='erroPermissao()'><i class='fa fa-trash'></i></button></td>";
                    }
                    $msg .= "</tr>";
                }
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function getDadosFuncionario($bi){
        global $conn;
        $msg = "";
        $row = "";

        $sql = "SELECT * FROM funcionarios WHERE bi =".$bi;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));

    }


    function guardaEditFuncionario($bi, $estado, $biOld){
        
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "UPDATE funcionarios SET bi = '".$bi."', id_estado = '".$estado."' WHERE bi =".$biOld;


        if ($conn->query($sql) === TRUE) {
            $msg = "Estado Alterado";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);

    }

    function getEstado(){
        global $conn;
        $msg = "<option selected>Escolha um Estado</option>";

        $sql = "SELECT * FROM estado_funcionario";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='".$row['id']."'>".$row['descr']."</option>"; 
            }
        } else {
            $msg = "<option value='-1'>Sem Estados registados</option>"; 

        }
        $conn->close();

        return ($msg);
    }


    }
?>