<?php declare(strict_types=1); 

require_once 'connection.php';


class Login{

    function registaUser($username, $pw, $tpUser){
    
        global $conn;
        $msg = "";
        $flag = false;

        $foto = "assets/imagens/user/user.webp";
        $pw = md5($pw);

        $stmt = $conn->prepare("INSERT INTO utilizador (user, pw, idtpuser, foto) 
        VALUES (?, ?, ?, ?);");
        $stmt->bind_param("ssis", $username, $pw, $tpUser, $foto);

        $stmt->execute();

        $msg = "Registado com sucesso!";
        $flag = true;
        
        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));

        $stmt->close();
        $conn->close();

        return($resp);

    }

    function login($username, $pw){

        global $conn;
        $msg = "";
        $flag = true;
        session_start();

        $pw = md5($pw);

        $stmt = $conn->prepare("SELECT * FROM utilizador WHERE user LIKE ? AND pw LIKE ?;");
        $stmt->bind_param("ss", $username, $pw);
        $stmt->execute();

        $result = $stmt->get_result();

        if($result->num_rows > 0){
            $row = $result->fetch_assoc();
            $msg = "Bemvindo ".$row['user'];
            $_SESSION['utilizador'] = $row['user'];
            $_SESSION['tipo'] = $row['idtpuser'];
            $_SESSION['foto'] = $row['foto'];
        }else{
            $flag = false;
            $msg = "Erro! Dados Inválidos"; 
        }

        $stmt->close();
        $conn->close();
        
        return (json_encode(array(
            "msg" => $msg,
            "flag" => $flag
        )));
    }

    function logout(){

        session_start();
        session_destroy();

        return("Obrigado!");
    }

    function getTiposUser(){

        global $conn;
        $msg = "<option value = '-1'>Escolha uma opção</option>";


        $stmt = $conn->prepare("SELECT * FROM tipouser");
        $stmt->execute();

        $result = $stmt->get_result();

        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value = '".$row['id']."'>".$row['descricao']."</option>";
            }
        }else{
            $msg .= "<option value = '-1'>Sem tipos registados</option>";
        }

        $stmt->close();
        $conn->close();
        return $msg;
    }

    function mostraVinho1() {
        global $conn;
        $msg = "";
        
        $sql = "SELECT nome, total, id AS id_vinhos FROM vinhos ORDER BY id ASC";
        $result = $conn->query($sql);
    
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $nome = $row['nome'];
                $total = $row['total'];
                // Criação do card com o nome do vinho e o total
                $msg .= "
                <div class='col'>
                    <div class='card p-2 my-4'>
                        <div class='card-body'>
                            <h5 class='card-title'>$nome</h5>
                            <p class='card-text'>Total de garrafas: $total</p>
                            <button class='btn btn-danger' onclick='openCompraVinhoModal(" . $row['id_vinhos'] . ")'>
                                <i class='fa fa-cart-plus'></i> Comprar
                            </button>
                        </div>
                    </div>
                </div>";
            }
        } else {
            $msg .= "<div class='col'>Nenhum vinho encontrado.</div>";
        }
    
        $conn->close();
        return $msg;
    }

    function compraVinho($id_vinho, $quantidade) {
        global $conn;
        $msg = "";
        $flag = true;
    
        // Get current total of wine
        $sql = "SELECT nome, total FROM vinhos WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id_vinho);
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $total = $row['total'];
            $nome = $row['nome'];
    
            if ($total >= $quantidade) {
                // Update the total
                $new_total = $total - $quantidade;
                $update_sql = "UPDATE vinhos SET total = ? WHERE id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("ii", $new_total, $id_vinho);
    
                if ($update_stmt->execute()) {
                    $msg = "Venda realizada com sucesso!";
                } else {
                    $flag = false;
                    $msg = "Erro ao atualizar quantidade: " . $conn->error;
                }
            } else {
                $flag = false;
                $msg = "Quantidade insuficiente em Stock.";
            }
        } else {
            $flag = false;
            $msg = "Vinho não encontrado.";
        }
    
        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg,
            "nome" => $nome,
            "total" => $new_total
        ));
    
        $conn->close();
        return $resp;
    }
    

}

?>