<?php declare(strict_types=1); 

require_once 'connection.php';

class Vinhas{

    function registarVinha($desc, $ha, $dataP, $anoC, $fotoV) {
        global $conn;
        $msg = "";
        $flag = true;
    
        $resp = $this ->  uploads($fotoV, $desc);
        $resp = json_decode($resp, TRUE);

        if($resp['flag']){
            $sql = "INSERT INTO vinha (descricao, ha, data_plantacao, ano_p_colheita, foto) VALUES ('".$desc."','".$ha."','".$dataP."','".$anoC."','".$resp['target']."')";
        }else{
            $sql = "INSERT INTO vinha (descricao, ha, data_plantacao, ano_p_colheita) VALUES ('".$desc."','".$ha."','".$dataP."','".$anoC."')";
        }

        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com sucesso!";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
            $resUpdate = $this -> updateFoto($resp['target'], $desc);        
                    $resUpdate = json_decode($resUpdate, TRUE);
        }
       

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);

    
    }

    function registarCastaVinha($vinha, $casta) {
        global $conn;
        $msg = "";
        $flag = true;
    

        $sql = "INSERT INTO vinhas_castas (id_vinha, id_casta) VALUES ('".$vinha."','".$casta."')";


        if ($conn->query($sql) === TRUE) {
            $msg = "Registada com sucesso!";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }
       

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);

    
    }

    function updateFoto($diretorio, $id){
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "UPDATE vinha SET foto = '".$diretorio."' WHERE id = ".$id;

        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));

        return($resp);
    }


    function getListaVinhas(){

        global $conn;
        $msg = "";
        session_start();

        $sql = "SELECT * FROM vinha";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'><img class='img-size' src='".$row['foto']."'></th>";
                $msg .= "<th scope='row'>".$row['id']."</th>";
                $msg .= "<td>".$row['descricao']."</td>";
                $msg .= "<td>".$row['ha']."</td>";
                $msg .= "<td>".$row['data_plantacao']."</td>";
                $msg .= "<td>".$row['ano_p_colheita']."</td>";
                if($_SESSION['tipo']==1){
                $msg .= "<td><button class='btn btn-warning' onclick ='getDadosVinha(".$row['id'].")'><i class='fa fa-pencil'></i></button></td>";
                    $msg .= "<td><button class='btn btn-danger' onclick ='removerVinha(".$row['id'].")'><i class='fa fa-trash'></i></button></td>";
                }else{
                    $msg .= "<td><button class='btn btn-secondary' onclick ='erroPermissao()'><i class='fa fa-pencil'></i></button></td>";
                    $msg .= "<td><button class='btn btn-secondary' onclick ='erroPermissao()'><i class='fa fa-trash'></i></button></td>";
                }
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    } 

    function removerVinha($id){
        global $conn;
        $msg = "";
        $flag = true;
    
        // Verifica se existem registros de vindima associados à vinha
        $check_sql = "SELECT COUNT(*) as count FROM vindima WHERE id_vinha = ".$id;
        $check_result = $conn->query($check_sql);
    
        if ($check_result->num_rows > 0) {
            $row = $check_result->fetch_assoc();
            if ($row['count'] > 0) {
                $flag = false;
                $msg = "Não pode remover a vinha porque existem registros de vindima associados a ela.";
            } else {
                // Remove a vinha se não houver registros de vindima associados
                $sql = "DELETE FROM vinha WHERE id = ".$id;
                if ($conn->query($sql) === TRUE) {
                    $msg = "Removida com Sucesso";
                } else {
                    $flag = false;
                    $msg = "Erro: " . $sql . "<br>" . $conn->error;
                }
            }
        } else {
            $flag = false;
            $msg = "Erro ao verificar registros de vindima.";
        }
    
        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
    
        $conn->close();
    
        return($resp);
    }

    function getDadosVinha($id){
        global $conn;
        $row = "";

        $sql = "SELECT * FROM vinha WHERE id =".$id;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));

    }


    function guardaEditVinha($desc, $ha, $dataP, $anoC, $foto, $idOld){
        
        global $conn;
        $msg = "";
        $flag = true;
        $sql = "";

        $resp = $this -> uploads($foto, $desc);
        $resp = json_decode($resp, TRUE);

        if($resp['flag']){
            $sql = "UPDATE vinha SET descricao = '".$desc."', ha = '".$ha."',data_plantacao = '".$dataP."',ano_p_colheita = '".$anoC."', foto = '".$resp['target']."' WHERE id =".$idOld;
        }else{
            $sql = "UPDATE vinha SET  descricao = '".$desc."', ha = '".$ha."',data_plantacao = '".$dataP."',ano_p_colheita = '".$anoC."' WHERE id =".$idOld;
        }

        if ($conn->query($sql) === TRUE) {
            $msg = "Editada com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);

    }

    function getSelectVinha(){
        global $conn;
        $msg = "<option selected>Escolha uma Vinha</option>";

        $sql = "SELECT * FROM vinha";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='".$row['id']."'>".$row['descricao']."</option>"; 
            }
        } else {
            $msg = "<option value='-1'>Sem Vinhas registadas</option>"; 

        }
        $conn->close();

        return ($msg);
    }

    function getSelectCasta(){
        global $conn;
        $msg = "<option selected>Escolha uma Casta</option>";

        $sql = "SELECT * FROM castas";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='".$row['id']."'>".$row['descricao']."</option>"; 
            }
        } else {
            $msg = "<option value='-1'>Sem Castas registadas</option>"; 

        }
        $conn->close();

        return ($msg);
    }

    function uploads($img, $id){

        $dir = "../imagens/Vinha".$id."/";
        $dir1 = "assets/imagens/Vinha".$id."/";
        $flag = false;
        $targetBD = "";
    
        if(!is_dir($dir)){
            if(!mkdir($dir, 0777, TRUE)){
                die ("Erro não é possivel criar o diretório");
            }
        }
      if(array_key_exists('foto', $img)){
        if(is_array($img)){
          if(is_uploaded_file($img['foto']['tmp_name'])){
            $fonte = $img['foto']['tmp_name'];
            $ficheiro = $img['foto']['name'];
            $end = explode(".",$ficheiro);
            $extensao = end($end);
    
            $newName = "vinha".date("YmdHis").".".$extensao;
    
            $target = $dir.$newName;
            $targetBD = $dir1.$newName;
    
            $flag = move_uploaded_file($fonte, $target);
            
          } 
        }
      }
        return (json_encode(array(
          "flag" => $flag,
          "target" => $targetBD
        )));
    
    
    }

}


?>