<?php declare(strict_types=1); 

require_once '../model/modelVinha.php';

$vinhas = new Vinhas();

if($_POST['op'] == 1){
    $resp = $vinhas -> registarVinha(
        $_POST['desc'],
        $_POST['ha'],
        $_POST['dataP'],
        $_POST['anoC'],
        $_FILES
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $vinhas -> getListaVinhas();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $vinhas -> removerVinha($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $vinhas -> getDadosVinha($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $vinhas -> guardaEditVinha(
        $_POST['desc'],
        $_POST['ha'],
        $_POST['dataP'],
        $_POST['anoC'],
        $_FILES,
        $_POST['idOld']
    );
    echo ($resp);

}else if($_POST['op'] == 6){
    $resp = $vinhas -> getSelectVinha();
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $vinhas -> getSelectCasta();
    echo($resp);

}else if($_POST['op'] == 8){
    $resp = $vinhas -> registarCastaVinha(
        $_POST['vinha'],
        $_POST['casta']
    );
    echo ($resp);

}





?>