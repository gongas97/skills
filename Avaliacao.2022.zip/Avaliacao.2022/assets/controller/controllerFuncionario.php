<?php

require_once '../model/modelFuncionario.php';

$func = new Funcionario();

if($_POST['op'] == 1){
    $resp = $func -> registarFuncionario(
        $_POST['bi'],
        $_POST['nome'],
        $_POST['morada'],
        $_POST['tel'],
        $_POST['email'],
        $_POST['salario'],
        $_POST['estado']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $func -> getListaFuncionarios();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $func -> getEstado();
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $func -> getDadosFuncionario($_POST['bi']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $func -> guardaEditFuncionario(
        $_POST['bi'],
        $_POST['estado'],
        $_POST['biOld']
    );
    echo ($resp);

}

?>