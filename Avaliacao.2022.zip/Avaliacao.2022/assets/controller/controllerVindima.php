<?php declare(strict_types=1); 

require_once '../model/modelVindima.php';

$vindima = new Vindima();

if($_POST['op'] == 1){
    $resp = $vindima -> registarVindima(
        $_POST['vinha'],
        $_POST['funcionario'],
        $_POST['kg'],
        $_POST['dth'],
        $_POST['ano']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $vindima ->getSelectFuncionario();
    echo ($resp);
}else if($_POST['op'] == 3){
    $resp = $vindima -> getListaVindimas();
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $vindima ->getSelectAno();
    echo ($resp);
}else if($_POST['op'] == 5){
    $resp = $vindima -> getSelectVinha();
    echo($resp);

}else if($_POST['op'] == 6){
    $resp = $vindima -> adicionarVinho($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $vindima -> getVinhos();
    echo($resp);

}else if($_POST['op'] == 8){
    $resp = $vindima -> vendaVinho($_POST['id_vinho'], $_POST['quantidade']);
    echo($resp);

}

?>