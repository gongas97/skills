<?php declare(strict_types=1);
session_start();
if (isset($_SESSION['utilizador'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>VINHAS</title>
        <link rel="stylesheet" href="assets/css/datatables.css">
        <link rel="stylesheet" href="assets/css/select2.css">
        <link rel="stylesheet" href="assets/css/bootstrap.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <script src="assets/js/lib/jquery.js"></script>
        <script src="assets/js/lib/datatables.js"></script>
        <script src="assets/js/lib/select2.js"></script>
        <script src="assets/js/lib/sweatalert.js"></script>
        <script src="assets/js/lib/bootstrap.js"></script>
        <script src="assets/js/vinha.js"></script>
        <script src="assets/js/login.js"></script>
    </head>

    <body>

        <?php include_once 'menu.php' ?>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Vinhas</h5>
                <div class="card-body">
                    <h5 class="card-title">Registar Vinhas</h5>
                    <?php if ($_SESSION['tipo'] == 1) { ?>
                        <form class="row g-3">
                            <div class="col-md-6">
                                <label for="descricaoVinha" class="form-label">Descrição:</label>
                                <input type="text" class="form-control" id="descricaoVinha">
                            </div>
                            <div class="col-md-3">
                                <label for="haVinha" class="form-label">HA:</label>
                                <input type="number" class="form-control" id="haVinha">
                            </div>

                            <div class="col-md-3">
                                <label for="dataPlantacaoVinha" class="form-label">Data Platação:</label>
                                <input type="date" class="form-control" id="dataPlantacaoVinha">
                            </div>

                            <div class="col-md-6">
                                <label for="anoColheitaVinha" class="form-label">Ano para Colheita:</label>
                                <input type="number" class="form-control" id="anoColheitaVinha">
                            </div>

                            <div class="col-md-6">
                                <label for="fotoVinha" class="form-label">Foto:</label>
                                <input type="file" class="form-control" id="fotoVinha">
                            </div>

                            <div class="col-12">
                                <button type="button" class="btn btn-primary" onclick="registaVinha()">Registar</button>
                            </div>
                        </form>
                    <?php } else {
                        echo "<p>Acesso restrito ao registo de vindimas!</p>";
                    } ?>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Vinhas - Castas</h5>
                <div class="card-body">
                    <h5 class="card-title">Registar</h5>
                    <?php if ($_SESSION['tipo'] == 1) { ?>
                        <form class="row g-3">

                            <div class="col-md-6">
                                <label for="listaVinhas" class="form-label">Vinhas</label>
                                <select class="form-control" id="listaVinhas">
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="listaCastas" class="form-label">Castas</label>
                                <select class="form-control" id="listaCastas">
                                </select>
                            </div>

                            <div class="col-12">
                                <button type="button" class="btn btn-primary" onclick="registaCastaVinha()">Registar</button>
                            </div>
                        </form>
                    <?php } else {
                        echo "<p>Acesso restrito ao registo de vindimas!</p>";
                    } ?>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Vinhas</h5>
                <div class="card-body">
                    <h5 class="card-title">Listagem de Vinhas</h5>

                    <table class="table table-striped" nif="tblVinhas">
                        <thead>
                            <tr>
                                <th scope="col">Foto</th>
                                <th scope="col">ID</th>
                                <th scope="col">Descrição</th>
                                <th scope="col">Ha</th>
                                <th scope="col">Data da Plantação</th>
                                <th scope="col">Ano para Colheita</th>
                                <th scope="col">Editar</th>
                                <th scope="col">Remover</th>
                            </tr>
                        </thead>

                        <tbody id="listagemVinhas">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="formEditVinha" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Editar Vinha</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container">
                            <div class="card">
                                <h5 class="card-header">Vinha <span id="nmVinha"></span></h5>
                                <div class="card-body">
                                    <h5 class="card-title">Editar</h5>
                                    <form class="row g-3">
                                        <div class="col-md-6">
                                            <label for="descricaoVinhaEdit" class="form-label">Descrição</label>
                                            <input type="text" class="form-control" id="descricaoVinhaEdit">
                                        </div>
                                        <div class="col-md-3">
                                            <label for="haVinhaEdit" class="form-label">Ha</label>
                                            <input type="number" class="form-control" id="haVinhaEdit">
                                        </div>

                                        <div class="col-md-3">
                                            <label for="dataPlantacaoEdit" class="form-label">Data Plantação</label>
                                            <input type="date" class="form-control" id="dataPlantacaoEdit">
                                        </div>

                                        <div class="col-md-6">
                                            <label for="anoColheitaEdit" class="form-label">Ano Colheita</label>
                                            <input type="number" class="form-control" id="anoColheitaEdit">
                                        </div>

                                        <div class="col-md-6">
                                            <label for="fotoEdit" class="form-label">Fotografia</label>
                                            <input type="file" class="form-control" id="fotoEdit">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="button" class="btn btn-primary" id="btnGuardar">Guardar</button>
                    </div>
                </div>
            </div>
        </div>
    </body>

    </html>

    <?php
} else {
    echo "sem permissão!";
}

?>