<?php declare(strict_types=1);
session_start();

require('assets/libraries/fpdf.php');

if (isset($_SESSION['utilizador'])) {
    ?>


    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>MENU</title>
        <link rel="stylesheet" href="assets/css/datatables.css">
        <link rel="stylesheet" href="assets/css/select2.css">
        <link rel="stylesheet" href="assets/css/bootstrap.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

        <script src="assets/js/lib/jquery.js"></script>
        <script src="assets/js/lib/datatables.js"></script>
        <script src="assets/js/lib/select2.js"></script>
        <script src="assets/js/lib/sweatalert.js"></script>
        <script src="assets/js/lib/bootstrap.js"></script>
        <script src="assets/js/login.js"></script>
    </head>

    <body>
        <?php include_once 'menu.php' ?>

        <div class="g-5">

            <!-- Carousel -->
            <div id="carouselExampleIndicators" class="carousel slide carousel-container" data-bs-ride="carousel">
                <div class="carousel-inner mb-5">
                    <div class="carousel-item active">
                        <img src="assets/imagens/01-Albenaz-5-vinos1-1.jpg" class="d-block w-80 mx-auto img-fluid"
                            alt="Slide 1">
                        <div class="carousel-caption d-none d-md-block">
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="assets/imagens/01-Albenaz-5-vinos1-1.jpg" class="d-block w-80 mx-auto img-fluid"
                            alt="Slide 2">
                        <div class="carousel-caption d-none d-md-block">
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="assets/imagens/01-Albenaz-5-vinos1-1.jpg" class="d-block w-80 mx-auto img-fluid"
                            alt="Slide 3">
                        <div class="carousel-caption d-none d-md-block">
                        </div>
                    </div>
                </div>
            </div>


            <div class="row row-cols-1 row-cols-md-3 mb-5" id="wineCardsContainer"></div>

                <div class="modal fade" id="compraVinhoModal" tabindex="-1" aria-labelledby="compraVinhoModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="compraVinhoModalLabel">Compra de Vinho</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="compraVinhoForm">
                                    <div class="mb-3">
                                        <label for="quantidade" class="form-label">Quantidade</label>
                                        <input type="number" class="form-control" id="quantidade1" name="quantidade" min="1"
                                            required>
                                    </div>
                                    <input type="hidden" id="compraVinhoId1" name="id_vinho">
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                <button type="button" class="btn btn-primary" onclick="compraVinho()">Comprar</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Scripts necessários -->
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    </body>

    </html>

    <?php
} else {
    echo "sem permissão!";
}

?>