<?php declare(strict_types=1); 
session_start();
if (isset($_SESSION['utilizador'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>FUNCIONÁRIOS</title>
        <link rel="stylesheet" href="assets/css/datatables.css">
        <link rel="stylesheet" href="assets/css/select2.css">
        <link rel="stylesheet" href="assets/css/bootstrap.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <script src="assets/js/lib/jquery.js"></script>
        <script src="assets/js/lib/datatables.js"></script>
        <script src="assets/js/lib/select2.js"></script>
        <script src="assets/js/lib/sweatalert.js"></script>
        <script src="assets/js/lib/bootstrap.js"></script>
        <script src="assets/js/funcionario.js"></script>
        <script src="assets/js/login.js"></script>
    </head>

    <body>

        <?php include_once 'menu.php' ?>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Funcionários</h5>
                <div class="card-body">
                    <h5 class="card-title">Registar funcionário</h5>
                    <?php if ($_SESSION['tipo'] == 1) { ?>
                    <form class="row g-3">
                        <div class="col-md-6">
                            <label for="biFuncionario" class="form-label">BI:</label>
                            <input type="number" class="form-control" id="biFuncionario">
                        </div>
                        <div class="col-md-3">
                            <label for="nomeFuncionario" class="form-label">Nome:</label>
                            <input type="text" class="form-control" id="nomeFuncionario">
                        </div>

                        <div class="col-md-3">
                            <label for="moradaFuncionario" class="form-label">Morada:</label>
                            <input type="text" class="form-control" id="moradaFuncionario">
                        </div>

                        <div class="col-md-6">
                            <label for="telFuncionario" class="form-label">Telefone:</label>
                            <input type="tel" class="form-control" id="telFuncionario">
                        </div>

                        <div class="col-md-6">
                            <label for="emailFuncionario" class="form-label">Email:</label>
                            <input type="email" class="form-control" id="emailFuncionario">
                        </div>

                        <div class="col-md-6">
                            <label for="salarioFuncionario" class="form-label">Salario:</label>
                            <input type="number" class="form-control" id="salarioFuncionario">
                        </div>

                        <div class="col-md-6">
                            <label for="estadoFuncionario" class="form-label">Estado</label>
                            <select class="form-control" id="estadoFuncionario">
                            </select>
                        </div>

                        <div class="col-12">
                            <button type="button" class="btn btn-primary" onclick="registaFuncionario()">Registar</button>
                        </div>
                    </form>
                    <?php } else {
                        echo "<p>Acesso restrito ao registo de vindimas!</p>";
                    } ?>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Listagem de Funcionários</h5>
                <div class="card-body">

                    <table class="table table-striped" nif="tblFuncionario">
                        <thead>
                            <tr>
                                <th scope="col">BI</th>
                                <th scope="col">Nome</th>
                                <th scope="col">Estado</th>
                                <th scope="col">Alterar Estado</th>
                            </tr>
                        </thead>

                        <tbody id="listagemFuncionarios">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="formEditFuncionario" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Editar Funcionario</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container">
                            <div class="card">
                                <h5 class="card-header">Alterar Estado <span id="nmFuncionario"></span></h5>
                                <div class="card-body">
                                    <h5 class="card-title">Editar</h5>
                                    <form class="row g-3">
                                        <div class="col-md-6">
                                            <label for="biFuncionarioEdit" class="form-label">BI</label>
                                            <input type="number" class="form-control" id="biFuncionarioEdit" disabled>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="estadoFuncionarioEdit" class="form-label">Estado</label>
                                            <select class="form-control" id="estadoFuncionarioEdit">
                                            </select>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="button" class="btn btn-primary" id="btnGuardar">Guardar</button>
                    </div>
                </div>
            </div>
        </div>
    </body>

    </html>

    <?php
} else {
    echo "sem permissão!";
}

?>