<?php declare(strict_types=1);
session_start();
if (isset($_SESSION['utilizador'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>VINDIMAS</title>
        <link rel="stylesheet" href="assets/css/datatables.css">
        <link rel="stylesheet" href="assets/css/select2.css">
        <link rel="stylesheet" href="assets/css/bootstrap.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">

        <script src="assets/js/lib/jquery.js"></script>
        <script src="assets/js/lib/datatables.js"></script>
        <script src="assets/js/lib/select2.js"></script>
        <script src="assets/js/lib/sweatalert.js"></script>
        <script src="assets/js/lib/bootstrap.js"></script>
        <script src="assets/js/vindima.js"></script>
        <script src="assets/js/login.js"></script>
    </head>

    <body>

        <?php include_once 'menu.php' ?>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Vindimas</h5>
                <div class="card-body">
                    <h5 class="card-title">Registar Vindimas</h5>
                    <?php if ($_SESSION['tipo'] == 1) { ?>
                    <form class="row g-3">
                        <div class="col-md-6">
                            <label for="listaVinhas1" class="form-label">Vinha:</label>
                            <select class="form-control" id="listaVinhas1"></select>
                        </div>
                        <div class="col-md-6">
                            <label for="listaFuncionarios1" class="form-label">Funcionário:</label>
                            <select class="form-control" id="listaFuncionarios1"></select>
                        </div>

                        <div class="col-md-3">
                            <label for="kgVindima" class="form-label">KG:</label>
                            <input type="text" class="form-control" id="kgVindima">
                        </div>

                        <div class="col-md-6">
                            <label for="dthVindima" class="form-label">Data/Hora:</label>
                            <input type="datetime-local" class="form-control" id="dthVindima">
                        </div>

                        <div class="col-md-3">
                            <label for="listaAnoVindima" class="form-label">Ano:</label>
                            <select class="form-control" id="listaAnoVindima"></select>
                        </div>

                        <div class="col-12">
                            <button type="button" class="btn btn-primary" onclick="registaVindima()">Registar</button>
                        </div>
                    </form>
                    <?php } else {
                        echo "<p>Acesso restrito ao registo de vindimas!</p>";
                    } ?>
                </div>
            </div>
        </div>


        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Vindimas</h5>
                <div class="card-body">
                    <h5 class="card-title">Listagem de Vindimas</h5>

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Foto Vinha</th>
                                <th scope="col">Funcionário/a</th>
                                <th scope="col">KG</th>
                                <th scope="col">Ano Vindima</th>
                                <th scope="col">Adicionar Vinhos</th>
                                <th scope="col">Remover</th>
                            </tr>
                        </thead>

                        <tbody id="listagemVindimas"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Vinhos</h5>
                <div class="card-body">
                    <h5 class="card-title">Listagem de Vinhos</h5>

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Nome Vinho</th>
                                <th scope="col">Stock Total</th>
                                <th scope="col">Castas</th>
                                <th scope="col">Venda</th>
                            </tr>
                        </thead>

                        <tbody id="listagemVinhos"></tbody>
                    </table>
                </div>
            </div>
        </div>


        <div class="modal fade" id="vendaVinhoModal" tabindex="-1" aria-labelledby="vendaVinhoModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="vendaVinhoModalLabel">Venda de Vinho</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="vendaVinhoForm">
                            <div class="mb-3">
                                <label for="quantidade" class="form-label">Quantidade</label>
                                <input type="number" class="form-control" id="quantidade" name="quantidade" min="1" placeholder="0"
                                    required>
                            </div>
                            <input type="hidden" id="vendaVinhoId" name="id_vinho">
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-primary" onclick="vendaVinho()">Vender</button>
                    </div>
                </div>
            </div>
        </div>
    </body>

    </html>

    <?php
} else {
    echo "sem permissão!";
}
?>