<nav id="sidebar" class="sidebar js-sidebar">
    <div class="sidebar-content js-simplebar">
        <a class='sidebar-brand' href='index.html'>
            <span class="sidebar-brand-text align-middle">
                Biblioteca Skilliana
                <sup><small class="badge bg-primary text-uppercase">Books</small></sup>
            </span>
            <svg class="sidebar-brand-icon align-middle" width="32px" height="32px" viewBox="0 0 24 24" fill="none"
                stroke="#FFFFFF" stroke-width="1.5" stroke-linecap="square" stroke-linejoin="miter" color="#FFFFFF"
                style="margin-left: -3px">
                <path d="M12 4L20 8.00004L12 12L4 8.00004L12 4Z"></path>
                <path d="M20 12L12 16L4 12"></path>
                <path d="M20 16L12 20L4 16"></path>
            </svg>
        </a>


        <ul class="sidebar-nav">
            <li class="sidebar-header">
                Important Pages
            </li>

            <?php if (isset($_SESSION['funcionario'])): ?>
                <li class="nav-item">
                    <a class="nav-link btn btn-info text-white" href="#" onclick="logout()">Logout</a>
                </li>
            <?php endif; ?>

            <li class="sidebar-item">
                <a class="sidebar-link" href="#" data-toggle="modal" data-target="#loginModal">
                    <i class="align-middle" data-feather="sliders"></i>
                    <span class="align-middle">Dashboard</span>
                </a>
            </li>
            <!-- Livros Dropdown -->
            <li class="sidebar-item">
                <a data-bs-target="#livrosDropdown" data-bs-toggle="collapse" class="sidebar-link collapsed">
                    <i class="align-middle" data-feather="book"></i> <span class="align-middle">Livros</span>
                </a>
                <ul id="livrosDropdown" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                    <li class="sidebar-item"><a class="sidebar-link" href="registoLivro.php">Registar</a></li>
                    <li class="sidebar-item"><a class="sidebar-link" href="editarLivro.php">Editar</a></li>
                    <li class="sidebar-item"><a class="sidebar-link" href="listagemLivro.php">Listagem</a></li>
                </ul>
            </li>

            <!-- Sócios Dropdown -->
            <li class="sidebar-item">
                <a data-bs-target="#sociosDropdown" data-bs-toggle="collapse" class="sidebar-link collapsed">
                    <i class="align-middle" data-feather="user"></i> <span class="align-middle">Sócios</span>
                </a>
                <ul id="sociosDropdown" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                    <li class="sidebar-item"><a class="sidebar-link" href="registoSocio.php">Registar</a></li>
                    <li class="sidebar-item"><a class="sidebar-link" href="editarSocio.php">Editar</a></li>
                    <li class="sidebar-item"><a class="sidebar-link" href="listagemSocio.php">Listagem</a></li>
                </ul>
            </li>

            <!-- Funcionários Dropdown -->
            <li class="sidebar-item">
                <a data-bs-target="#funcionariosDropdown" data-bs-toggle="collapse" class="sidebar-link collapsed">
                    <i class="align-middle" data-feather="user"></i> <span class="align-middle">Colaboradores</span>
                </a>
                <ul id="funcionariosDropdown" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                    <li class="sidebar-item"><a class="sidebar-link" href="registoFuncionario.php">Registar</a>
                    </li>
                    <li class="sidebar-item"><a class="sidebar-link" href="editarFuncionario.php">Editar</a></li>
                    <li class="sidebar-item"><a class="sidebar-link" href="listagemFuncionario.php">Listagem</a></li>
                </ul>
            </li>

            <!-- Autores Dropdown -->
            <li class="sidebar-item">
                <a data-bs-target="#autoresDropdown" data-bs-toggle="collapse" class="sidebar-link collapsed">
                    <i class="align-middle" data-feather="user"></i> <span class="align-middle">Autores</span>
                </a>
                <ul id="autoresDropdown" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                    <li class="sidebar-item"><a class="sidebar-link" href="registoAutor.php">Registar</a></li>
                    <li class="sidebar-item"><a class="sidebar-link" href="editarAutor.php">Editar</a></li>
                    <li class="sidebar-item"><a class="sidebar-link" href="listagemAutor.php">Listagem</a></li>
                </ul>
            </li>

            <!-- Empréstimos Dropdown -->
            <li class="sidebar-item">
                <a data-bs-target="#emprestimosDropdown" data-bs-toggle="collapse" class="sidebar-link collapsed">
                    <i class="align-middle" data-feather="gift"></i> <span class="align-middle">Empréstimos</span>
                </a>
                <ul id="emprestimosDropdown" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                    <li class="sidebar-item"><a class="sidebar-link" href="registoEmprestimo.php">Registar</a></li>
                    <li class="sidebar-item"><a class="sidebar-link" href="editarEmprestimo.php">Estender a Data de
                            Empréstimo</a></li>
                    <li class="sidebar-item"><a class="sidebar-link" href="listagemEmprestimo.php">Listagem</a></li>
                </ul>
            </li>

            <li class="sidebar-header">
                Others Pages
            </li>

            <li class="sidebar-item">
                <a class="sidebar-link" href="moverLivros.php">
                    <i class="align-middle"></i> <span class="align-middle">Mover Livros de Localização</span>
                </a>
            </li>

            <!-- Localizações Dropdown -->
            <li class="sidebar-item">
                <a data-bs-target="#localizacoesDropdown" data-bs-toggle="collapse" class="sidebar-link collapsed">
                    <i class="align-middle" data-feather=""></i> <span class="align-middle">Localizações</span>
                </a>
                <ul id="localizacoesDropdown" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                    <li class="sidebar-item"><a class="sidebar-link" href="seccoes.php">Secções</a></li>
                    <li class="sidebar-item"><a class="sidebar-link" href="estantes.php">Estantes</a></li>
                </ul>
            </li>
        </ul>
    </div>
</nav>

<div class="main">
    <nav class="navbar navbar-expand navbar-light navbar-bg">
        <a class="sidebar-toggle js-sidebar-toggle">
            <i class="hamburger align-self-center"></i>
        </a>

        <ul class="navbar-nav d-none d-lg-flex">
            <li class="nav-item px-2">
                <a class="nav-link" href="index.html" id="megaDropdown" role="button" aria-haspopup="true"
                    aria-expanded="false">
                    <span>Home Page</span>
                </a>
            </li>
        </ul>

        <!-- Aligns the book icon to the right -->
        <div class="ms-auto"> <!-- Use ms-auto for Bootstrap 5 -->
            <a class="nav-link" href="#" title="Books">
                <i class="fas fa-book"></i> BIBLIOTECA SKILLIANA
            </a>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="LoginModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="LoginModalLabel">LOGIN</h5>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="LoginForm">
                            <div class="mb-3">
                                <label for="passwordLogin" class="form-label">Password</label>
                                <input type="password" class="form-control" id="passwordLogin">
                            </div>

                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                            <button type="button" class="btn btn-primary" onclick="login()">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="assets/js/login.js"></script>
    <script src="assets/js/sweatalert.js"></script>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>