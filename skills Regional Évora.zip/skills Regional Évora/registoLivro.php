<?php

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords"
        content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <link rel="shortcut icon" href="img/icons/icon-48x48.png" />

    <link rel="canonical" href="https://demo.adminkit.io/forms-layouts.html" />

    <title>BlSkilliana - Livro</title>



    <!-- BEGIN SETTINGS -->
    <!-- Remove this after purchasing -->
    <link class="js-stylesheet" href="css/light.css" rel="stylesheet">

    <script src="assets/js/datatables.js"></script>
    <script src="assets/js/jquery.js"></script>
    <style>
        body {
            opacity: 0;
        }
    </style>

</head>

<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-layout="default">
    <div class="wrapper">

        <?php include_once 'menu.php' ?>

        <main class="content">
            <div class="container-fluid p-0">

                <div class="mb-3">
                    <h1 class="h3 d-inline align-middle">Registar</h1>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Livro</h5>
                            </div>
                            <div class="card-body">
                                <form>
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label">ISBN</label>
                                            <input type="number" class="form-control" id="ISBNLivro">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Título</label>
                                            <input type="text" class="form-control" id="tituloLivro">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Data Lançamento</label>
                                            <input type="date" class="form-control" id="dataLanLivro">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Sinopse</label>
                                            <input class="form-control" type="text" id="sinopseLivro">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Edição</label>
                                            <input type="text" class="form-control" id="edicaoLivro"
                                                name="historiaH"></input>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Editora</label>
                                            <input class="form-control" type="text" id="editoraLivro">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Idioma</label>
                                            <input type="text" class="form-control" id="idiomaLivro">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Numero de Páginas</label>
                                            <input type="number" class="form-control" id="paginasLivro">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Estado</label>
                                            <select class="form-select" id="estadoLivro">
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Quantidade</label>
                                            <input type="number" class="form-control" id="quantLivro">
                                        </div>

                                    </div>
                                    <button type="button" class="btn btn-primary"
                                        onclick="registarLivro()">Registar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Escritor</h5>
                            </div>
                            <div class="card-body">
                                <form>
                                    <div class="row mb-3">
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Autor</label>
                                            <select class="form-select" id="listaAutores">
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Livro</label>
                                            <select class="form-select" id="listaLivros">
                                            </select>
                                        </div>

                                    </div>
                                    <button type="button" class="btn btn-primary"
                                        onclick="registarEscritor()">Defenir Escritor</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Localização</h5>
                            </div>
                            <div class="card-body">
                                <form>
                                    <div class="row mb-3">
                                        
                                        <div class="col-md-6">
                                            <label class="form-label">Estante</label>
                                            <select class="form-select" id="listaEstantes">
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Livro</label>
                                            <select class="form-select" id="listaLivros2">
                                            </select>
                                        </div>

                                    </div>
                                    <button type="button" class="btn btn-primary"
                                        onclick="localizacao()">Defenir Localização</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php include_once 'footer.php' ?>

    </div>
    </div>

    <script src="assets/js/app.js"></script>
    <script src="assets/js/livro.js"></script>
    <script src="assets/js/sweatalert.js"></script>

</html>

<?php

?>