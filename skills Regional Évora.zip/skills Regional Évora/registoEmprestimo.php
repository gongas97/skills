<?php

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords"
        content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <link rel="shortcut icon" href="img/icons/icon-48x48.png" />

    <link rel="canonical" href="https://demo.adminkit.io/forms-layouts.html" />

    <title>BlSkilliana - Dashboard</title>



    <!-- BEGIN SETTINGS -->
    <!-- Remove this after purchasing -->
    <link class="js-stylesheet" href="css/light.css" rel="stylesheet">

    <script src="assets/js/datatables.js"></script>
    <script src="assets/js/jquery.js"></script>
    <style>
        body {
            opacity: 0;
        }
    </style>

</head>

<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-layout="default">
    <div class="wrapper">

        <?php include_once 'menu.php' ?>

        <main class="content">
            <div class="container-fluid p-0">

                <div class="mb-3">
                    <h1 class="h3 d-inline align-middle">Registar</h1>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Empréstimo</h5>
                            </div>
                            <div class="card-body">
                                <form>
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Data do Registo do Empéstimo</label>
                                            <input type="date" class="form-control" id="dataRegistoEmprestimo">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Data Prevista para Devolução</label>
                                            <input type="date" class="form-control" id="dataDevolucaoEmprestimo">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Sócio</label>
                                            <select class="form-select" id="listaSocios2">
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Colaborador que cedeu o Empréstimo</label>
                                            <select class="form-select" id="listaFuncionarios">
                                            </select>
                                        </div>

                                    </div>
                                    <button type="button" class="btn btn-primary"
                                        onclick="registaEmprestimo()">Registar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Livros por Empréstimo</h5>
                            </div>
                            <div class="card-body">
                                <form>
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Código do empréstimo</label>
                                            <select class="form-select" id="codEmprestimo">
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Livros</label>
                                            <select class="form-select" id="listaLivros2">
                                            </select>
                                        </div>

                                    </div>
                                    <button type="button" class="btn btn-primary"
                                        onclick="registaLivrosEmprestimo()">Registar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Devolução</h5>
                            </div>
                            <div class="card-body">
                                <form>
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Cod Emprestimo</label>
                                            <select class="form-select" id="listaEmprestimos4"
                                                onchange="carregarLivrosAssociados()">
                                                <!-- Options will be populated dynamically -->
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Livros Associados</label>
                                            <select class="form-select" id="listaLivrosAssociados">
                                                <!-- Livros serão carregados dinamicamente com base no empréstimo selecionado -->
                                            </select>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-primary" id="btnGuardaEdit1"
                                        onclick="devolucao()">Devolução</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php include_once 'footer.php' ?>

    </div>
    </div>

    <script src="assets/js/app.js"></script>
    <script src="assets/js/emprestimo.js"></script>
    <script src="assets/js/sweatalert.js"></script>

</html>

<?php

?>