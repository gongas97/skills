<?php

require_once 'connection.php';

class Socio {

    function registaSocio($nif, $nome, $num, $morada, $email, $tel, $dataN, $atividade) {
        global $conn;
        $msg = "";
        $flag = true;
    
        // Check if the NIF already exists in the database
        $sqlCheck = "SELECT nif FROM socio WHERE nif = ?";
    
        if ($stmtCheck = $conn->prepare($sqlCheck)) {
            // Bind the parameter
            $stmtCheck->bind_param("s", $nif);
    
            // Execute the query
            $stmtCheck->execute();
    
            // Store the result
            $stmtCheck->store_result();
    
            // Check if any record was found
            if ($stmtCheck->num_rows > 0) {
                $flag = false;
                $msg = "Error: Socio already registered with this NIF.";
                $stmtCheck->close();
            } else {
                // Close the check statement
                $stmtCheck->close();
    
                // Validate the phone number (must be exactly 9 digits)
                if (strlen($tel) != 9 || !is_numeric($tel)) {
                    $flag = false;
                    $msg = "Error: The phone number must have exactly 9 digits.";
                } else {
                    // Validate age (must be at least 10 years)
                    $dataNascimento = new DateTime($dataN);
                    $dataAtual = new DateTime();
                    $idade = $dataAtual->diff($dataNascimento)->y;
    
                    if ($idade < 10) {
                        $flag = false;
                        $msg = "Error: The age must be at least 10 years.";
                    } else {
                        // Prepare the SQL query to insert a new socio
                        $sql = "INSERT INTO socio (nif, nome, numeroSocio, morada, email, telefone, dataNascimento, idAtividade) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
                        // Prepare the statement
                        if ($stmt = $conn->prepare($sql)) {
                            // Bind the parameters to the placeholders
                            $stmt->bind_param("ssisssss", $nif, $nome, $num, $morada, $email, $tel, $dataN, $atividade);
    
                            // Execute the statement
                            if ($stmt->execute()) {
                                $msg = "Registered successfully!";
                            } else {
                                $flag = false;
                                $msg = "Error registering: " . $stmt->error;
                            }
    
                            // Close the statement
                            $stmt->close();
                        } else {
                            $flag = false;
                            $msg = "Error preparing the query: " . $conn->error;
                        }
                    }
                }
            }
        } else {
            $flag = false;
            $msg = "Error checking NIF: " . $conn->error;
        }
    
        // Close the database connection
        $conn->close();
    
        // Create the JSON response
        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );
    
        return $resp;
    }

    function getDados1($socioSelect2) {
        global $conn;
        $msg = "";
        $row = "";

        $sql = "SELECT * FROM socio WHERE nif =" . $socioSelect2;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function guardaEdicao1($nif, $nome, $numeroSocio, $morada, $email, $telefone, $dataNascimento, $oldNif) {
        global $conn;
        $msg = "";
        $flag = true;
        
        // Prepare the SQL statement
        $sql = "UPDATE socio SET 
                nif = ?, 
                nome = ?, 
                numeroSocio = ?, 
                morada = ?, 
                email = ?, 
                telefone = ?, 
                dataNascimento = ?
                WHERE nif = ?";
        
        // Prepare the statement
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            // Bind the parameters
            $stmt->bind_param("isissisi", $nif, $nome, $numeroSocio, $morada, $email, $telefone, $dataNascimento, $oldNif);
            
            // Execute the statement
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $msg = "Editing completed";
                } else {
                    $msg = "No rows updated. Check if the NIF exists.";
                }
            } else {
                $flag = false;
                $msg = "Error executing update: " . $stmt->error;
            }
        
            // Closing the statement
            $stmt->close();
        } else {
            $flag = false;
            $msg = "Error preparing the statement: " . $conn->error;
        }
    
        // Closing the connection
        $conn->close();
    
        return json_encode(array("flag" => $flag, "msg" => $msg));
    }
    

    function getListaSocio() {

        global $conn;
        $msg = "";

        $sql = "SELECT socio.*, atividade.descricao FROM socio, atividade WHERE socio.idAtividade = atividade.id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>".$row['nif']."</th>";
                $msg .= "<th scope='row'>".$row['nome']."</th>";
                $msg .= "<td>".$row['descricao']."</td>";
                $msg .= "<td><button class='btn btn-danger' onclick ='deleteSocio(".$row['nif'].")'><i class='fa fa-trash'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>No Records</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function getListaSocioInativos() {
        global $conn;
        $msg = "";
    
        // Updated SQL query to sort by nome
        $sql = "SELECT socio.*, atividade.descricao 
                FROM socio 
                JOIN atividade ON socio.idAtividade = atividade.id 
                WHERE atividade.descricao = 'inativo' 
                ORDER BY socio.nome ASC"; // Change to ORDER BY socio.nif ASC if needed
    
        $result = $conn->query($sql);
    
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['nif'] . "</th>";
                $msg .= "<th scope='row'>" . $row['nome'] . "</th>";
                $msg .= "<td>" . $row['descricao'] . "</td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr><td colspan='3'>No Records</td></tr>";
        }
    
        $conn->close();
        return $msg;
    }

    function deleteSocio($nif) {
        global $conn;
        $msg = "";
        $flag = true;
    
        // Defining the query with a prepared statement
        $sql = "DELETE FROM socio WHERE nif = ?";
        
        // Preparing the statement
        $stmt = $conn->prepare($sql);
    
        if ($stmt) {
            // Binding the parameter to the statement
            $stmt->bind_param("i", $nif);
    
            // Executing the statement
            if ($stmt->execute()) {
                $msg = "Removed successfully";
            } else {
                $flag = false;
                $msg = "Error removing the record: " . $stmt->error;
            }
    
            // Closing the statement
            $stmt->close();
        } else {
            $flag = false;
            $msg = "Error preparing the statement: " . $conn->error;
        }
    
        // Closing the connection
        $conn->close();
    
        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    function getDadosSocio($socioSelect) {
        global $conn;
        $msg = "";
        $row = "";

        $sql = "SELECT * FROM socio WHERE nif =" . $socioSelect;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function guardaEdicaoSocio($atividade, $oldNif) {
        global $conn;
        $msg = "";
        $flag = true;
        
        // Prepare the SQL statement
        $sql = "UPDATE socio SET 
                idAtividade = ? 
                WHERE nif = ?";
        
        // Prepare the statement
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            // Bind the parameters
            $stmt->bind_param("ss", $atividade, $oldNif);
            
            // Execute the statement
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $msg = "Editing completed";
                } else {
                    $msg = "No rows updated. Check if the NIF exists.";
                }
            } else {
                $flag = false;
                $msg = "Error executing update: " . $stmt->error;
            }
        
            // Closing the statement
            $stmt->close();
        } else {
            $flag = false;
            $msg = "Error preparing the statement: " . $conn->error;
        }
    
        // Closing the connection
        $conn->close();
    
        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    function getAtividade() {
        global $conn;
        $msg = "<option selected>Select a Activity Type</option>";

        $sql = "SELECT * FROM atividade";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>"; 
            }
        } else {
            $msg = "<option value='-1'>No Activitys Types registered</option>"; 
        }
        $conn->close();

        return ($msg);
    }

    function getSocio() {
        global $conn;
        $msg = "<option selected>Select an partner</option>";

        $sql = "SELECT * FROM socio";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['nif'] . "'>" . $row['nome'] . " - Nº:" . $row['numeroSocio'] . "</option>"; 
            }
        } else {
            $msg = "<option value='-1'>No partners registered</option>"; 
        }
        $conn->close();

        return ($msg);
    }

    function getAutores() {
        global $conn;
        $msg = "<option selected>Select an author</option>";

        $sql = "SELECT * FROM autor";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['nif'] . "'>" . $row['nome'] . "</option>"; 
            }
        } else {
            $msg = "<option value='-1'>No authors registered</option>"; 
        }
        $conn->close();

        return ($msg);
    }

    function getEstantes() {
        global $conn;
        $msg = "<option selected>Select an localization</option>";

        $sql = "SELECT * FROM estante";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>"; 
            }
        } else {
            $msg = "<option value='-1'>No localization registered</option>"; 
        }
        $conn->close();

        return ($msg);
    }
}
?>
