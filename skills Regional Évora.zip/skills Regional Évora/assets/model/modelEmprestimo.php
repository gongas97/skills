<?php

require_once 'connection.php';

class Emprestimo {

    function registarEmprestimo ($dataR, $dataD, $socio, $colaborador) {

        global $conn;
        $msg = "";
        $flag = true;
    
        // Prepare the SQL query with placeholders
        $sql = "INSERT INTO emprestimo (dataRegisto, dataPrevistaDevolucao, nifSocio, nifFuncionario) 
                VALUES (?, ?, ?, ?)";
    
        // Prepare the statement
        if ($stmt = $conn->prepare($sql)) {
            
            // Bind the parameters to the placeholders
            $stmt->bind_param("ssss", $dataR, $dataD, $socio, $colaborador);
    
            // Execute the statement
            if ($stmt->execute()) {
                $msg = "Registered successfully!";
            } else {
                $flag = false;
                $msg = "Error registering: " . $stmt->error;
            }
    
            // Close the statement
            $stmt->close();
            
        } else {
            $flag = false;
            $msg = "Error preparing the query: " . $conn->error;
        }
    
        // Close the database connection
        $conn->close();
    
        // Create the JSON response
        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );
    
        return $resp;
    }

    function registarLivrosEmprestimo($cod, $livro) {
        global $conn;
        $msg = "";
        $flag = true;
    
        // Start a transaction
        $conn->begin_transaction();
    
        try {
            // Prepare the SQL query to decrement the quantity of the book
            $sqlUpdate = "UPDATE livro SET quantidade = quantidade - 1 WHERE ISBN = ?";
            if ($stmtUpdate = $conn->prepare($sqlUpdate)) {
                $stmtUpdate->bind_param("s", $livro);
                if (!$stmtUpdate->execute()) {
                    throw new Exception("Error updating quantity: " . $stmtUpdate->error);
                }
                $stmtUpdate->close();
            } else {
                throw new Exception("Error preparing update query: " . $conn->error);
            }
    
            // Check the new quantity of the book
            $sqlCheck = "SELECT quantidade, idEstado FROM livro WHERE ISBN = ?";
            if ($stmtCheck = $conn->prepare($sqlCheck)) {
                $stmtCheck->bind_param("s", $livro);
                $stmtCheck->execute();
                $result = $stmtCheck->get_result();
                $row = $result->fetch_assoc();
    
                // If quantity reaches zero, update the state to inactive
                if ($row['quantidade'] <= 0) {
                    $sqlDeactivate = "UPDATE livro SET idEstado = 2 WHERE ISBN = ?";
                    if ($stmtDeactivate = $conn->prepare($sqlDeactivate)) {
                        $stmtDeactivate->bind_param("s", $livro);
                        if (!$stmtDeactivate->execute()) {
                            throw new Exception("Error deactivating book: " . $stmtDeactivate->error);
                        }
                        $stmtDeactivate->close();
                    } else {
                        throw new Exception("Error preparing deactivate query: " . $conn->error);
                    }
                }
    
                $stmtCheck->close();
            } else {
                throw new Exception("Error preparing check query: " . $conn->error);
            }
    
            // Prepare the SQL query to insert the loan
            $sqlInsert = "INSERT INTO emprestimolivro (codEmprestimo, ISBNLivro) VALUES (?, ?)";
            if ($stmtInsert = $conn->prepare($sqlInsert)) {
                $stmtInsert->bind_param("ss", $cod, $livro);
                if ($stmtInsert->execute()) {
                    $msg = "Registered successfully!";
                } else {
                    throw new Exception("Error registering loan: " . $stmtInsert->error);
                }
                $stmtInsert->close();
            } else {
                throw new Exception("Error preparing insert query: " . $conn->error);
            }
    
            // Commit the transaction
            $conn->commit();
        } catch (Exception $e) {
            // Rollback the transaction in case of an error
            $conn->rollback();
            $flag = false;
            $msg = $e->getMessage();
        }
    
        // Close the database connection
        $conn->close();
    
        // Create the JSON response
        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );
    
        return $resp;
    }

    function getListaEmprestimos() {

        global $conn;
        $msg = "";

        $sql = "SELECT emprestimo.*, funcionario.nome AS nomeFuncionario, socio.nome AS nomeSocio FROM emprestimo, funcionario, socio WHERE emprestimo.nifSocio = socio.nif AND emprestimo.nifFuncionario = funcionario.nif";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>".$row['cod']."</th>";
                $msg .= "<td>".$row['dataRegisto']."</td>";
                $msg .= "<td>".$row['dataPrevistaDevolucao']."</td>";
                $msg .= "<td>".$row['nomeFuncionario']."</td>";
                $msg .= "<td>".$row['nomeSocio']."</td>";
                $msg .= "<td><button class='btn btn-danger' onclick ='deleteFuncionario(".$row['cod'].")'><i class='fa fa-trash'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>No Records</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function getLivrosAssociados($codEmprestimo) {
        global $conn;
        $msg = [];
        
        // SQL query para obter os livros associados ao código do empréstimo
        $sql = "SELECT livro.titulo, livro.ISBN 
                FROM emprestimolivro 
                INNER JOIN livro ON livro.ISBN = emprestimolivro.ISBNLivro 
                WHERE emprestimolivro.codEmprestimo = ?";
    
        // Prepare a declaração
        if ($stmt = $conn->prepare($sql)) {
            // Vincule o parâmetro
            $stmt->bind_param("s", $codEmprestimo); // Supondo que codEmprestimo seja uma string
            
            // Execute a declaração
            $stmt->execute();
            
            // Obtenha o resultado
            $result = $stmt->get_result();
            
            // Armazene os títulos e ISBNs dos livros em um array
            while ($row = $result->fetch_assoc()) {
                $msg[] = [
                    "titulo" => $row['titulo'],
                    "ISBN" => $row['ISBN']
                ]; // Armazenar o título e o ISBN
            }
    
            // Fechar a declaração
            $stmt->close();
        } else {
            $msg = ["error" => "Erro ao preparar a consulta: " . $conn->error];
        }
    
        // Fechar a conexão
        $conn->close();
    
        // Retornar os dados como JSON
        return json_encode(["livros" => $msg]);
    }

    function registaDevolucao1($codEmprestimo, $ISBNLivro) {
        global $conn;
        $msg = "";
        $flag = true;
    
        // Iniciar uma transação
        $conn->begin_transaction();
    
        try {
            // Verifique se $ISBNLivro é uma string
            if (empty($ISBNLivro)) {
                throw new Exception("ISBN do livro não pode ser vazio.");
            }
    
            // Atualizar a quantidade do livro
            $sqlUpdateQuantidade = "UPDATE livro SET quantidade = quantidade + 1 WHERE ISBN = ?";
            if ($stmt = $conn->prepare($sqlUpdateQuantidade)) {
                $stmt->bind_param("s", $ISBNLivro);
                if (!$stmt->execute()) {
                    throw new Exception("Erro ao atualizar a quantidade do livro: " . $stmt->error);
                }
                $stmt->close();
            } else {
                throw new Exception("Erro ao preparar a consulta de atualização: " . $conn->error);
            }
    
            // Atualizar o estado do empréstimo se necessário
            $sqlUpdateEmprestimo = "UPDATE emprestimo SET estado = 'Devolvido' WHERE cod = ?";
            if ($stmt = $conn->prepare($sqlUpdateEmprestimo)) {
                $stmt->bind_param("s", $codEmprestimo);
                if (!$stmt->execute()) {
                    throw new Exception("Erro ao atualizar o estado do empréstimo: " . $stmt->error);
                }
                $stmt->close();
            }
    
            // Commit da transação
            $conn->commit();
            $msg = "Devolução registrada com sucesso!";
        } catch (Exception $e) {
            // Rollback da transação em caso de erro
            $conn->rollback();
            $flag = false;
            $msg = $e->getMessage();
        }
    
        // Retornar a resposta
        return json_encode(["flag" => $flag, "msg" => $msg]);
    }

    function listagemEmprestimosAtrasados() {
        global $conn;
        $msg = "";
    
        // Get the current date in the format suitable for the database
        $currentDate = date('Y-m-d');
    
        // SQL query to select overdue loans
        $sql = "SELECT emprestimo.*, socio.nome AS nomeSocio 
                FROM emprestimo 
                JOIN socio ON emprestimo.nifSocio = socio.nif 
                WHERE emprestimo.dataPrevistaDevolucao < ?"; // Condition to check for overdue loans
    
        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            // Bind the current date to the prepared statement
            $stmt->bind_param("s", $currentDate);
    
            // Execute the statement
            $stmt->execute();
    
            // Get the result
            $result = $stmt->get_result();
    
            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    $msg .= "<tr>";
                    $msg .= "<th scope='row'>" . $row['cod'] . "</th>";
                    $msg .= "<td>" . $row['nomeSocio'] . "</td>";
                    $msg .= "</tr>";
                }
            } else {
                // No records found
                $msg .= "<tr>";
                $msg .= "<td colspan='2'>No Records</td>"; // Adjusted to span all columns
                $msg .= "</tr>";
            }
    
            // Close the statement
            $stmt->close();
        } else {
            // Handle error preparing the statement
            $msg .= "<tr><td colspan='2'>Error preparing statement: " . $conn->error . "</td></tr>";
        }
    
        // Close the database connection
        $conn->close();
    
        return $msg;
    }

    function deleteFuncionario($nif) {
        global $conn;
        $msg = "";
        $flag = true;
    
        // Defining the query with a prepared statement
        $sql = "DELETE FROM funcionario WHERE nif = ?";
        
        // Preparing the statement
        $stmt = $conn->prepare($sql);
    
        if ($stmt) {
            // Binding the parameter to the statement
            $stmt->bind_param("i", $nif);
    
            // Executing the statement
            if ($stmt->execute()) {
                $msg = "Removed successfully";
            } else {
                $flag = false;
                $msg = "Error removing the record: " . $stmt->error;
            }
    
            // Closing the statement
            $stmt->close();
        } else {
            $flag = false;
            $msg = "Error preparing the statement: " . $conn->error;
        }
    
        // Closing the connection
        $conn->close();
    
        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    function getDadosEmprestimo($emprestimoSelect) {
        global $conn;
        $msg = "";
        $row = "";

        $sql = "SELECT * FROM emprestimo WHERE cod =" . $emprestimoSelect;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    

    function guardaEdicaoEmprestimo($dataP, $oldCod) {
        global $conn;
        $msg = "";
        $flag = true;
        
        // Prepare the SQL statement
        $sql = "UPDATE emprestimo SET 
                dataPrevistaDevolucao = ? 
                WHERE cod = ?";
        
        // Prepare the statement
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            // Bind the parameters
            $stmt->bind_param("ss", $dataP, $oldCod);
            
            // Execute the statement
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $msg = "Actualization completed";
                } else {
                    $msg = "No rows updated. Check if the COD exists.";
                }
            } else {
                $flag = false;
                $msg = "Error executing update: " . $stmt->error;
            }
        
            // Closing the statement
            $stmt->close();
        } else {
            $flag = false;
            $msg = "Error preparing the statement: " . $conn->error;
        }
    
        // Closing the connection
        $conn->close();
    
        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    function getCodEmprestimo() {
        global $conn;
        $msg = "<option selected>Select a loan Type</option>";

        $sql = "SELECT * FROM emprestimo";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['cod'] . "'> Nif Sócio: " . $row['nifSocio'] . "</option>"; 
            }
        } else {
            $msg = "<option value='-1'>No loans registered</option>"; 
        }
        $conn->close();

        return ($msg);
    }

}
?>
