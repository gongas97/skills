<?php

require_once 'connection.php';

class Livro
{

    function registaLivro($ISBN, $tit, $dataL, $sinop, $edicao, $editora, $idioma, $nPaginas, $estado, $qtd)
{
    global $conn;
    $msg = "";
    $flag = true;

    // First, check if the ISBN already exists
    $sqlCheck = "SELECT ISBN FROM livro WHERE ISBN = ?";
    
    if ($stmtCheck = $conn->prepare($sqlCheck)) {
        
        // Bind the ISBN parameter
        $stmtCheck->bind_param("s", $ISBN);
        
        // Execute the query
        $stmtCheck->execute();
        
        // Store the result
        $stmtCheck->store_result();
        
        // Check if any record was found
        if ($stmtCheck->num_rows > 0) {
            $flag = false;
            $msg = "Error: A book with this ISBN is already registered.";
            $stmtCheck->close();
        } else {
            // Close the check statement
            $stmtCheck->close();

            // Prepare the SQL query to insert a new book
            $sql = "INSERT INTO livro (ISBN, titulo, dataLancamento, sinopse, edicao, editora, idioma, nPaginas, idEstado, quantidade) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            // Prepare the statement
            if ($stmt = $conn->prepare($sql)) {

                // Bind the parameters to the placeholders
                $stmt->bind_param("sssssssisi", $ISBN, $tit, $dataL, $sinop, $edicao, $editora, $idioma, $nPaginas, $estado, $qtd);

                // Execute the statement
                if ($stmt->execute()) {
                    $msg = "Registered successfully!";
                } else {
                    $flag = false;
                    $msg = "Error registering: " . $stmt->error;
                }

                // Close the statement
                $stmt->close();
            } else {
                $flag = false;
                $msg = "Error preparing the query: " . $conn->error;
            }
        }
    } else {
        $flag = false;
        $msg = "Error checking ISBN: " . $conn->error;
    }

    // Close the database connection
    $conn->close();

    // Create the JSON response
    $resp = json_encode(
        array(
            "flag" => $flag,
            "msg" => $msg
        )
    );

    return $resp;
}

    function registaEscritor($autor, $livro)
    {

        global $conn;
        $msg = "";
        $flag = true;

        // Prepare the SQL query with placeholders
        $sql = "INSERT INTO escritor (nifAutor, ISBNLivro) 
                VALUES (?, ?)";

        // Prepare the statement
        if ($stmt = $conn->prepare($sql)) {

            // Bind the parameters to the placeholders
            $stmt->bind_param("ss", $autor, $livro);

            // Execute the statement
            if ($stmt->execute()) {
                $msg = "Registered successfully!";
            } else {
                $flag = false;
                $msg = "Error registering: " . $stmt->error;
            }

            // Close the statement
            $stmt->close();

        } else {
            $flag = false;
            $msg = "Error preparing the query: " . $conn->error;
        }

        // Close the database connection
        $conn->close();

        // Create the JSON response
        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        return $resp;
    }

    function localizacaoLivro($estante, $livro)
    {

        global $conn;
        $msg = "";
        $flag = true;

        // Prepare the SQL query with placeholders
        $sql = "INSERT INTO localizacao (idEstante, ISBNLivro) 
                VALUES (?, ?)";

        // Prepare the statement
        if ($stmt = $conn->prepare($sql)) {

            // Bind the parameters to the placeholders
            $stmt->bind_param("ss", $estante, $livro);

            // Execute the statement
            if ($stmt->execute()) {
                $msg = "Registered successfully!";
            } else {
                $flag = false;
                $msg = "Error registering: " . $stmt->error;
            }

            // Close the statement
            $stmt->close();

        } else {
            $flag = false;
            $msg = "Error preparing the query: " . $conn->error;
        }

        // Close the database connection
        $conn->close();

        // Create the JSON response
        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        return $resp;
    }

    function getListagemLivros()
    {

        global $conn;
        $msg = "";

        $sql = "SELECT livro.*, estado.descricao FROM livro, estado WHERE livro.idEstado = estado.id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['titulo'] . "</th>";
                $msg .= "<td>" . $row['quantidade'] . "</td>";
                $msg .= "<td><button class='btn btn-success' onclick ='adicionarQuantidade(" . $row['ISBN'] . ")'>Adicionar Quantidade</button></td>";
                $msg .= "<td><button class='btn btn-success' onclick ='infoLivro(" . $row['ISBN'] . ")'>Informações</button></td>";
                $msg .= "<td><button class='btn btn-danger' onclick ='deleteLivro(" . $row['ISBN'] . ")'><i class='fa fa-trash'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>No Records</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function infoLivro($ISBN)
    {
        global $conn;
        $msg = "";

        // SQL query to select book details, including the author name and the year of the release date
        $sql = "SELECT livro.*, autor.nome, autor.nif, YEAR(livro.dataLancamento) AS ano 
                FROM livro 
                INNER JOIN escritor ON livro.ISBN = escritor.ISBNLivro 
                INNER JOIN autor ON escritor.nifAutor = autor.nif
                WHERE livro.ISBN = ?";

        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            // Bind the ISBN parameter to the prepared statement
            $stmt->bind_param("s", $ISBN);

            // Execute the prepared statement
            $stmt->execute();

            // Get the result of the query
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Process each row of the result set
                while ($row = $result->fetch_assoc()) {
                    $msg .= "<tr>";
                    $msg .= "<th scope='row'>" . $row['sinopse'] . "</th>";
                    $msg .= "<td>" . $row['ano'] . "</td>";  // Display only the year
                    $msg .= "<td>" . $row['edicao'] . "</td>";
                    $msg .= "<td><a href='#' onclick='showAuthorInfo(\"" . $row['nif'] . "\")'>" . $row['nome'] . "</a></td>";
                    $msg .= "<td>" . $row['titulo'] . "</td>";
                    $msg .= "</tr>";
                }
            } else {
                // No records found
                $msg .= "<tr>";
                $msg .= "<td colspan='5'>No Records</td>";
                $msg .= "</tr>";
            }

            // Close the statement
            $stmt->close();
        } else {
            // Error preparing the statement
            $msg = "Error preparing the statement: " . $conn->error;
        }

        // Close the database connection
        $conn->close();

        return $msg;
    }

    function getAuthorInfo($nif)
    {
        global $conn;
        $msg = "";

        // SQL query to fetch author details based on NIF
        $sql = "SELECT * FROM autor WHERE nif = ?";

        // Prepare and execute the query
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("s", $nif);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Display author details
                $row = $result->fetch_assoc();
                $msg .= "<th scope='row'>" . $row['nif'] . "</th>";
                $msg .= "<td>" . $row['nome'] . "</td>";
                $msg .= "<td>" . $row['dataNascimento'] . "</td>";
                $msg .= "<td>" . $row['biografia'] . "</td>";
                $msg .= "<td>" . $row['info'] . "</td>";
                $msg .= "<td>" . $row['facebook'] . "</td>";
                $msg .= "<td>" . $row['instagram'] . "</td>";
                $msg .= "<td>" . $row['X'] . "</td>";
            } else {
                $msg .= "No author information found.";
            }

            $stmt->close();
        } else {
            $msg = "Error preparing the statement: " . $conn->error;
        }

        return $msg;
    }

    function adicionarQuantidadeLivro($ISBN, $quantidadeAdicionada)
    {
        global $conn;
        $msg = "";

        // Seleciona a quantidade atual do livro
        $sql = "SELECT quantidade FROM livro WHERE ISBN = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $ISBN);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $quantidadeAtual = $row['quantidade'];
            $novaQuantidade = $quantidadeAtual + $quantidadeAdicionada;

            // Atualiza a quantidade no banco de dados
            $sqlUpdate = "UPDATE livro SET quantidade = ? WHERE ISBN = ?";
            $stmtUpdate = $conn->prepare($sqlUpdate);
            $stmtUpdate->bind_param("is", $novaQuantidade, $ISBN);

            if ($stmtUpdate->execute()) {
                $msg = "Quantidade atualizada com sucesso.";
            } else {
                $msg = "Erro ao atualizar a quantidade.";
            }
        } else {
            $msg = "Livro não encontrado.";
        }

        $stmt->close();
        $conn->close();

        return $msg;
    }

    function deleteLivro($ISBN)
    {
        global $conn;
        $msg = "";
        $flag = true;

        // Defining the query with a prepared statement
        $sql = "DELETE FROM livro WHERE ISBN = ?";

        // Preparing the statement
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            // Binding the parameter to the statement
            $stmt->bind_param("i", $ISBN);

            // Executing the statement
            if ($stmt->execute()) {
                $msg = "Removed successfully";
            } else {
                $flag = false;
                $msg = "Error removing the record: " . $stmt->error;
            }

            // Closing the statement
            $stmt->close();
        } else {
            $flag = false;
            $msg = "Error preparing the statement: " . $conn->error;
        }

        // Closing the connection
        $conn->close();

        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    function getDadoslivros($livroSelect2)
    {
        global $conn;
        $msg = "";
        $row = "";

        $sql = "SELECT * FROM livro WHERE ISBN =" . $livroSelect2;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function guardaEdicaolivro($isbn, $tit, $data, $sinop, $edicao, $editora, $idioma, $nPaginas, $estado, $oldISBN)
    {
        global $conn;
        $msg = "";
        $flag = true;

        // Prepare the SQL statement
        $sql = "UPDATE livro SET 
                ISBN = ?, 
                titulo = ?, 
                dataLancamento = ?, 
                sinopse = ?, 
                edicao = ?, 
                editora = ?, 
                idioma = ?,
                nPaginas = ?,  
                idEstado = ? 
                WHERE ISBN = ?";

        // Prepare the statement
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            // Bind the parameters
            $stmt->bind_param("issssisisi", $isbn, $tit, $data, $sinop, $edicao, $editora, $idioma, $nPaginas, $estado ,$oldISBN);

            // Execute the statement
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $msg = "Editing completed";
                } else {
                    $msg = "No rows updated. Check if the ISBN exists.";
                }
            } else {
                $flag = false;
                $msg = "Error executing update: " . $stmt->error;
            }

            // Closing the statement
            $stmt->close();
        } else {
            $flag = false;
            $msg = "Error preparing the statement: " . $conn->error;
        }

        // Closing the connection
        $conn->close();

        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    function getDadosLocalizacao($livroSelect)
    {
        global $conn;
        $msg = "";
        $row = "";

        $sql = "SELECT * FROM localizacao WHERE ISBNLivro =" . $livroSelect;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function moverLivro($estante, $oldId)
    {
        global $conn;
        $msg = "";
        $flag = true;

        // Prepare the SQL statement
        $sql = "UPDATE localizacao SET 
                idEstante = ?
                WHERE id = ?";

        // Prepare the statement
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            // Bind the parameters
            $stmt->bind_param("is", $estante, $oldId);

            // Execute the statement
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $msg = "Editing completed";
                } else {
                    $msg = "No rows updated. Check if the ID exists.";
                }
            } else {
                $flag = false;
                $msg = "Error executing update: " . $stmt->error;
            }

            // Closing the statement
            $stmt->close();
        } else {
            $flag = false;
            $msg = "Error preparing the statement: " . $conn->error;
        }

        // Closing the connection
        $conn->close();

        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    function getEstado()
    {
        global $conn;
        $msg = "<option selected>Select a State Type</option>";

        $sql = "SELECT * FROM estado";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>No State Types registered</option>";
        }
        $conn->close();

        return ($msg);
    }

    function getLivro()
    {
        global $conn;
        $msg = "<option selected>Select an Book</option>";

        $sql = "SELECT * FROM livro";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['ISBN'] . "'>" . $row['titulo'] . " - " . $row['edicao'] . " Edição</option>";
            }
        } else {
            $msg = "<option value='-1'>No Books registered</option>";
        }
        $conn->close();

        return ($msg);
    }

    function getAutores()
    {
        global $conn;
        $msg = "<option selected>Select an author</option>";

        $sql = "SELECT * FROM autor";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['nif'] . "'>" . $row['nome'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>No authors registered</option>";
        }
        $conn->close();

        return ($msg);
    }

    function getEstantes()
    {
        global $conn;
        $msg = "<option selected>Select an localization</option>";

        $sql = "SELECT * FROM estante";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>No localization registered</option>";
        }
        $conn->close();

        return ($msg);
    }
}
?>