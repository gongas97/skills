<?php

require_once 'connection.php';

class Estante {
    function getListaEstantes() {

        global $conn;
        $msg = "";
    
        // Using LEFT JOIN to get records even if seccao.descricao is NULL
        $sql = "SELECT estante.*, seccao.descricao AS descricaoSeccao 
                FROM estante 
                LEFT JOIN seccao ON estante.codseccao = seccao.cod";
        
        $result = $conn->query($sql);
    
        if ($result->num_rows > 0) {
            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>".$row['id']."</th>";
                $msg .= "<td>".$row['descricao']."</td>";
                $msg .= "<td>".($row['descricaoSeccao'] !== null ? $row['descricaoSeccao'] : "No Section")."</td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>No Records</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        
        $conn->close();
    
        return ($msg);
    }
}
?>