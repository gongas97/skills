<?php

require_once 'connection.php';

class Card {

    function card1() {
        global $conn;
        $count = 0;
        
        // SQL to count rows in emprestimolivro
        $sql = "SELECT COUNT(*) as total FROM emprestimolivro";
        
        // Execute the query
        if ($result = $conn->query($sql)) {
            // Fetch the result
            $row = $result->fetch_assoc();
            $count = $row['total']; // Get the count
        } else {
            // If there's an error, return 0
            return "Error: " . $conn->error;
        }

        // Close the connection
        $conn->close();

        // Return the count as a number
        return $count;
    }

    function card2() {
        global $conn;
        $count = 0;

        // SQL para contar sócios com idEstado == 'ativo'
        $sql = "SELECT COUNT(*) as total FROM socio WHERE idAtividade = 1";

        // Executar a query
        if ($result = $conn->query($sql)) {
            $row = $result->fetch_assoc();
            $count = $row['total']; // Obter a contagem
        } else {
            return "Error: " . $conn->error;
        }

        return $count;
    }

    function card3() {
        global $conn;
        $count = 0;

        // SQL para contar livros na tabela livro
        $sql = "SELECT COUNT(*) as total FROM livro";

        // Executar a query
        if ($result = $conn->query($sql)) {
            $row = $result->fetch_assoc();
            $count = $row['total']; // Obter a contagem
        } else {
            return "Error: " . $conn->error;
        }

        return $count;
    }
    
    function card4() {
        global $conn;
        $count = 0;

        // SQL para contar registros da tabela emprestimo com dataRegisto entre hoje e os últimos 7 dias
        $sql = "SELECT COUNT(*) as total FROM emprestimo 
                WHERE dataRegisto >= CURDATE() - INTERVAL 7 DAY AND dataRegisto <= CURDATE()";

        // Executar a query
        if ($result = $conn->query($sql)) {
            $row = $result->fetch_assoc();
            $count = $row['total'];
        } else {
            return "Error: " . $conn->error;
        }

        return $count;
    }

    function card5() {
        global $conn;
        $socio = "";
        $count = 0;

        // SQL para encontrar o sócio com mais empréstimos
        $sql = "SELECT socio.nome, COUNT(emprestimo.nifSocio) as total 
                FROM emprestimo 
                INNER JOIN socio ON emprestimo.nifSocio = socio.nif
                GROUP BY emprestimo.nifSocio
                ORDER BY total DESC
                LIMIT 1";  // Em caso de empate, retorna o primeiro socio com mais empréstimos

        if ($result = $conn->query($sql)) {
            if ($row = $result->fetch_assoc()) {
                $socio = $row['nome'];
                $count = $row['total'];
            }
        } else {
            return "Error: " . $conn->error;
        }

        return json_encode(array("nome" => $socio, "total" => $count));
    }
}
?>