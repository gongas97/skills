<?php

require_once 'connection.php';


class Login{

    function login($pw) {

        global $conn;
        $msg = "";
        $flag = true;
        session_start();
    
        // Prepare the SQL statement to check the password
        $stmt = $conn->prepare("SELECT * FROM funcionario WHERE pw = ?");
        
        // Bind the plain password to the statement (assuming the password in DB is plain text)
        $stmt->bind_param("s", $pw);
        
        // Execute the statement
        $stmt->execute();
    
        // Get the result of the query
        $result = $stmt->get_result();
    
        // Check if a row was found
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
    
            // Check if the user has the correct type
            if ($row['idTipoUtilizador'] == 1) {
                $msg = "Bem-vindo " . $row['nome'];
                $_SESSION['funcionario'] = $row['nome'];  // Store user info in session
            } else {
                $flag = false;
                $msg = "Erro! Acesso negado. Você não tem permissão para acessar esta área.";
            }
            
        } else {
            $flag = false;
            $msg = "Erro! Dados inválidos";
        }
    
        // Close the statement and connection
        $stmt->close();
        $conn->close();
    
        // Return the result as a JSON response
        return json_encode(array(
            "msg" => $msg,
            "flag" => $flag
        ));
    }
    function logout(){

        session_start();
        session_destroy();

        return("Obrigado!");
    }

}


?>