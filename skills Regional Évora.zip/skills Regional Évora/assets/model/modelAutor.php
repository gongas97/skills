<?php

require_once 'connection.php';

class Autor {

    function registaAutor($nif, $nome, $dataNasc, $bio, $info, $face, $inst, $x) {

        global $conn;
        $msg = "";
        $flag = true;
    
        // Prepare the SQL query with placeholders
        $sql = "INSERT INTO autor (nif, nome, dataNascimento, biografia, info, facebook, instagram, X) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
        // Prepare the statement
        if ($stmt = $conn->prepare($sql)) {
            
            // Bind the parameters to the placeholders
            $stmt->bind_param("ssssssss", $nif, $nome, $dataNasc, $bio, $info, $face, $inst, $x);
    
            // Execute the statement
            if ($stmt->execute()) {
                $msg = "Registered successfully!";
            } else {
                $flag = false;
                $msg = "Error registering: " . $stmt->error;
            }
    
            // Close the statement
            $stmt->close();
            
        } else {
            $flag = false;
            $msg = "Error preparing the query: " . $conn->error;
        }
    
        // Close the database connection
        $conn->close();
    
        // Create the JSON response
        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );
    
        return $resp;
    }

    function getListaAutores() {

        global $conn;
        $msg = "";

        $sql = "SELECT autor.* FROM autor";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>".$row['nif']."</th>";
                $msg .= "<th scope='row'>".$row['nome']."</th>";
                $msg .= "<td><button class='btn btn-danger' onclick ='deleteAutor(".$row['nif'].")'><i class='fa fa-trash'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>No Records</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function deleteAutor($nif) {
        global $conn;
        $msg = "";
        $flag = true;
    
        // Defining the query with a prepared statement
        $sql = "DELETE FROM autor WHERE nif = ?";
        
        // Preparing the statement
        $stmt = $conn->prepare($sql);
    
        if ($stmt) {
            // Binding the parameter to the statement
            $stmt->bind_param("i", $nif);
    
            // Executing the statement
            if ($stmt->execute()) {
                $msg = "Removed successfully";
            } else {
                $flag = false;
                $msg = "Error removing the record: " . $stmt->error;
            }
    
            // Closing the statement
            $stmt->close();
        } else {
            $flag = false;
            $msg = "Error preparing the statement: " . $conn->error;
        }
    
        // Closing the connection
        $conn->close();
    
        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    function getDadosAutor($autorSelect) {
        global $conn;
        $msg = "";
        $row = "";

        $sql = "SELECT * FROM autor WHERE nif =" . $autorSelect;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));
    }

    function guardaEdicaoAutor($nif, $nome, $dataNascimento, $biografia, $info, $facebook, $instagram, $X, $oldNif) {
        global $conn;
        $msg = "";
        $flag = true;
        
        // Prepare the SQL statement
        $sql = "UPDATE autor SET 
                nif = ?, 
                nome = ?, 
                dataNascimento = ?, 
                biografia = ?, 
                info = ?, 
                facebook = ?, 
                instagram = ?, 
                X = ? 
                WHERE nif = ?";
        
        // Prepare the statement
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            // Bind the parameters
            $stmt->bind_param("isssssssi", $nif, $nome, $dataNascimento, $biografia, $info, $facebook, $instagram, $X, $oldNif);
            
            // Execute the statement
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $msg = "Editing completed";
                } else {
                    $msg = "No rows updated. Check if the NIF exists.";
                }
            } else {
                $flag = false;
                $msg = "Error executing update: " . $stmt->error;
            }
        
            // Closing the statement
            $stmt->close();
        } else {
            $flag = false;
            $msg = "Error preparing the statement: " . $conn->error;
        }
    
        // Closing the connection
        $conn->close();
    
        return json_encode(array("flag" => $flag, "msg" => $msg));
    }

    function getTipoUtilizador() {
        global $conn;
        $msg = "<option selected>Select a Employee Type</option>";

        $sql = "SELECT * FROM tipoutilizador";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>"; 
            }
        } else {
            $msg = "<option value='-1'>No Employee Types registered</option>"; 
        }
        $conn->close();

        return ($msg);
    }

    function getFuncionario() {
        global $conn;
        $msg = "<option selected>Select an Employee</option>";

        $sql = "SELECT * FROM funcionario";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['nif'] . "'>" . $row['nome'] . " - " . $row['numeroF'] . "</option>"; 
            }
        } else {
            $msg = "<option value='-1'>No Employees registered</option>"; 
        }
        $conn->close();

        return ($msg);
    }
}
?>
