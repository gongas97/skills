<?php

require_once 'connection.php';

class Seccao {
function getListaSeccoes() {

        global $conn;
        $msg = "";

        $sql = "SELECT seccao.* FROM seccao";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>".$row['cod']."</th>";
                $msg .= "<td>".$row['descricao']."</td>";
                $msg .= "<td><button class='btn btn-danger' onclick ='deleteSeccao(".$row['cod'].")'><i class='fa fa-trash'></i></button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>No Records</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function deleteSeccao($cod) {
    global $conn;
    $msg = "";
    $flag = true;

    // Start transaction
    $conn->begin_transaction();

    try {
        // Set `codSeccao` to NULL where the section is referenced
        $sqlUpdate = "UPDATE estante SET codSeccao = NULL WHERE codSeccao = ?";
        $stmtUpdate = $conn->prepare($sqlUpdate);
        
        if ($stmtUpdate) {
            $stmtUpdate->bind_param("i", $cod);
            $stmtUpdate->execute();
            $stmtUpdate->close();
        } else {
            throw new Exception("Error preparing update statement: " . $conn->error);
        }

        // Defining the DELETE query with a prepared statement
        $sqlDelete = "DELETE FROM seccao WHERE cod = ?";
        $stmtDelete = $conn->prepare($sqlDelete);
    
        if ($stmtDelete) {
            // Binding the parameter to the statement
            $stmtDelete->bind_param("i", $cod);
    
            // Executing the DELETE statement
            if ($stmtDelete->execute()) {
                $msg = "Removed successfully";
            } else {
                throw new Exception("Error removing the record: " . $stmtDelete->error);
            }
    
            // Closing the DELETE statement
            $stmtDelete->close();
        } else {
            throw new Exception("Error preparing delete statement: " . $conn->error);
        }

        // Commit the transaction
        $conn->commit();
    } catch (Exception $e) {
        // Rollback in case of error
        $conn->rollback();
        $flag = false;
        $msg = $e->getMessage();
    }

    // Closing the connection
    $conn->close();

    return json_encode(array("flag" => $flag, "msg" => $msg));
}
}
?>