<?php

require_once '../model/modelSeccao.php';

$sec = new Seccao();

if($_POST['op'] == 2){
    $resp = $sec -> getListaSeccoes();
    echo($resp);

}else if($_POST['op'] == 1){
    $resp = $sec->deleteSeccao($_POST['cod']);
    echo($resp);
}

?>