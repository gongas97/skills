<?php

require_once '../model/modelSocio.php';

$soc = new Socio();

if($_POST['op'] == 1){
    $resp = $soc -> registaSocio(
        $_POST['nif'],
        $_POST['nome'],
        $_POST['num'],
        $_POST['morada'],
        $_POST['email'],
        $_POST['tel'],
        $_POST['dataN'],
        $_POST['atividade']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $soc -> getListaSocio();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $soc -> getAtividade();
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $soc -> getDadosSocio($_POST['socioSelect']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $soc->guardaEdicaoSocio(
        $_POST['atividade'], 
        $_POST['oldNif']
    );
    echo($resp);
}else if($_POST['op'] == 6){
    $resp = $soc -> getSocio();
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $soc->deleteSocio($_POST['nif']);
    echo($resp);
}else if($_POST['op'] == 8){
    $resp = $soc -> getAutores();
    echo($resp);

}else if($_POST['op'] == 9){
    $resp = $soc -> getEstantes();
    echo($resp);

}else if($_POST['op'] == 20){
    $resp = $soc -> getListaSocioInativos();
    echo($resp);

}else if($_POST['op'] == 44){
    $resp = $soc -> getDados1($_POST['socioSelect2']);
    echo($resp);

}else if($_POST['op'] == 55){
    $resp = $soc->guardaEdicao1(
        $_POST['nif'], 
        $_POST['nome'], 
        $_POST['numeroSocio'], 
        $_POST['morada'],
        $_POST['email'], 
        $_POST['telefone'], 
        $_POST['dataNascimento'], 
        $_POST['oldNif']
    );
    echo($resp);
}

?>