<?php

require_once '../model/modelAutor.php';

$aut = new Autor();

if($_POST['op'] == 1){
    $resp = $aut -> registaAutor(
        $_POST['nif'],
        $_POST['nome'],
        $_POST['dataNasc'],
        $_POST['bio'],
        $_POST['info'],
        $_POST['face'],
        $_POST['inst'],
        $_POST['x']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $aut -> getListaAutores();
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $aut -> getDadosAutor($_POST['autorSelect']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $aut->guardaEdicaoAutor(
        $_POST['nif'], 
        $_POST['nome'], 
        $_POST['dataNascimento'], 
        $_POST['biografia'],
        $_POST['info'], 
        $_POST['facebook'], 
        $_POST['instagram'], 
        $_POST['X'], 
        $_POST['oldNif']
    );
    echo($resp);
}else if($_POST['op'] == 7){
    $resp = $aut->deleteAutor($_POST['nif']);
    echo($resp);
}

?>