<?php

require_once '../model/modelFuncionario.php';

$func = new Funcionario();

if($_POST['op'] == 1){
    $resp = $func -> registarFuncionario(
        $_POST['nif'],
        $_POST['nome'],
        $_POST['morada'],
        $_POST['tel'],
        $_POST['email'],
        $_POST['num'],
        $_POST['dataNac'],
        $_POST['tipo'],
        $_POST['pw']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $func -> getListaFuncionarios();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $func -> getTipoUtilizador();
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $func -> getDadosFuncionario($_POST['funcionarioSelect']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $func->guardaEdicaoFuncionario(
        $_POST['nif'], 
        $_POST['nome'], 
        $_POST['morada'], 
        $_POST['tel'],
        $_POST['email'], 
        $_POST['numF'], 
        $_POST['data'], 
        $_POST['tipo'], 
        $_POST['oldNif']
    );
    echo($resp);
}else if($_POST['op'] == 6){
    $resp = $func -> getFuncionario();
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $func->deleteFuncionario($_POST['nif']);
    echo($resp);
}

?>