<?php

require_once '../model/modelLivro.php';

$liv = new Livro();

if($_POST['op'] == 1){
    $resp = $liv -> registaLivro(
        $_POST['ISBN'],
        $_POST['tit'],
        $_POST['dataL'],
        $_POST['sinop'],
        $_POST['edicao'],
        $_POST['editora'],
        $_POST['idioma'],
        $_POST['nPaginas'],
        $_POST['estado'],
        $_POST['qtd']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $liv -> getListagemLivros();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $liv -> getEstado();
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $liv -> getDadoslivros($_POST['livroSelect2']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $liv->guardaEdicaolivro(
        $_POST['isbn'], 
        $_POST['tit'], 
        $_POST['data'], 
        $_POST['sinop'],
        $_POST['edicao'], 
        $_POST['editora'], 
        $_POST['idioma'], 
        $_POST['nPaginas'],
        $_POST['estado'],  
        $_POST['oldISBN']
    );
    echo($resp);
}else if($_POST['op'] == 6){
    $resp = $liv -> getLivro();
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $liv->deleteLivro($_POST['ISBN']);
    echo($resp);
}else if($_POST['op'] == 8){
    $resp = $liv -> getAutores();
    echo($resp);

}else if($_POST['op'] == 9){
    $resp = $liv -> getEstantes();
    echo($resp);

}else if($_POST['op'] == 10){
    $resp = $liv->registaEscritor(
        $_POST['autor'], 
        $_POST['livro']
    );
    echo($resp);
}else if($_POST['op'] == 11){
    $resp = $liv->localizacaoLivro(
        $_POST['estante'], 
        $_POST['livro']
    );
    echo($resp);
}else if($_POST['op'] == 12){
    $resp = $liv -> getDadosLocalizacao($_POST['livroSelect']);
    echo($resp);

}else if($_POST['op'] == 13){
    $resp = $liv->moverLivro(
        $_POST['estante'], 
        $_POST['oldId']
    );
    echo($resp);
}else if($_POST['op'] == 14){
    $resp = $liv->infoLivro($_POST['ISBN']);
    echo($resp);
}else if($_POST['op'] == 15) {
    $resp = $liv->adicionarQuantidadeLivro(
        $_POST['ISBN'], 
        $_POST['quantidadeAdicionada']
    );
    echo($resp);
}if ($_POST['op'] == 16) {
    $resp = $liv->getAuthorInfo($_POST['nif']);
    echo($resp);
}

?>