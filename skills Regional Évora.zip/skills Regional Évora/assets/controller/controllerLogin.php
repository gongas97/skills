<?php

include_once "../model/modelLogin.php";

$log = new Login();

if($_POST['op'] == 1){
    $resp = $log -> login($_POST['password']);
    echo($resp);
}else if($_POST['op'] == 3){
    $resp = $log -> logout();
    echo($resp);
}


?>