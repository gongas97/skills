<?php

require_once '../model/modelEstante.php';

$est = new Estante();

if($_POST['op'] == 2){
    $resp = $est -> getListaEstantes();
    echo($resp);

}

?>