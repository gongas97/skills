<?php

require_once '../model/modelEmprestimo.php';

$emp = new Emprestimo();

if($_POST['op'] == 1){
    $resp = $emp -> registarEmprestimo(
        $_POST['dataR'],
        $_POST['dataD'],
        $_POST['socio'],
        $_POST['colaborador']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $emp -> getListaEmprestimos();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $emp -> getCodEmprestimo();
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $emp -> getDadosEmprestimo($_POST['emprestimoSelect']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $emp->guardaEdicaoEmprestimo(
        $_POST['dataP'], 
        $_POST['oldCod']
    );
    echo($resp);
}else if($_POST['op'] == 7){
    $resp = $emp -> registarLivrosEmprestimo(
        $_POST['cod'],
        $_POST['livro']
    );
    echo ($resp);

}else if($_POST['op'] == 21){
    $resp = $emp -> listagemEmprestimosAtrasados();
    echo($resp);

}else if ($_POST['op'] == 44) {
    // Verifique se o código do empréstimo foi enviado
    if (isset($_POST['codEmprestimo'])) {
        $codEmprestimo = $_POST['codEmprestimo'];

        // Chame a função para obter os livros associados
        $resp = $emp->getLivrosAssociados($codEmprestimo);
        echo($resp);
    } else {
        echo json_encode(["flag" => false, "msg" => "Código do empréstimo não fornecido."]);
    }
}else if ($_POST['op'] == 55) {
    $resp = $emp->registaDevolucao1(
        $_POST['codEmprestimo'],
        $_POST['ISBNLivro'] // deve ser apenas um único ISBN
    );
    echo($resp);
}

?>