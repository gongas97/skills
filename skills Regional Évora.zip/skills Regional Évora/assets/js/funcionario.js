function registaFuncionario() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("nif", $('#nifFuncionario').val());
    dados.append("nome", $('#nomeFuncionario').val());
    dados.append("morada", $('#moradaFuncionario').val());
    dados.append("tel", $('#telFuncionario').val());
    dados.append("email", $('#emailFuncionario').val());
    dados.append("num", $('#numFuncionario').val());
    dados.append("dataNac", $('#dataNascimentoFuncionario').val());
    dados.append("tipo", $('#tipoFuncionario').val());
    dados.append("pw", $('#pw').val());

    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Funcionário/a", obj.msg, "success");
                getListaFuncionario();
                getFuncionarios();
            } else {
                alerta("Funcionário/a", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getListaFuncionario(){

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {

        $('#listagemFuncionarios').html(msg);
        
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function deleteFuncionario(nif) {
    let dados = new FormData();
    dados.append('nif', nif); 
    dados.append('op', 7);

    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {

        let obj = JSON.parse(msg);
        if (obj.flag) {
            alerta("Funcionário/a", obj.msg, "success");
            getListaFuncionario();
        } else {
            alerta("Funcionário/a", obj.msg, "error");
        }

    })
    .fail(function(jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

function getTipo(){

    let dados = new FormData();
    dados.append("op", 3);


    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {
        $('#tipoFuncionario').html(msg); 
        $('#tipoFuncionarioEdit').html(msg); 
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function getFuncionarios(){

    let dados = new FormData();
    dados.append("op", 6);


    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {
        $('#listaFuncioanrios').html(msg); 
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function filtrarTabela() {
    let funcionarioSelect = $('#listaFuncioanrios').val();
    let dados = new FormData();
    dados.append('funcionarioSelect', funcionarioSelect);
    dados.append('op', 4);
  
    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
      method: "POST",
      data: dados,
      dataType: "html",
      cache: false,
      contentType: false,
      processData: false,
    })
    .done(function(msg) {
        let obj = JSON.parse(msg);
        $('#nifFuncionarioEdit').val(obj.nif);
        $('#nomeFuncionarioEdit').val(obj.nome);
        $('#moradaFuncionarioEdit').val(obj.morada);
        $('#telFuncionarioEdit').val(obj.telefone);
        $('#emailFuncionarioEdit').val(obj.email);
        $('#numFuncionarioEdit').val(obj.numeroF);
        $('#dataNascimentoFuncionarioEdit').val(obj.dataNascimento);
        $('#tipoFuncionarioEdit').val(obj.idTipoUtilizador);
     
        $('#btnGuardaEdit').attr('onclick', 'guardaDadosFuncionario('+obj.nif+')')
    })
    .fail(function(jqXHR, textStatus) {
      alert("Request failed: " + textStatus);
    });
  }
  
  $('#listaFuncioanrios').change(filtrarTabela);

  function guardaDadosFuncionario(funcionarioSelect){
  
    let dados = new FormData();
    dados.append('nif', $('#nifFuncionarioEdit').val());
    dados.append('nome', $('#nomeFuncionarioEdit').val());
    dados.append('morada', $('#moradaFuncionarioEdit').val());
    dados.append('tel', $('#telFuncionarioEdit').val());
    dados.append('email', $('#emailFuncionarioEdit').val());
    dados.append('numF', $('#numFuncionarioEdit').val());
    dados.append('data', $('#dataNascimentoFuncionarioEdit').val());
    dados.append('tipo', $('#tipoFuncionarioEdit').val());
    dados.append('oldNif', funcionarioSelect);
    dados.append('op', 5);
  
   
    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
      method: "POST",
      data: dados,
      dataType: "html",
      cache: false,
      contentType: false,
      processData:false,
    })
    
    .done(function (msg) {

        let obj = JSON.parse(msg);
        if (obj.flag) {
            alerta("Funcionário/a", obj.msg, "success");
            getListaFuncionario();
        } else {
            alerta("Funcionário/a", obj.msg, "error");
        }

    })
    
    .fail(function( jqXHR, textStatus ) {
      alert( "Request failed: " + textStatus );
    });
  
  }

  function enableEditButton() {
    // Remove o atributo 'disabled' do botão de edição
    document.getElementById('nifFuncionarioEdit').disabled = false;
}

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,
        
    })
}

$(function () {
    getTipo();
    getFuncionarios();
    getListaFuncionario();
});