function registarSocio() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("nif", $('#nifSocio').val());
    dados.append("nome", $('#nomeSocio').val());
    dados.append("num", $('#numSocio').val());
    dados.append("morada", $('#moradaSocio').val());
    dados.append("email", $('#emailSocio').val());
    dados.append("tel", $('#telSocio').val());
    dados.append("dataN", $('#datNSocio').val());
    dados.append("atividade", $('#atividadeSocio').val());

    $.ajax({
        url: "assets/controller/controllerSocio.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Sócio/a", obj.msg, "success");
                getListaSocios();
            } else {
                alerta("Sócio/a", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getListaSocios() {

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerSocio.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemSocios').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getListaSociosInativos() {

    let dados = new FormData();
    dados.append("op", 20);


    $.ajax({
        url: "assets/controller/controllerSocio.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemSociosInativos').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getListaEmprestimosAtraso() {

    let dados = new FormData();
    dados.append("op", 21);


    $.ajax({
        url: "assets/controller/controllerEmprestimo.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemEmprestimosAtrasados').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function deleteSocio(nif) {
    let dados = new FormData();
    dados.append('nif', nif);
    dados.append('op', 7);

    $.ajax({
        url: "assets/controller/controllerSocio.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Sócio/a", obj.msg, "success");
                getListaSocios();
            } else {
                alerta("Sócio/a", obj.msg, "error");
            }

        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getAtividades() {

    let dados = new FormData();
    dados.append("op", 3);


    $.ajax({
        url: "assets/controller/controllerSocio.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#atividadeSocio').html(msg);
            $('#atividadeEdit').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getLivros() {

    let dados = new FormData();
    dados.append("op", 6);


    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#listaLivros').html(msg);
            $('#listaLivros2').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getSocio() {

    let dados = new FormData();
    dados.append("op", 6);


    $.ajax({
        url: "assets/controller/controllerSocio.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#listaSocios2').html(msg);
            $('#listaSocios4').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function filtrarTabela() {
    let socioSelect = $('#listaSocios4').val();
    let dados = new FormData();
    dados.append('socioSelect', socioSelect);
    dados.append('op', 4);

    $.ajax({
        url: "assets/controller/controllerSocio.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })
        .done(function (msg) {
            let obj = JSON.parse(msg);
            $('#atividadeEdit').val(obj.idAtividade);

            $('#btnGuardaEdit').attr('onclick', 'alteraActividade(' + obj.nif + ')')
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

$('#listaSocios4').change(filtrarTabela);

function alteraActividade(socioSelect) {

    let dados = new FormData();
    dados.append('atividade', $('#atividadeEdit').val());
    dados.append('oldNif', socioSelect);
    dados.append('op', 5);


    $.ajax({
        url: "assets/controller/controllerSocio.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Atividade Alterada", obj.msg, "success");
                getListaFuncionario();
            } else {
                alerta("Sócio", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function filtrarTabela1() {
    let socioSelect2 = $('#listaSocios4').val();
    let dados = new FormData();
    dados.append('socioSelect2', socioSelect2);
    dados.append('op', 44);
  
    $.ajax({
        url: "assets/controller/controllerSocio.php",
      method: "POST",
      data: dados,
      dataType: "html",
      cache: false,
      contentType: false,
      processData: false,
    })
    .done(function(msg) {
        let obj = JSON.parse(msg);
        $('#nifSocioEdit').val(obj.nif);
        $('#nomeSocioEdit').val(obj.nome);
        $('#moradaSocioEdit').val(obj.numeroSocio);
        $('#telSocioEdit').val(obj.morada);
        $('#emailSocioEdit').val(obj.email);
        $('#numSocioEdit').val(obj.telefone);
        $('#dataNascimentoSocioEdit').val(obj.dataNascimento);
     
        $('#btnGuardaEdit1').attr('onclick', 'guardaDadosSocioEdit('+obj.nif+')')
    })
    .fail(function(jqXHR, textStatus) {
      alert("Request failed: " + textStatus);
    });
  }
  
  $('#listaSocios4').change(filtrarTabela1);

  function guardaDadosSocioEdit(socioSelect2){
  
    let dados = new FormData();
    dados.append('nif', $('#nifSocioEdit').val());
    dados.append('nome', $('#nomeSocioEdit').val());
    dados.append('numeroSocio', $('#moradaSocioEdit').val());
    dados.append('morada', $('#telSocioEdit').val());
    dados.append('email', $('#emailSocioEdit').val());
    dados.append('telefone', $('#numSocioEdit').val());
    dados.append('dataNascimento', $('#dataNascimentoSocioEdit').val());
    dados.append('oldNif', socioSelect2);
    dados.append('op', 55);
  
   
    $.ajax({
        url: "assets/controller/controllerSocio.php",
      method: "POST",
      data: dados,
      dataType: "html",
      cache: false,
      contentType: false,
      processData:false,
    })
    
    .done(function (msg) {

        let obj = JSON.parse(msg);
        if (obj.flag) {
            alerta("Socio/a", obj.msg, "success");
            getListaSocios();
        } else {
            alerta("Socio/a", obj.msg, "error");
        }

    })
    
    .fail(function( jqXHR, textStatus ) {
      alert( "Request failed: " + textStatus );
    });
  
  }

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}

function enableEditButton() {
    // Remove o atributo 'disabled' do botão de edição
    document.getElementById('nifSocioEdit').disabled = false;
}

$(function () {
    getAtividades();
    getSocio();
    getListaSocios();
    getListaSociosInativos();
    getListaEmprestimosAtraso();
});