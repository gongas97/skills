function getSeccoes() {

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerSeccao.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemSeccoes').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}

function deleteSeccao(cod) {
    let dados = new FormData();
    dados.append('cod', cod); 
    dados.append('op', 1);

    $.ajax({
        url: "assets/controller/controllerSeccao.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {

        let obj = JSON.parse(msg);
        if (obj.flag) {
            alerta("Secção Removida", obj.msg, "success");
            getSeccoes();
        } else {
            alerta("Secção", obj.msg, "error");
        }

    })
    .fail(function(jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

$(function () {
    getSeccoes();
});