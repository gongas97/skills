function registarLivro() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("ISBN", $('#ISBNLivro').val());
    dados.append("tit", $('#tituloLivro').val());
    dados.append("dataL", $('#dataLanLivro').val());
    dados.append("sinop", $('#sinopseLivro').val());
    dados.append("edicao", $('#edicaoLivro').val());
    dados.append("editora", $('#editoraLivro').val());
    dados.append("idioma", $('#idiomaLivro').val());
    dados.append("nPaginas", $('#paginasLivro').val());
    dados.append("estado", $('#estadoLivro').val());
    dados.append("qtd", $('#quantLivro').val());

    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Livro", obj.msg, "success");
                getListaLivros();
                getLivros();
            } else {
                alerta("Livro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function registarEscritor() {

    let dados = new FormData();
    dados.append("op", 10);
    dados.append("autor", $('#listaAutores').val());
    dados.append("livro", $('#listaLivros').val());

    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Escritor/a", obj.msg, "success");
                getLivros();
            } else {
                alerta("Escritor/a", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function localizacao() {

    let dados = new FormData();
    dados.append("op", 11);
    dados.append("estante", $('#listaEstantes').val());
    dados.append("livro", $('#listaLivros2').val());

    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Localização Defenida", obj.msg, "success");
                getLivros();
            } else {
                alerta("Localização", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}


function getListaLivros() {

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemLivros').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function deleteLivro(ISBN) {
    let dados = new FormData();
    dados.append('ISBN', ISBN);
    dados.append('op', 7);

    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Livro", obj.msg, "success");
                getListaLivros();
            } else {
                alerta("Livro", obj.msg, "error");
            }

        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function adicionarQuantidade(ISBN) {
    let dados = new FormData();
    dados.append('ISBN', ISBN);
    dados.append('op', 14);

    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        $('#modalStock').modal('show');
        $('#hiddenISBN').val(ISBN);  
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

function adicionarStock() {
    let ISBN = $('#hiddenISBN').val(); 
    let quantidadeAdicionada = $('#quantidade').val();  

    let dados = new FormData();
    dados.append('ISBN', ISBN);
    dados.append('quantidadeAdicionada', quantidadeAdicionada);
    dados.append('op', 15);

    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        alert("Stock atualizado com sucesso.");
        $('#modalStock').modal('hide');  // jQuery to close modal
        getListaLivros(); 
    })
    .fail(function (jqXHR, textStatus) {
        alert("Erro ao adicionar stock: " + textStatus);
    });
}

function infoLivro(ISBN) {
    let dados = new FormData();
    dados.append('ISBN', ISBN);
    dados.append('op', 14);

    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        $('#modalInfo').modal('show');
        $('#listagemInfo').html(msg);  
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

function getEstadoLivro() {

    let dados = new FormData();
    dados.append("op", 3);


    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#estadoLivro').html(msg);
            $('#estadoLivroEdit').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getLivros() {

    let dados = new FormData();
    dados.append("op", 6);


    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#listaLivros').html(msg);
            $('#listaLivros2').html(msg);
            $('#listaLivros3').html(msg);
            $('#listaLivros4').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getAutor() {

    let dados = new FormData();
    dados.append("op", 8);


    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#listaAutores').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getEstante() {

    let dados = new FormData();
    dados.append("op", 9);


    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#listaEstantes').html(msg);
            $('#listaEstantes2').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function filtrarTabela() {
    let livroSelect2 = $('#listaLivros4').val();
    let dados = new FormData();
    dados.append('livroSelect2', livroSelect2);
    dados.append('op', 4);

    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })
        .done(function (msg) {
            let obj = JSON.parse(msg);
            $('#isbnLivroEdit').val(obj.ISBN);
            $('#titLivroEdit').val(obj.titulo);
            $('#dataLivroEdit').val(obj.dataLancamento);
            $('#sinopLivroEdit').val(obj.sinopse);
            $('#edicaoLivroEdit').val(obj.edicao);
            $('#editoraLivroEdit').val(obj.editora);
            $('#idiomaLivroEdit').val(obj.idioma);
            $('#nPaginasLivroEdit').val(obj.nPaginas);
            $('#estadoLivroEdit').val(obj.idEstado);

            $('#btnGuardaEdit').attr('onclick', 'guardaDadosLivroEdit(' + obj.ISBN + ')')
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

$('#listaLivros4').change(filtrarTabela);

function guardaDadosLivroEdit(livroSelect2) {

    let dados = new FormData();
    dados.append('isbn', $('#isbnLivroEdit').val());
    dados.append('tit', $('#titLivroEdit').val());
    dados.append('data', $('#dataLivroEdit').val());
    dados.append('sinop', $('#sinopLivroEdit').val());
    dados.append('edicao', $('#edicaoLivroEdit').val());
    dados.append('editora', $('#editoraLivroEdit').val());
    dados.append('idioma', $('#idiomaLivroEdit').val());
    dados.append('nPaginas', $('#nPaginasLivroEdit').val());
    dados.append('estado', $('#estadoLivroEdit').val());
    dados.append('oldISBN', livroSelect2);
    dados.append('op', 5);


    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Livro", obj.msg, "success");
                getListaLivros();
            } else {
                alerta("Livro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function filtrarTabela1() {
    let livroSelect = $('#listaLivros3').val();
    let dados = new FormData();
    dados.append('livroSelect', livroSelect);
    dados.append('op', 12);

    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })
        .done(function (msg) {
            let obj = JSON.parse(msg);
            $('#listaEstantes2').val(obj.idEstante);

            $('#btnGuardaEdit').attr('onclick', 'moverLivro(' + obj.id + ')')
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

$('#listaLivros3').change(filtrarTabela1);

function moverLivro(livroSelect) {

    let dados = new FormData();
    dados.append('estante', $('#listaEstantes2').val());
    dados.append('oldId', livroSelect);
    dados.append('op', 13);


    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Livro Movido", obj.msg, "success");
                getListaLivros();
            } else {
                alerta("Livro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function showAuthorInfo(nif) {
    // Prepare the data to send
    let dados = new FormData();
    dados.append('nif', nif);
    dados.append('op', 16); 

    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        // Populate the author information modal
        $('#infoAutor').html(msg);
        // Show the author info modal
        $('#modalAuthorInfo').modal('show');
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}

$(function () {
    getEstadoLivro();
    getLivros();
    getAutor();
    getEstante();
    getListaLivros();
});