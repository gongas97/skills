function registaEmprestimo() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("dataR", $('#dataRegistoEmprestimo').val());
    dados.append("dataD", $('#dataDevolucaoEmprestimo').val());
    dados.append("socio", $('#listaSocios2').val());
    dados.append("colaborador", $('#listaFuncionarios').val());

    $.ajax({
        url: "assets/controller/controllerEmprestimo.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Empréstimo", obj.msg, "success");
                getListaEmprestimo();
                getEmprestimo();
            } else {
                alerta("Empréstimo", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}



function registaLivrosEmprestimo() {

    let dados = new FormData();
    dados.append("op", 7);
    dados.append("cod", $('#codEmprestimo').val());
    dados.append("livro", $('#listaLivros2').val());

    $.ajax({
        url: "assets/controller/controllerEmprestimo.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Livro Concedido por Empréstimo", obj.msg, "success");
            } else {
                alerta("Registo", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}



function getListaEmprestimo() {

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerEmprestimo.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemEmprestimos').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function deleteFuncionario(nif) {
    let dados = new FormData();
    dados.append('nif', nif);
    dados.append('op', 7);

    $.ajax({
        url: "assets/controller/controllerEmprestimo.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Funcionário/a", obj.msg, "success");
                getListaFuncionario();
            } else {
                alerta("Funcionário/a", obj.msg, "error");
            }

        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getEmprestimo() {

    let dados = new FormData();
    dados.append("op", 3);


    $.ajax({
        url: "assets/controller/controllerEmprestimo.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#codEmprestimo').html(msg);
            $('#codEmprestimoEdit').html(msg);
            $('#listaEmprestimos4').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function carregarLivrosAssociados() {
    let emprestimoSelect = $('#listaEmprestimos4').val();
    let dados = new FormData();
    dados.append("op", 44); // Verifique se o código da operação está correto
    dados.append("codEmprestimo", emprestimoSelect); // Passar o código do empréstimo

    $.ajax({
        url: "assets/controller/controllerEmprestimo.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        let obj = JSON.parse(msg); // Certifique-se de que a resposta é um JSON
        $('#listaLivrosAssociados').empty(); // Limpar a lista de livros

        // Preencher a lista de livros associados
        obj.livros.forEach(function(livro) {
            $('#listaLivrosAssociados').append(new Option(livro.titulo, livro.ISBN)); // Use ISBN como valor
        });
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

function devolucao() {
    let emprestimoSelect = $('#listaEmprestimos4').val();
    let ISBNLivros = $('#listaLivrosAssociados').val(); // Assume que este ID pode conter múltiplos ISBNs

    // Se for múltiplo, apenas pega o primeiro
    let ISBNLivro = Array.isArray(ISBNLivros) ? ISBNLivros[0] : ISBNLivros;

    let dados = new FormData();
    dados.append("op", 55); // Códigos de operação
    dados.append("codEmprestimo", emprestimoSelect);

    // Verifique se ISBNLivro está definido e não é nulo
    if (ISBNLivro) {
        dados.append("ISBNLivro", ISBNLivro); // Passar apenas um ISBN
    } else {
        alert("Por favor, selecione um livro.");
        return;
    }

    $.ajax({
        url: "assets/controller/controllerEmprestimo.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        let obj = JSON.parse(msg);
        if (obj.flag) {
            alerta("Devolução", obj.msg, "success");
            getListaEmprestimo(); // Atualiza a lista de empréstimos, se necessário
        } else {
            alerta("Devolução", obj.msg, "error");
        }
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

function getSocio() {

    let dados = new FormData();
    dados.append("op", 6);


    $.ajax({
        url: "assets/controller/controllerSocio.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#listaSocios2').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getLivro() {

    let dados = new FormData();
    dados.append("op", 6);


    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#listaLivros2').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getFuncionario() {

    let dados = new FormData();
    dados.append("op", 6);


    $.ajax({
        url: "assets/controller/controllerFuncionario.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#listaFuncionarios').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function filtrarTabela() {
    let emprestimoSelect = $('#codEmprestimoEdit').val();
    let dados = new FormData();
    dados.append('emprestimoSelect', emprestimoSelect);
    dados.append('op', 4);

    $.ajax({
        url: "assets/controller/controllerEmprestimo.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })
        .done(function (msg) {
            let obj = JSON.parse(msg);
            $('#dataPrevistaEdit').val(obj.dataPrevistaDevolucao);

            $('#btnGuardaEdit').attr('onclick', 'guardaDadosEmprestimo(' + obj.cod + ')')
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

$('#codEmprestimoEdit').change(filtrarTabela);

function guardaDadosEmprestimo(emprestimoSelect) {

    let dados = new FormData();
    dados.append('dataP', $('#dataPrevistaEdit').val());
    dados.append('oldCod', emprestimoSelect);
    dados.append('op', 5);


    $.ajax({
        url: "assets/controller/controllerEmprestimo.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Data de Devolução Alterada", obj.msg, "success");
                getListaEmprestimo();
            } else {
                alerta("Data", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function handleDevolucao() {
    let emprestimoSelect1 = $('#listaEmprestimos2').val(); // código do empréstimo
    let ISBNLivro = $('#listaLivros6').val(); // ISBN do livro selecionado

    if (emprestimoSelect1 && ISBNLivro) {
        registaDevolucao(emprestimoSelect1, ISBNLivro); // Passar o ISBN selecionado
    } else {
        alert("Por favor, selecione um empréstimo e um livro.");
    }
}

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}

$(function () {
    getSocio();
    getFuncionario();
    getEmprestimo();
    getLivro();
    getListaEmprestimo();
});