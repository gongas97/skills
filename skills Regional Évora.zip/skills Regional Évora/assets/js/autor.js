function registarAutor() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("nif", $('#nifAutor').val());
    dados.append("nome", $('#nomeAutor').val());
    dados.append("dataNasc", $('#dataAutor').val());
    dados.append("bio", $('#bioAutor').val());
    dados.append("info", $('#infoAutor').val());
    dados.append("face", $('#faceAutor').val());
    dados.append("inst", $('#instAutor').val());
    dados.append("x", $('#xAutor').val());

    $.ajax({
        url: "assets/controller/controllerAutor.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Autor/a", obj.msg, "success");
                getListaAutor();
            } else {
                alerta("Autor/a", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getAutor() {

    let dados = new FormData();
    dados.append("op", 8);


    $.ajax({
        url: "assets/controller/controllerLivro.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {
            $('#ListaAutorEdit').html(msg);
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getListaAutor() {

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerAutor.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemAutor').html(msg);

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function deleteAutor(nif) {
    let dados = new FormData();
    dados.append('nif', nif);
    dados.append('op', 7);

    $.ajax({
        url: "assets/controller/controllerAutor.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Funcionário/a", obj.msg, "success");
                getListaAutor();
            } else {
                alerta("Funcionário/a", obj.msg, "error");
            }

        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function filtrarTabela() {
    let autorSelect = $('#ListaAutorEdit').val();
    let dados = new FormData();
    dados.append('autorSelect', autorSelect);
    dados.append('op', 4);

    $.ajax({
        url: "assets/controller/controllerAutor.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })
        .done(function (msg) {
            let obj = JSON.parse(msg);
            $('#nifAutorEdit').val(obj.nif);
            $('#nomeAutorEdit').val(obj.nome);
            $('#dataNascimentoAutorEdit').val(obj.dataNascimento);
            $('#biografiaAutorEdit').val(obj.biografia);
            $('#infoAutorEdit').val(obj.info);
            $('#facebookAutorEdit').val(obj.facebook);
            $('#instagramAutorEdit').val(obj.instagram);
            $('#XAutorEdit').val(obj.X);

            $('#btnGuardaEdit').attr('onclick', 'guardaDadosAutor(' + obj.nif + ')')
        })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

$('#ListaAutorEdit').change(filtrarTabela);

function guardaDadosAutor(autorSelect) {

    let dados = new FormData();
    dados.append('nif', $('#nifAutorEdit').val());
    dados.append('nome', $('#nomeAutorEdit').val());
    dados.append('dataNascimento', $('#dataNascimentoAutorEdit').val());
    dados.append('biografia', $('#biografiaAutorEdit').val());
    dados.append('info', $('#infoAutorEdit').val());
    dados.append('facebook', $('#facebookAutorEdit').val());
    dados.append('instagram', $('#instagramAutorEdit').val());
    dados.append('X', $('#XAutorEdit').val());
    dados.append('oldNif', autorSelect);
    dados.append('op', 5);


    $.ajax({
        url: "assets/controller/controllerAutor.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Autor/a", obj.msg, "success");
                getListaAutor();
            } else {
                alerta("Autor/a", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}

$(function () {
    getListaAutor();
    getAutor();
});