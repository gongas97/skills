<?php
session_start();

if (isset($_SESSION['utilizador'])) {
    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>MENU</title>
        <link rel="stylesheet" href="assets/css/datatables.css">
        <link rel="stylesheet" href="assets/css/select2.css">
        <link rel="stylesheet" href="assets/css/bootstrap.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <script src="assets/js/lib/jquery.js"></script>
        <script src="assets/js/lib/datatables.js"></script>
        <script src="assets/js/lib/select2.js"></script>
        <script src="assets/js/lib/sweatalert.js"></script>
        <script src="assets/js/lib/bootstrap.js"></script>
        <script src="assets/js/login.js"></script>
    </head>

    <body>
        <?php include_once 'menu.php' ?>

        <div class="g-5">

            <!-- Carousel -->
            <div id="carouselExampleIndicators" class="carousel slide carousel-container" data-bs-ride="carousel">
                <div class="carousel-inner mb-5">
                    <div class="carousel-item active">
                        <img src="assets/imagens/sala.jpg"
                            class="d-block w-80 mx-auto img-fluid" alt="Slide 1">
                        <div class="carousel-caption d-none d-md-block">
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="assets/imagens/sala.jpg"
                            class="d-block w-80 mx-auto img-fluid" alt="Slide 2">
                        <div class="carousel-caption d-none d-md-block">
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="assets/imagens/sala.jpg"
                            class="d-block w-80 mx-auto img-fluid" alt="Slide 3">
                        <div class="carousel-caption d-none d-md-block">
                        </div>
                    </div>

                    <!-- Scripts necessários -->
                    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    </body>

    </html>

<?php
} else {
    echo "sem permissão!";
}

?>