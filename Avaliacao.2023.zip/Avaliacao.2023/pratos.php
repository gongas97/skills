<?php
session_start();
if (isset($_SESSION['utilizador'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PRATOS</title>
        <link rel="stylesheet" href="assets/css/datatables.css">
        <link rel="stylesheet" href="assets/css/select2.css">
        <link rel="stylesheet" href="assets/css/bootstrap.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <script src="assets/js/lib/jquery.js"></script>
        <script src="assets/js/lib/datatables.js"></script>
        <script src="assets/js/lib/select2.js"></script>
        <script src="assets/js/lib/sweatalert.js"></script>
        <script src="assets/js/lib/bootstrap.js"></script>
        <script src="assets/js/pratos.js"></script>
        <script src="assets/js/login.js"></script>
    </head>

    <body>

        <?php include_once 'menu.php' ?>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Pratos</h5>
                <div class="card-body">
                    <h5 class="card-title">Adicionar Prato</h5>
                    <form class="row g-3">
                        <div class="col-md-3">
                            <label for="nomePrato" class="form-label">Nome Prato</label>
                            <input type="text" class="form-control" id="nomePrato">
                        </div>

                        <div class="col-md-3">
                            <label for="precoPrato" class="form-label">Preço</label>
                            <input type="number" class="form-control" id="precoPrato">
                        </div>

                        <div class="col-md-6">
                            <label for="tipoPrato" class="form-label">Tipo Prato</label>
                            <select class="form-control" id="tipoPrato">
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="fotografia" class="form-label">Fotografia</label>
                            <input type="file" class="form-control" id="fotografia">
                        </div>

                        <div class="col-12">
                            <button type="button" class="btn btn-primary" onclick="registaPrato()">Registar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Listagem de Pratos</h5>
                <div class="card-body">

                    <table class="table table-striped" nif="tblPratos">
                        <thead>
                            <tr>
                                <th scope="col">Fotografia</th>
                                <th scope="col">Nome</th>
                                <th scope="col">Preço</th>
                                <th scope="col">Tipo</th>
                                <th scope="col">Editar</th>
                                <th scope="col">Remover</th>
                            </tr>
                        </thead>

                        <tbody id="listagemPratos">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="formEditPrato" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Editar Prato</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container">
                            <div class="card">
                                <h5 class="card-header">Prato <span id="nmPrato"></span></h5>
                                <div class="card-body">
                                    <h5 class="card-title">Editar</h5>
                                    <form class="row g-3">
                                    <div class="col-md-6">
                                            <label for="idPratoEdit" class="form-label">ID</label>
                                            <input type="number" class="form-control" id="idPratoEdit" disabled>
                                        </div>

                                        <div class="col-md-6">
                                            <label for="nomePratoEdit" class="form-label">Nome</label>
                                            <input type="text" class="form-control" id="nomePratoEdit">
                                        </div>
                                        <div class="col-md-3">
                                            <label for="precoPratoedit" class="form-label">Preço</label>
                                            <input type="number" class="form-control" id="precoPratoedit">
                                        </div>

                                        <div class="col-md-3">
                                            <label for="tipoPratoEdit" class="form-label">Tipo</label>
                                            <select class="form-control" id="tipoPratoEdit">
                                            </select>
                                        </div>

                                        <div class="col-md-6">
                                            <label for="fotoEdit" class="form-label">Fotografia</label>
                                            <input type="file" class="form-control" id="fotoEdit">
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="button" class="btn btn-primary" id="btnGuardar">Guardar</button>
                    </div>
                </div>
            </div>
        </div>
    </body>

    </html>

    <?php
} else {
    echo "sem permissão!";
}

?>