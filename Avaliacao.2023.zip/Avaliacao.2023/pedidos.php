<?php
session_start();
if (isset($_SESSION['utilizador'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PEDIDOS</title>
        <link rel="stylesheet" href="assets/css/datatables.css">
        <link rel="stylesheet" href="assets/css/select2.css">
        <link rel="stylesheet" href="assets/css/bootstrap.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <script src="assets/js/lib/jquery.js"></script>
        <script src="assets/js/lib/datatables.js"></script>
        <script src="assets/js/lib/select2.js"></script>
        <script src="assets/js/lib/sweatalert.js"></script>
        <script src="assets/js/lib/bootstrap.js"></script>
        <script src="assets/js/pedidos.js"></script>
        <script src="assets/js/reserva.js"></script>
        <script src="assets/js/login.js"></script>
    </head>

    <body>

        <?php include_once 'menu.php' ?>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Pedidos</h5>
                <div class="card-body">
                    <h5 class="card-title">Registar Pedido</h5>
                    <form class="row g-3">

                        <div class="col-md-6">
                            <label for="listaMesas1" class="form-label">Mesa</label>
                            <select class="form-control" id="listaMesas1">
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="listaEstado1" class="form-label">Estado</label>
                            <select class="form-control" id="listaEstado1">
                                <option value="-1">Iniciado</option>
                            </select>
                        </div>

                        <div class="col-12">
                            <button type="button" class="btn btn-primary" onclick="registaPedido()">Registar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Cozinha</h5>
                <div class="card-body">
                    <h5 class="card-title">Pedidos à Cozinha</h5>
                    <form class="row g-3">

                        <div class="col-md-6">
                            <label for="listaPedidos" class="form-label">Pedidos</label>
                            <select class="form-control" id="listaPedidos">
                            </select>
                        </div>

                        <div class="col-md-12 mt-4">
                            <div class="table-responsive">
                                <table class="table table-dark table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">ID</th>
                                            <th scope="col">Nome do Prato</th>
                                            <th scope="col">Sim/Não</th>
                                            <th scope="col">Comentário</th>
                                        </tr>
                                    </thead>
                                    <tbody id="listaPratos1">
                                        <!-- Linhas de pratos serão adicionadas aqui -->
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="col-12">
                            <button type="button" class="btn btn-primary" onclick="registaPedidoCozinha()">Fazer
                                Pedido</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Listagem de Pedidos à Cozinha</h5>
                <div class="card-body">

                    <table class="table table-striped" nif="tblPedidosCozinha">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">PEDIDO</th>
                                <th scope="col">INFO</th>
                                <th scope="col">REMOVER</th>
                            </tr>
                        </thead>

                        <tbody id="listagemPedidosCozinha">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Listagem de Pedidos</h5>
                <div class="card-body">

                    <table class="table table-striped" nif="tblPedidos">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Mesa</th>
                                <th scope="col">Estado</th>
                                <th scope="col">Alterar Estado</th>
                                <th scope="col">Remover</th>
                                <th scope="col">Recibos</th>
                            </tr>
                        </thead>

                        <tbody id="listagemPedidos">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="formInfoPratos" tabindex="-1" aria-labelledby="formInfoPratosLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="formInfoPratosLabel">Informações dos Pratos</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">Tipo</th>
                                    <th scope="col">Nome</th>
                                    <th scope="col">Preço</th>
                                </tr>
                            </thead>
                            <tbody id="listagemPedidosCozinhaPratos">
                                <!-- Dados dos pratos serão preenchidos aqui -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="formEditPedido" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Alterar Estado do Pedido</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container">
                            <div class="card">
                                <h5 class="card-header">Alterar Estado <span id="nmPedido"></span></h5>
                                <div class="card-body">
                                    <h5 class="card-title">Editar</h5>
                                    <form class="row g-3">

                                        <div class="col-md-6">
                                            <label for="estadoPedidoEdit" class="form-label">Estado Pedido</label>
                                            <select class="form-control" id="estadoPedidoEdit">
                                            </select>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="button" class="btn btn-primary" id="btnGuardar">Guardar</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="faturaPedido" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form>
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Pratos</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="container">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Nome</th>
                                            <th scope="col">Preço</th>
                                        </tr>
                                    </thead>
                                    <tbody id="listaPratosFatura"></tbody>
                                </table>
                                <div class="col-md-6">
                                    <label for="nome" class="form-label">TOTAL em euros</label>
                                    <input type="text" class="form-control" id="total" disabled>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </body>

    </html>

    <?php
} else {
    echo "sem permissão!";
}

?>