<?php

require_once 'connection.php';

class Reserva{

    function registaReserva($cliente, $mesa, $data, $hora, $estado){
    
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "INSERT INTO reserva (idCliente, idMesa, data, hora, estado) VALUES ('".$cliente."', '".$mesa."','".$data."','".$hora."','".$estado."')";


        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com sucesso!";
        } else {
            $flag = false;
        }
       

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);

    }

    function getListaReservas(){

        global $conn;
        $msg = "";
        session_start();

        $sql = "SELECT clientes.*, mesas.nome as nomeM, reserva.*, estadoreserva.descricao FROM clientes, mesas, reserva, estadoreserva WHERE clientes.nif = reserva.idCliente AND mesas.id = reserva.idMesa AND reserva.estado = estadoreserva.id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>".$row['id']."</th>";
                $msg .= "<th scope='row'>".$row['nome']."</th>";
                $msg .= "<td>".$row['nomeM']."</td>";
                $msg .= "<td>".$row['data']." - ".$row['hora']."</td>";
                $msg .= "<td>".$row['descricao']."</td>";
                if($_SESSION['tipo'] == 1){
                    $msg .= "<td><button class='btn btn-dark' onclick ='getDadosReserva(".$row['id'].")'>Alterar Estado</button></td>";
                    $msg .= "<td><button class='btn btn-danger' onclick ='removerReserva(".$row['id'].")'><i class='fa fa-trash'></i></button></td>";
                }else{
                    $msg .= "<td><button class='btn btn-secondary' onclick ='erroPermissao()'><i class='fa fa-trash'></i></button></td>";
                }
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function getDadosReserva($id){
        global $conn;
        $msg = "";
        $row = "";

        $sql = "SELECT * FROM reserva WHERE id =".$id;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));

    }


    function guardaEditReserva($id, $estado, $idOld){
        
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "UPDATE reserva SET id = '".$id."', estado = '".$estado."' WHERE id =".$idOld;


        if ($conn->query($sql) === TRUE) {
            $msg = "Estado Alterado";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);

    }


    function removerReserva($id) {
        global $conn;
        $msg = "";
        $flag = true;
    
        // Verificar o estado da reserva
        $sql_check = "SELECT estadoreserva.*, reserva.* FROM reserva 
                      JOIN estadoreserva ON reserva.estado = estadoreserva.id 
                      WHERE reserva.id = ".$id;
        $result_check = $conn->query($sql_check);
    
        if ($result_check->num_rows > 0) {
            $row = $result_check->fetch_assoc();
            if ($row['descricao'] == 'Cancelada') {
                // Estado é cancelado, pode remover a reserva
                $sql_delete = "DELETE FROM reserva WHERE id = ".$id;
    
                if ($conn->query($sql_delete) === TRUE) {
                    $msg = "Removido com Sucesso";
                } else {
                    $flag = false;
                    $msg = "Error: " . $sql_delete . "<br>" . $conn->error;
                }
            } else {
                $flag = false;
                $msg = "Erro: A reserva só pode ser removida se estiver no estado 'cancelada'.";
            }
        } else {
            $flag = false;
            $msg = "Erro: Reserva não encontrada.";
        }
    
        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
        
        $conn->close();
    
        return $resp;
    }


    function getEstadoReserva(){
        global $conn;
        $msg = "";
        $provisoria = "";

        $sql = "SELECT * FROM estadoreserva";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                if ($row['descricao'] == 'Provisória') {
                    $provisoria = "<option value='" . $row['id'] . "' selected>" . $row['descricao'] . "</option>";
                } else {
                    $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
                } 
            }
        } else {
            $msg = "<option value='-1'>Sem Estados registados</option>"; 

        }
        $conn->close();

        return $provisoria . $msg;
    }

    function getCancelada() {
        global $conn;
        $msg = "<option selected>Escolha uma Opção</option>";
    
        $sql = "SELECT * FROM estadoreserva WHERE id = 1";
        $result = $conn->query($sql);
    
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $msg = "<option value='1'>" . $row['descricao'] . "</option>"; 
        }
    
        $conn->close();
    
        return $msg;
    }

    function getMesaReserva(){
        global $conn;
        $msg = "<option selected>Escolha uma Mesa</option>";

        $sql = "SELECT * FROM mesas";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='".$row['id']."'>".$row['nome']."</option>"; 
            }
        } else {
            $msg = "<option value='-1'>Sem Mesas registadas</option>"; 

        }
        $conn->close();

        return ($msg);
    }

    function getClienteReserva(){
        global $conn;
        $msg = "<option selected>Escolha um Cliente</option>";

        $sql = "SELECT * FROM clientes";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='".$row['nif']."'>".$row['nome']."</option>"; 
            }
        } else {
            $msg = "<option value='-1'>Sem Clientes registados</option>"; 

        }
        $conn->close();

        return ($msg);
    }

}


?>