<?php

require_once 'connection.php';

class Clientes{

    function registarCliente($nif, $nome, $telefone, $morada, $email) {
        global $conn;
        $msg = "";
        $flag = true;
    
        // Verifica se o cliente com este NIF já está registrado
        $sql_check = "SELECT * FROM clientes WHERE nif = ?";
        if ($stmt_check = $conn->prepare($sql_check)) {
            $stmt_check->bind_param("s", $nif);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();
    
            if ($result_check->num_rows > 0) {
                $flag = false;
                $msg = "Erro: Cliente com este NIF já está registrado.";
            } else {
                // Registra o novo cliente
                $sql_insert = "INSERT INTO clientes (nif, nome, telefone, morada, email) VALUES (?, ?, ?, ?, ?)";
                if ($stmt_insert = $conn->prepare($sql_insert)) {
                    $stmt_insert->bind_param("sssss", $nif, $nome, $telefone, $morada, $email);
                    if ($stmt_insert->execute()) {
                        $msg = "Registrado com sucesso!";
                    } else {
                        $flag = false;
                        $msg = "Erro: " . $stmt_insert->error;
                    }
                    $stmt_insert->close();
                } else {
                    $flag = false;
                    $msg = "Erro: " . $conn->error;
                }
            }
            $stmt_check->close();
        } else {
            $flag = false;
            $msg = "Erro: " . $conn->error;
        }
    
        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
    
        $conn->close();
    
        return $resp;
    }


    function getListaClientes(){

        global $conn;
        $msg = "";
        session_start();

        $sql = "SELECT * FROM clientes";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>".$row['nif']."</th>";
                $msg .= "<td>".$row['nome']."</td>";
                $msg .= "<td>".$row['telefone']."</td>";
                $msg .= "<td>".$row['morada']."</td>";
                $msg .= "<td>".$row['email']."</td>";
                $msg .= "<td><button class='btn btn-warning' onclick ='getDadosCliente(".$row['nif'].")'><i class='fa fa-pencil'></i></button></td>";
                if($_SESSION['tipo']==1){
                    $msg .= "<td><button class='btn btn-danger' onclick ='removerCliente(".$row['nif'].")'><i class='fa fa-trash'></i></button></td>";
                }else{
                    $msg .= "<td>sem permissao</td>";
                }
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function removeCliente($nif){
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "DELETE FROM clientes WHERE nif = ".$nif;

        if ($conn->query($sql) === TRUE) {
            $msg = "Removido com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);
    }

    function getDadosCliente($nif){
        global $conn;
        $msg = "";
        $row = "";

        $sql = "SELECT * FROM clientes WHERE nif =".$nif;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));

    }


    function guardaEditCliente($nif, $nome, $telefone, $morada, $email, $nifOld){
        
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "UPDATE clientes SET nif = '".$nif."', nome = '".$nome."',telefone = '".$telefone."',morada = '".$morada."', email = '".$email."' WHERE nif =".$nifOld;


        if ($conn->query($sql) === TRUE) {
            $msg = "Editado com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);

    }

    function getSelectCliente(){
        global $conn;
        $msg = "<option selected>Escolha um Cliente</option>";

        $sql = "SELECT * FROM clientes";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='".$row['nif']."'>".$row['nome']."</option>"; 
            }
        } else {
            $msg = "<option value='-1'>Sem Clientes registados</option>"; 

        }
        $conn->close();

        return ($msg);
    }

}


?>