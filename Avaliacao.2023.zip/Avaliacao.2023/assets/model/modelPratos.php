<?php

require_once 'connection.php';

class Pratos{

    function registarPrato($nome, $preco, $tipo, $foto){

        global $conn;
        $msg = "";
        $flag = true;
        $sql = "";

        $resp = $this ->  uploads($foto, $nome);
        $resp = json_decode($resp, TRUE);

        if($resp['flag']){
            $sql = "INSERT INTO pratos (nome, preco, idTipo, foto) VALUES ('".$nome."','".$preco."','".$tipo."','".$resp['target']."')";
        }else{
            $sql = "INSERT INTO pratos (nome, preco, idTipo) VALUES ('".$nome."','".$preco."','".$tipo."')";
        }

        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com sucesso!";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
            $resUpdate = $this -> updateFoto($resp['target'], $nome);        
                    $resUpdate = json_decode($resUpdate, TRUE);
        }
       

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);

    
    }

    function updateFoto($diretorio, $id){
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "UPDATE pratos SET foto = '".$diretorio."' WHERE id = ".$id;

        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));

        return($resp);
    }

    function getListaPrato(){

        global $conn;
        $msg = "";
        session_start();

        $sql = "SELECT pratos.*, tipoprato.descricao, tipoprato.id as idTipo FROM pratos, tipoprato WHERE pratos.idTipo = tipoprato.id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'><img class='img-thumbnail' src='".$row['foto']."'></th>";
                $msg .= "<th scope='row'>".$row['nome']."</th>";
                $msg .= "<td>".$row['preco']." €</td>";
                $msg .= "<td>".$row['descricao']."</td>";
                $msg .= "<td><button class='btn btn-warning' onclick ='getDadosPratos(".$row['id'].")'><i class='fa fa-pencil'></i></button></td>";
                if($_SESSION['tipo']==1){
                    $msg .= "<td><button class='btn btn-danger' onclick ='removerPrato(".$row['id'].")'><i class='fa fa-trash'></i></button></td>";
                }else{
                    $msg .= "<td>sem permissao</td>";
                }
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function removerPrato($id) {
        global $conn;
        $msg = "";
        $flag = true;
    
        // Verifica se o prato está associado a algum pedido na tabela cozinha
        $checkSql = "SELECT COUNT(*) as count FROM cozinha WHERE idPrato = ?";
        if ($stmt = $conn->prepare($checkSql)) {
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->bind_result($count);
            $stmt->fetch();
            $stmt->close();
    
            if ($count > 0) {
                // O prato está associado a pedidos na cozinha, não pode ser removido
                $flag = false;
                $msg = "O prato não pode ser removido porque está associado a pedidos na cozinha.";
            } else {
                // O prato não está associado a pedidos, pode ser removido
                $deleteSql = "DELETE FROM pratos WHERE id = ?";
                if ($stmt = $conn->prepare($deleteSql)) {
                    $stmt->bind_param("i", $id);
                    if ($stmt->execute()) {
                        $msg = "Removido com Sucesso";
                    } else {
                        $flag = false;
                        $msg = "Error: " . $stmt->error;
                    }
                    $stmt->close();
                } else {
                    $flag = false;
                    $msg = "Error: " . $conn->error;
                }
            }
        } else {
            $flag = false;
            $msg = "Error: " . $conn->error;
        }
    
        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
        
        $conn->close();
        
        return $resp;
    }

    function getDadosPratos($id){
        global $conn;
        $msg = "";
        $row = "";

        $sql = "SELECT * FROM pratos WHERE id =".$id;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));

    }


    function guardaEditPrato($id, $nome, $preco, $tipo, $foto, $idOld){
        
        global $conn;
        $msg = "";
        $flag = true;
        $sql = "";

        $resp = $this -> uploads($foto, $nome);
        $resp = json_decode($resp, TRUE);

        if($resp['flag']){
            $sql = "UPDATE pratos SET id = '".$id."', nome = '".$nome."',preco = '".$preco."',idTipo = '".$tipo."', foto = '".$resp['target']."' WHERE id =".$idOld;
        }else{
            $sql = "UPDATE pratos SET  id = '".$id."', nome = '".$nome."',preco = '".$preco."',idTipo = '".$tipo."' WHERE id =".$idOld;
        }

        if ($conn->query($sql) === TRUE) {
            $msg = "Editado com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(array(
            "flag" => $flag,
            "msg" => $msg
        ));
          
        $conn->close();

        return($resp);

    }

    function getTipoPrato(){
        global $conn;
        $msg = "<option selected>Escolha um Tipo de Prato</option>";

        $sql = "SELECT * FROM tipoprato";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                $msg .= "<option value='".$row['id']."'>".$row['descricao']."</option>"; 
            }
        } else {
            $msg = "<option value='-1'>Sem Tipos registados</option>"; 

        }
        $conn->close();

        return ($msg);
    }



    function uploads($img, $id){

        $dir = "../imagens/pratos".$id."/";
        $dir1 = "assets/imagens/pratos".$id."/";
        $flag = false;
        $targetBD = "";
    
        if(!is_dir($dir)){
            if(!mkdir($dir, 0777, TRUE)){
                die ("Erro não é possivel criar o diretório");
            }
        }
      if(array_key_exists('foto', $img)){
        if(is_array($img)){
          if(is_uploaded_file($img['foto']['tmp_name'])){
            $fonte = $img['foto']['tmp_name'];
            $ficheiro = $img['foto']['name'];
            $end = explode(".",$ficheiro);
            $extensao = end($end);
    
            $newName = "prato".date("YmdHis").".".$extensao;
    
            $target = $dir.$newName;
            $targetBD = $dir1.$newName;
    
            $flag = move_uploaded_file($fonte, $target);
            
          } 
        }
      }
        return (json_encode(array(
          "flag" => $flag,
          "target" => $targetBD
        )));
    
    
    }
}


?>