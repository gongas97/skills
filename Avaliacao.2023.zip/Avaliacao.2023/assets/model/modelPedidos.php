<?php

require_once 'connection.php';

class Pedidos
{

    function registarPedido($mesa, $estado)
    {

        global $conn;
        $msg = "";
        $flag = true;

        $sql = "INSERT INTO pedido (idMesa, idEstado) VALUES ('" . $mesa . "', '" . $estado . "')";


        if ($conn->query($sql) === TRUE) {
            $msg = "Registado com sucesso!";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;

        }


        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return ($resp);


    }


    function getListaPedidos()
    {

        global $conn;
        $msg = "";

        $sql = "SELECT pedido.*, mesas.nome, estadopedido.descricao FROM pedido, mesas, estadopedido WHERE pedido.idMesa = mesas.id AND pedido.idEstado = estadopedido.id ";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['id'] . "</th>";
                $msg .= "<td>" . $row['nome'] . "</td>";
                $msg .= "<td>" . $row['descricao'] . "</td>";
                $msg .= "<td><button class='btn btn-outline-dark' onclick ='alterarEstado(" . $row['id'] . ")'>Alterar Estado</button></td>";
                $msg .= "<td><button class='btn btn-danger' onclick ='removePedido(" . $row['id'] . ")'><i class='fa fa-trash'></i></button></td>";
                if ($row['descricao'] == 'Finalizado')
                    $msg .= "<td><button class='btn btn-success' onclick ='emitirFatura(" . $row['id'] . ")'>Emitir Fatura</button></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function emitirFatura($idPedido) {
        global $conn;
        $total = 0;
        $msg = "";    
        $pratos = [];
    
        $sql = "SELECT pratos.nome, pratos.preco 
                FROM pratos 
                JOIN cozinha ON cozinha.idPrato = pratos.id 
                JOIN pedido ON cozinha.idPedido = pedido.id 
                WHERE pedido.id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $idPedido);
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";                    
                $msg .= "<td>" . htmlspecialchars($row['nome']) . "</td>";
                $msg .= "<td>" . htmlspecialchars($row['preco']) . "</td>";            
                $msg .= "</tr>";
                $total += $row['preco'];
    
                // Adiciona o prato e o preço como um array associativo
                array_push($pratos, array("nome" => $row['nome'], "preco" => $row['preco']));
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<th scope='row'>Sem resultados</th>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
    
        $stmt1 = $conn->prepare("UPDATE pedido SET idEstado = 3 WHERE id = ?");
        $stmt1->bind_param("i", $idPedido);       
        $stmt1->execute();
    
        $stmt->close();
        $stmt1->close();
        $conn->close();
    
        $response = array(
            "msg" => $msg,
            "total" => $total
        );
    
        $this -> faturas($idPedido, $pratos, $total);
    
        return json_encode($response);
    }
    function removePedido($id)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "DELETE FROM pedido WHERE id = " . $id;

        if ($conn->query($sql) === TRUE) {
            $msg = "Removido com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return ($resp);
    }

    function getEstado()
    {
        global $conn;
        $msg = "";
        $iniciado = "";

        $sql = "SELECT * FROM estadopedido";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                if ($row['descricao'] == 'Iniciado') {
                    $iniciado = "<option value='" . $row['id'] . "' selected>" . $row['descricao'] . "</option>";
                } else {
                    $msg .= "<option value='" . $row['id'] . "'>" . $row['descricao'] . "</option>";
                }
            }
        } else {
            $msg = "<option value='-1'>Sem Estados registados</option>";
        }

        $conn->close();

        return $iniciado . $msg;
    }

    function alterarEstado($id)
    {
        global $conn;
        $msg = "";
        $row = "";

        $sql = "SELECT * FROM pedido WHERE id =" . $id;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            $row = $result->fetch_assoc();
        }

        $conn->close();

        return (json_encode($row));

    }

    function getPedido()
    {
        global $conn;
        $msg = "<option selected>Escolha um Pedido</option>";

        $sql = "SELECT pedido.id, mesas.nome FROM pedido, mesas WHERE pedido.idMesa = mesas.id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<option value='" . $row['id'] . "'>" . $row['nome'] . "</option>";
            }
        } else {
            $msg = "<option value='-1'>Sem Mesas registadas</option>";

        }
        $conn->close();

        return ($msg);
    }

    function registarPedidoCozinha($pedido, $pratos)
    {
        global $conn;
        $msg = "";
        $flag = true;

        // Iniciar uma transação
        $conn->begin_transaction();

        try {
            foreach ($pratos as $prato) {
                $sql = "INSERT INTO cozinha (idPedido, idPrato) VALUES ('" . $pedido . "', '" . $prato . "')";
                if (!$conn->query($sql)) {
                    throw new Exception("Erro ao inserir o prato $prato: " . $conn->error);
                }
            }
            // Confirmar a transação
            $conn->commit();
            $msg = "Registado com sucesso!";
        } catch (Exception $e) {
            // Reverter a transação em caso de erro
            $conn->rollback();
            $flag = false;
            $msg = $e->getMessage();
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();
        return ($resp);
    }

    function getListaPedidosCozinha()
    {

        global $conn;
        $msg = "";
        session_start();

        $sql = "SELECT cozinha.*, pedido.idMesa, mesas.nome FROM cozinha, pedido, mesas WHERE cozinha.idPedido = pedido.id AND pedido.idMesa = mesas.id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['id'] . "</th>";
                $msg .= "<td>" . $row['nome'] . "</td>";
                if ($_SESSION['tipo'] == 1) {
                    $msg .= "<td><button class='btn btn-success' onclick ='infoPratos(" . $row['id'] . ")'><i class='fa fa-info'></i></button></td>";
                    $msg .= "<td><button class='btn btn-danger' onclick ='removePedidoCozinha(" . $row['id'] . ")'><i class='fa fa-trash'></i></button></td>";
                } else {
                    $msg .= "<td>sem permissao</td>";
                }
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";
        }
        $conn->close();

        return ($msg);
    }

    function infoPratos($id)
    {
        global $conn;

        $msg = "";
        $sql = "SELECT cozinha.id, pratos.nome, pratos.preco, tipoprato.descricao FROM cozinha, pratos, tipoprato WHERE cozinha.idPrato = pratos.id AND pratos.idTipo = tipoprato.id AND cozinha.id = $id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {

                $msg .= "<tr>";
                $msg .= "<td>" . $row['descricao'] . "</td>";
                $msg .= "<td>" . $row['nome'] . "</td>";
                $msg .= "<td>" . $row['preco'] . " €</td>";
                $msg .= "</tr>";
            }
        } else {
            $msg = "Sem Observações Registadas";
        }
        $conn->close();

        return ($msg);
    }

    function removePedidoCozinha($id)
    {
        global $conn;
        $msg = "";
        $flag = true;

        $sql = "DELETE FROM cozinha WHERE id = " . $id;

        if ($conn->query($sql) === TRUE) {
            $msg = "Removido com Sucesso";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return ($resp);
    }

    function getPrato()
    {
        global $conn;
        $msg = "";

        $sql = "SELECT * FROM pratos";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $msg .= "<tr>";
                $msg .= "<th scope='row'>" . $row['id'] . "</th>";
                $msg .= "<td>" . $row['nome'] . "</td>";
                $msg .= "<td><input type='checkbox' class='form-check-input' id='checkPrato" . $row['id'] . "'></td>";
                $msg .= "<td><input type='text' class='form-control' id='comentario" . $row['id'] . "'></td>";
                $msg .= "</tr>";
            }
        } else {
            $msg .= "<tr>";
            $msg .= "<td>Sem Registos</td>";
            $msg .= "<th scope='row'></th>";
            $msg .= "<td></td>";
            $msg .= "<td></td>";
            $msg .= "</tr>";

        }
        $conn->close();

        return ($msg);
    }


    function guardaEditPedido($estado, $idOld)
    {

        global $conn;
        $msg = "";
        $flag = true;

        $sql = "UPDATE pedido SET idEstado = '" . $estado . "' WHERE id =" . $idOld;


        if ($conn->query($sql) === TRUE) {
            $msg = "Estado Alterado";
        } else {
            $flag = false;
            $msg = "Error: " . $sql . "<br>" . $conn->error;
        }

        $resp = json_encode(
            array(
                "flag" => $flag,
                "msg" => $msg
            )
        );

        $conn->close();

        return ($resp);

    }

    function faturas($idPedido, $pratos, $total) {
        $dir = "../faturas/";
        // Cria o diretório se não existir
        if (!is_dir($dir)) {
            if (!mkdir($dir, 0777, true)) {
                die("Erro: não é possível criar o diretório de faturas.");
            }
        }
        // Gera o nome do arquivo
        $filename = 'fatura_' . date('YmdHis') . '.txt';
        $filepath = $dir . $filename;
        // Conteúdo do arquivo de texto
        $textContent = "Fatura de Mesa $idPedido\n\n";
        $textContent .= "Prato\t\tPreço\n";
        $textContent .= str_repeat("=", 40) . "\n";
    
        foreach ($pratos as $prato) {
            $textContent .= $prato['nome'] . "---------€" . $prato['preco'] . "\n";
        }
    
        $textContent .= "Total: €$total\n";
        // Escreve o conteúdo no arquivo
        if (file_put_contents($filepath, $textContent) !== false) {
            return $filepath; // Retorna o caminho do arquivo .txt
        } else {
            return false; // Retorna false se a escrita falhar
        }
    }

}

?>