<?php

require_once '../model/modelCliente.php';

$clientes = new Clientes();

if($_POST['op'] == 1){
    $resp = $clientes -> registarCliente(
        $_POST['nif'],
        $_POST['nome'],
        $_POST['telefone'],
        $_POST['morada'],
        $_POST['email']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $clientes -> getListaClientes();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $clientes -> removeCliente($_POST['nif']);
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $clientes -> getDadosCliente($_POST['nif']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $clientes -> guardaEditCliente(
        $_POST['nif'],
        $_POST['nome'],
        $_POST['telefone'],
        $_POST['morada'],
        $_POST['email'],
        $_POST['nifOld']
    );
    echo ($resp);

}





?>