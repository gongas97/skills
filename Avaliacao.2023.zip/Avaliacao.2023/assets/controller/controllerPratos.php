<?php

require_once '../model/modelPratos.php';

$prato = new Pratos();

if($_POST['op'] == 1){
    $resp = $prato -> registarPrato(
        $_POST['nome'],
        $_POST['preco'],
        $_POST['tipo'],
        $_FILES
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $prato -> getListaPrato();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $prato -> removerPrato($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $prato -> getDadosPratos($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $prato -> guardaEditPrato(
        $_POST['id'],
        $_POST['nome'],
        $_POST['preco'],
        $_POST['tipo'],
        $_FILES,
        $_POST['idOld']
    );
    echo ($resp);

}else if($_POST['op'] == 6){
    $resp = $prato -> getTipoPrato();
    echo($resp);

}





?>