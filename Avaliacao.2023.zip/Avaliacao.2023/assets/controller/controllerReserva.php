<?php

require_once '../model/modelReserva.php';

$reserva = new Reserva();

if($_POST['op'] == 1){
    $resp = $reserva -> registaReserva(
        $_POST['cliente'],
        $_POST['mesa'],
        $_POST['data'],
        $_POST['hora'],
        $_POST['estado']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $reserva -> getListaReservas();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $reserva -> removerReserva($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 6){
    $resp = $reserva -> getEstadoReserva();
    echo($resp);

}else if($_POST['op'] == 7){
    $resp = $reserva -> getMesaReserva();
    echo($resp);

}else if($_POST['op'] == 8){
    $resp = $reserva -> getClienteReserva();
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $reserva -> getDadosReserva($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $reserva -> guardaEditReserva(
        $_POST['id'],
        $_POST['estado'],
        $_POST['idOld']
    );
    echo ($resp);

}else if($_POST['op'] == 9){
    $resp = $reserva -> getCancelada();
    echo($resp);

}





?>