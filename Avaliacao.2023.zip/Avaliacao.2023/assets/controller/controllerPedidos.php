<?php

require_once '../model/modelPedidos.php';

$ped = new Pedidos();

if($_POST['op'] == 1){
    $resp = $ped -> registarPedido(
        $_POST['mesa'],
        $_POST['estado']
    );
    echo ($resp);

}else if($_POST['op'] == 2){
    $resp = $ped -> getListaPedidos();
    echo($resp);

}else if($_POST['op'] == 3){
    $resp = $ped -> removePedido($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 6){
    $resp = $ped -> getEstado();
    echo($resp);

}else if($_POST['op'] == 4){
    $resp = $ped -> alterarEstado($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 5){
    $resp = $ped -> guardaEditPedido(
        $_POST['estado'],
        $_POST['idOld']
    );
    echo ($resp);

}else if($_POST['op'] == 7){
    $resp = $ped -> getPedido();
    echo($resp);

}else if($_POST['op'] == 8){
    $resp = $ped -> getPrato();
    echo($resp);

}else if ($_POST['op'] == 9) {
    $pedido = $_POST['pedido'];
    $pratos = json_decode($_POST['pratos'], true);

    $resp = $ped->registarPedidoCozinha($pedido, $pratos);
    echo ($resp);

}else if($_POST['op'] == 10){
    $resp = $ped -> getListaPedidosCozinha();
    echo($resp);

}else if($_POST['op'] == 11){
    $resp = $ped -> removePedidoCozinha($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 12){
    $resp = $ped -> infoPratos($_POST['id']);
    echo($resp);

}else if($_POST['op'] == 13){
    $resp = $ped -> emitirFatura($_POST['idPedido']);
    echo($resp);

}





?>