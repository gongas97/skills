function registaPrato() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("nome", $('#nomePrato').val());
    dados.append("preco", $('#precoPrato').val());
    dados.append("tipo", $('#tipoPrato').val());
    dados.append("foto", $('#fotografia').prop('files')[0]);

    $.ajax({
        url: "assets/controller/controllerPratos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Prato", obj.msg, "success");
                getListaPratos();
            } else {
                alerta("Prato", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getListaPratos() {

    if ($.fn.DataTable.isDataTable('#tblPratos')) {
        $('#tblPratos').DataTable().destroy();
    }

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerPratos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemPratos').html(msg);
            $('#tblPratos').DataTable();

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function removerPrato(id) {

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerPratos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Prato", obj.msg, "success");
                getListaPratos();
            } else {
                alerta("Prato", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function getDadosPratos(id) {


    let dados = new FormData();
    dados.append("op", 4);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerPratos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#idPratoEdit').val(obj.id);
            $('#nomePratoEdit').val(obj.nome);
            $('#precoPratoedit').val(obj.preco);
            $('#tipoPratoEdit').val(obj.idTipo);
            $('#fotoEdit').attr('src', obj.foto);

            $('#btnGuardar').attr("onclick", "guardaEditPrato(" + obj.id + ")")

            $('#formEditPrato').modal('show')
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function guardaEditPrato(idOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("id", $('#idPratoEdit').val());
    dados.append("nome", $('#nomePratoEdit').val());
    dados.append("preco", $('#precoPratoedit').val());
    dados.append("tipo", $('#tipoPratoEdit').val());
    dados.append("foto", $('#fotoEdit').prop('files')[0]);
    dados.append("idOld", idOld);

    $.ajax({
        url: "assets/controller/controllerPratos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Prato", obj.msg, "success");
                getListaClientes();
                $('#formEditPrato').modal('hide')
            } else {
                alerta("Prato", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function getTipoPrato(){

    let dados = new FormData();
    dados.append("op", 6);


    $.ajax({
        url: "assets/controller/controllerPratos.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {
        $('#tipoPratoEdit').html(msg);  
        $('#tipoPrato').html(msg);  
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}


function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getListaPratos();
    getTipoPrato();
});

