function registaPedido() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("mesa", $('#listaMesas1').val());
    dados.append("estado", $('#listaEstado1').val());

    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Pedido", obj.msg, "success");
                getListaPedidos();
            } else {
                alerta("Pedido", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

let faturaEmitida = {};

function emitirFatura(idPedido) {
    let dados = new FormData();
    dados.append("op", 13);
    dados.append("idPedido", idPedido);

    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function(resp) {
        let obj = JSON.parse(resp);
        $('#listaPratosFatura').html(obj.msg);
        $('#total').val(obj.total);
        $('#faturaPedido').modal('show');

        // Atualiza o texto do botão após a emissão da fatura
        faturaEmitida[idPedido] = true;
        updateButtonText(idPedido);
    })
    .fail(function(jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

// Função para atualizar o texto do botão
function updateButtonText(idPedido) {
    let button = document.querySelector(`button[onclick='emitirFatura(${idPedido})']`);
    if (button) {
        button.innerText = faturaEmitida[idPedido] ? 'Emitir Segunda Via' : 'Emitir Fatura';
    }
}

function getListaPedidos() {

    if ($.fn.DataTable.isDataTable('#tblPedidos')) {
        $('#tblPedidos').DataTable().destroy();
    }

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemPedidos').html(msg);
            $('#tblPedidos').DataTable();

                    // Inicializa o estado dos botões
        $('#listagemPedidos tr').each(function() {
            let idPedido = $(this).find('th[scope="row"]').text();
            faturaEmitida[idPedido] = false; // Inicialmente, nenhuma fatura foi emitida
        });

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function removePedido(id) {

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Pedido", obj.msg, "success");
                getListaPedidos();
            } else {
                alerta("Pedido", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function getEstadoPedido(){

    let dados = new FormData();
    dados.append("op", 6);


    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {
        $('#listaEstado1').html(msg);  
        $('#estadoPedidoEdit').html(msg); 
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function alterarEstado(id) {


    let dados = new FormData();
    dados.append("op", 4);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#estadoPedidoEdit').val(obj.idEstado);

            $('#btnGuardar').attr("onclick", "guardaEditPedido(" + obj.id + ")")

            $('#formEditPedido').modal('show')
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function guardaEditPedido(idOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("estado", $('#estadoPedidoEdit').val());
    dados.append("idOld", idOld);

    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Estado Alterado", obj.msg, "success");
                getListaPedidos();
                $('#formEditPedido').modal('hide')
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

// COZINHA

function registaPedidoCozinha() {
    let pratosSelecionados = [];

    // Coleta os pratos selecionados
    $('#listaPratos1 input[type="checkbox"]:checked').each(function() {
        let pratoId = $(this).attr('id').replace('checkPrato', '');
        pratosSelecionados.push(pratoId);
    });

    let dados = new FormData();
    dados.append("op", 9);
    dados.append("pedido", $('#listaPedidos').val());
    dados.append("pratos", JSON.stringify(pratosSelecionados));

    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })
    .done(function (msg) {
        let obj = JSON.parse(msg);
        if (obj.flag) {
            alerta("Pedido à Cozinha", obj.msg, "success");
            getListaPedidosCozinha();
        } else {
            alerta("Pedido à Cozinha", obj.msg, "error");
        }
    })
    .fail(function (jqXHR, textStatus) {
        alert("Request failed: " + textStatus);
    });
}

function getListaPedidosCozinha() {

    if ($.fn.DataTable.isDataTable('#tblPedidosCozinha')) {
        $('#tblPedidosCozinha').DataTable().destroy();
    }

    let dados = new FormData();
    dados.append("op", 10);


    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemPedidosCozinha').html(msg);
            $('#tblPedidosCozinha').DataTable();

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function removePedidoCozinha(id) {

    let dados = new FormData();
    dados.append("op", 11);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Pedido Cozinha", obj.msg, "success");
                getListaPedidosCozinha();
            } else {
                alerta("Pedido Cozinha", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function getPedidoCozinha(){

    let dados = new FormData();
    dados.append("op", 7);


    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {
        $('#listaPedidos').html(msg);   
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function infoPratos(id) {

    $('#formInfoPratos').modal('show');

    let dados = new FormData();
    dados.append('id', id);
    dados.append('op', 12);


    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false,
    })

        .done(function (msg) {
            $('#formInfoPratos').modal('hide'),
            $('#listagemPedidosCozinhaPratos').html(msg)

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getPrato(){

    let dados = new FormData();
    dados.append("op", 8);


    $.ajax({
        url: "assets/controller/controllerPedidos.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {
        $('#listaPratos1').html(msg);   
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getListaPedidos();
    getEstadoPedido();
    getPedidoCozinha();
    getPrato();
    getListaPedidosCozinha();
});

