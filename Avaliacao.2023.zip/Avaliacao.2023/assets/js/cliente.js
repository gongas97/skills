function registaCliente() {

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("nif", $('#nifCliente').val());
    dados.append("nome", $('#nomeCliente').val());
    dados.append("telefone", $('#telefoneCliente').val());
    dados.append("morada", $('#moradaCliente').val());
    dados.append("email", $('#emailCliente').val());

    $.ajax({
        url: "assets/controller/controllerCliente.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Clientes", obj.msg, "success");
                getListaClientes();
            } else {
                alerta("Clientes", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function getListaClientes() {

    if ($.fn.DataTable.isDataTable('#tblClientes')) {
        $('#tblClientes').DataTable().destroy();
    }

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerCliente.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            $('#listagemClientes').html(msg);
            $('#tblClientes').DataTable();

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });
}

function removerCliente(nif) {

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("nif", nif);

    $.ajax({
        url: "assets/controller/controllerCliente.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Clientes", obj.msg, "success");
                getListaClientes();
            } else {
                alerta("Clientes", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });

}

function getDadosCliente(nif) {


    let dados = new FormData();
    dados.append("op", 4);
    dados.append("nif", nif);

    $.ajax({
        url: "assets/controller/controllerCliente.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#nifEdit').val(obj.nif);
            $('#nomeEdit').val(obj.nome);
            $('#telefoneEdit').val(obj.telefone);
            $('#moradaEdit').val(obj.morada);
            $('#emailEdit').val(obj.email);

            $('#btnGuardar').attr("onclick", "guardaEditCliente(" + obj.nif + ")")

            $('#formEditCliente').modal('show')
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function guardaEditCliente(nifOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("nif", $('#nifEdit').val());
    dados.append("nome", $('#nomeEdit').val());
    dados.append("telefone", $('#telefoneEdit').val());
    dados.append("morada", $('#moradaEdit').val());
    dados.append("email", $('#emailEdit').val());
    dados.append("nifOld", nifOld);

    $.ajax({
        url: "assets/controller/controllerCliente.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Cliente", obj.msg, "success");
                getListaClientes();
                $('#formEditCliente').modal('hide')
            } else {
                alerta("Cliente", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}


function alerta(titulo, msg, icon) {
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

    })
}


$(function () {
    getListaClientes();
});

