function registaReserva(){

    let dados = new FormData();
    dados.append("op", 1);
    dados.append("cliente", $('#listaClientes').val());
    dados.append("mesa", $('#listaMesas').val());
    dados.append("data", $('#dataReserva').val());
    dados.append("hora", $('#horaReserva').val());
    dados.append("estado", $('#estadoReserva').val());

    $.ajax({
    url: "assets/controller/controllerReserva.php",
    method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {

        let obj = JSON.parse(msg);
        if(obj.flag){
            alerta("Reserva",obj.msg,"success");
            getListareserva();
        }else{
            alerta("Reserva",obj.msg,"error");    
        }
        
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function getListareserva(){

    if ( $.fn.DataTable.isDataTable('#tblReserva') ) {
        $('#tblReserva').DataTable().destroy();
    }

    let dados = new FormData();
    dados.append("op", 2);


    $.ajax({
        url: "assets/controller/controllerReserva.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {

        $('#listagemReservas').html(msg);
        $('#tblReserva').DataTable();
        
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function removerReserva(id){

    let dados = new FormData();
    dados.append("op", 3);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerReserva.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {

        let obj = JSON.parse(msg);
        if(obj.flag){
            alerta("Reserva",obj.msg,"success");
            getListareserva();    
        }else{
            alerta("Reserva",obj.msg,"error");    
        }
        
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });

}

function getDadosReserva(id) {


    let dados = new FormData();
    dados.append("op", 4);
    dados.append("id", id);

    $.ajax({
        url: "assets/controller/controllerReserva.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            $('#idReservaEdit').val(obj.id);
            $('#estadoReservaEdit').val(obj.estado);

            $('#btnGuardar').attr("onclick", "guardaEditReserva(" + obj.id + ")")

            $('#formEditReserva').modal('show')
        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}

function guardaEditReserva(idOld) {

    let dados = new FormData();
    dados.append("op", 5);
    dados.append("id", $('#idReservaEdit').val());
    dados.append("estado", $('#estadoReservaEdit').val());
    dados.append("idOld", idOld);

    $.ajax({
        url: "assets/controller/controllerReserva.php",
        method: "POST",
        data: dados,
        dataType: "html",
        cache: false,
        contentType: false,
        processData: false
    })

        .done(function (msg) {

            let obj = JSON.parse(msg);
            if (obj.flag) {
                alerta("Estado Alterado", obj.msg, "success");
                getListareserva();
                $('#formEditReserva').modal('hide')
            } else {
                alerta("Erro", obj.msg, "error");
            }

        })

        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        });


}


function getEstado(){

    let dados = new FormData();
    dados.append("op", 6);


    $.ajax({
        url: "assets/controller/controllerReserva.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {
        $('#estadoReserva').html(msg);   
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function getEstadoCancelada(){

    let dados = new FormData();
    dados.append("op", 9);


    $.ajax({
        url: "assets/controller/controllerReserva.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {  
        $('#estadoReservaEdit').html(msg);  
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function getMesa(){

    let dados = new FormData();
    dados.append("op", 7);


    $.ajax({
        url: "assets/controller/controllerReserva.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {
        $('#listaMesas').html(msg); 
        $('#listaMesas1').html(msg); 
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}

function getCliente(){

    let dados = new FormData();
    dados.append("op", 8);


    $.ajax({
        url: "assets/controller/controllerReserva.php",
        method: "POST",
    data: dados,
    dataType: "html",
    cache: false,
    contentType: false,
    processData: false
    })
    
    .done(function( msg ) {
        $('#listaClientes').html(msg);  
    })
    
    .fail(function( jqXHR, textStatus ) {
    alert( "Request failed: " + textStatus );
    });
}


function alerta(titulo,msg,icon){
    Swal.fire({
        position: 'center',
        icon: icon,
        title: titulo,
        text: msg,
        showConfirmButton: true,

      })
}

function erroPermissao(){
    Swal.fire({
        position: 'center',
        icon: 'error',
        title: "Sem permissão!",
        text: "Não pode aceder a este conteudo",
        showConfirmButton: true,

      })
}


$(function() {
    getListareserva();
    getEstado();
    getEstadoCancelada();
    getCliente();
    getMesa();
    $('#clubeJogadorEdit').select2();

    $('#clubeJogadorEdit').select2({
        dropdownParent: $('#formEditJogador')
    });
});

