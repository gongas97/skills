<?php
session_start();

if (isset($_SESSION['utilizador'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>RESERVAS</title>
        <link rel="stylesheet" href="assets/css/datatables.css">
        <link rel="stylesheet" href="assets/css/select2.css">
        <link rel="stylesheet" href="assets/css/bootstrap.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <script src="assets/js/lib/jquery.js"></script>
        <script src="assets/js/lib/datatables.js"></script>
        <script src="assets/js/lib/select2.js"></script>
        <script src="assets/js/lib/sweatalert.js"></script>
        <script src="assets/js/lib/bootstrap.js"></script>
        <script src="assets/js/reserva.js"></script>
        <script src="assets/js/login.js"></script>
    </head>

    <body>
        <?php include_once 'menu.php' ?>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Reservas</h5>
                <div class="card-body">
                    <h5 class="card-title">Registar Reserva</h5>
                    <form class="row g-3">

                        <div class="col-md-8">
                            <label for="listaClientes" class="form-label">Cliente</label>
                            <select class="form-control" id="listaClientes">
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label for="listaMesas" class="form-label">Numero da Mesa</label>
                            <select class="form-control" id="listaMesas">
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label for="dataReserva" class="form-label">Data</label>
                            <input type="date" class="form-control" id="dataReserva">
                        </div>

                        <div class="col-md-4">
                            <label for="horaReserva" class="form-label">Hora</label>
                            <input type="time" class="form-control" id="horaReserva">
                        </div>

                        <div class="col-md-4">
                            <label for="estadoReserva" class="form-label">Estado</label>
                            <select class="form-control" id="estadoReserva">
                            </select>
                        </div>

                        <div class="col-12">
                            <button type="button" class="btn btn-primary" onclick="registaReserva()">Registar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <div class="card">
                <h5 class="card-header">Listagem de Reservas</h5>
                <div class="card-body">

                    <table class="table table-striped" nif="tblReserva">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Cliente</th>
                                <th scope="col">Mesa</th>
                                <th scope="col">Data/Hora</th>
                                <th scope="col">Estado</th>
                                <th scope="col">Alterar Estado</th>
                                <th scope="col">Remover</th>
                            </tr>
                        </thead>

                        <tbody id="listagemReservas">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="formEditReserva" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Editar Reserva</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container">
                            <div class="card">
                                <h5 class="card-header">Alterar Estado <span id="nmReserva"></span></h5>
                                <div class="card-body">
                                    <h5 class="card-title">Editar</h5>
                                    <form class="row g-3">
                                        <div class="col-md-6">
                                            <label for="idReservaEdit" class="form-label">ID</label>
                                            <input type="number" class="form-control" id="idReservaEdit" disabled>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="estadoReservaEdit" class="form-label">Estado</label>
                                            <select class="form-control" id="estadoReservaEdit">Escolha um estado
                                            </select>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="button" class="btn btn-primary" id="btnGuardar">Guardar</button>
                    </div>
                </div>
            </div>
        </div>

    </body>

    </html>

<?php
} else {
    echo "sem permissão!";
}

?>